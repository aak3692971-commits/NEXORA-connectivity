export type LookupSource =
  | 'steam' | 'gog' | 'epic' | 'xbox' | 'playstation' | 'nintendo'
  | 'ubisoft' | 'ea' | 'battlenet' | 'itchio' | 'rawg' | 'wikipedia';

const ALIASES: Record<string, string[]> = {
  "assassin's creed iv black flag": [
    'ac black flag', 'assassins creed black flag', 'assassin creed black flag',
    'assassins creed iv black flag', 'assassin creed iv black flag',
  ],
  'grand theft auto v': [
    'gta 5', 'gta5', 'gta v', 'grand theft auto 5', 'grand theft auto v enhanced',
  ],
  'red dead redemption 2': ['rdr2', 'rdr 2', 'red dead 2'],
  'the witcher 3 wild hunt': [
    'witcher 3', 'the witcher 3', 'witcher iii', 'the witcher iii wild hunt',
    'the witcher 3 wild hunt remastered',
  ],
};

const PLATFORM_NAME = '(?:steam|gog|epic(?: games store)?|xbox(?: game pass)?|microsoft(?: store)?|playstation|ps[45]|nintendo(?: switch)?|ubisoft(?: connect)?|ea(?: app)?|origin|battle\\.net|itch\\.io)';
const PLATFORM_SUFFIX = new RegExp(`(?:\\s*[([]\\s*(?:on\\s+)?${PLATFORM_NAME}\\s*[)\\]]\\s*$|\\s+(?:on|via)\\s+${PLATFORM_NAME}\\s*$|\\s+${PLATFORM_NAME}\\s*$)`, 'i');
const ARTICLES = new Set(['the', 'a', 'an']);
const ALIAS_TO_CANONICAL = new Map<string, string>();
for (const [canonical, aliases] of Object.entries(ALIASES)) {
  const normalizedCanonical = normalizeGameName(canonical);
  ALIAS_TO_CANONICAL.set(normalizedCanonical, normalizedCanonical);
  for (const alias of aliases) ALIAS_TO_CANONICAL.set(normalizeGameName(alias), normalizedCanonical);
}

export function normalizeGameName(value: string): string {
  return String(value ?? '')
    .replace(PLATFORM_SUFFIX, '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[™®©]/g, '')
    .toLowerCase()
    .replace(/['’]/g, '')
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .join(' ');
}

export function canonicalizeGameName(value: string): string {
  const cleaned = normalizeGameName(value);
  return ALIAS_TO_CANONICAL.get(cleaned) ?? cleaned;
}

function editDistance(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const next = [i];
    for (let j = 1; j <= b.length; j++) {
      next[j] = Math.min(
        next[j - 1]! + 1,
        prev[j]! + 1,
        prev[j - 1]! + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
    prev = next;
  }
  return prev[b.length]!;
}

function tokenSimilarity(a: string, b: string): number {
  if (a === b) return 1;
  if (Math.min(a.length, b.length) < 4) return 0;
  return 1 - editDistance(a, b) / Math.max(a.length, b.length);
}

/** Conservative 0..1 title similarity; exact known aliases are expanded first. */
export function matchScore(query: string, title: string): number {
  const q = canonicalizeGameName(query).split(' ').filter(Boolean);
  const t = canonicalizeGameName(title).split(' ').filter(Boolean);
  const qMeaningful = q.filter(x => !ARTICLES.has(x));
  const tMeaningful = t.filter(x => !ARTICLES.has(x));
  if (!qMeaningful.length || !tMeaningful.length) return 0;
  const qs = qMeaningful.join(' ');
  const ts = tMeaningful.join(' ');
  if (qs === ts) return 1;
  if (qs.replace(/\s/g, '') === ts.replace(/\s/g, '')) return 0.97;

  const used = new Set<number>();
  let matched = 0;
  for (const word of qMeaningful) {
    let best = 0, bestIndex = -1;
    tMeaningful.forEach((candidate, index) => {
      if (used.has(index)) return;
      const score = tokenSimilarity(word, candidate);
      if (score > best) { best = score; bestIndex = index; }
    });
    if (bestIndex >= 0 && best >= 0.72) {
      used.add(bestIndex);
      matched += best;
    }
  }
  const precision = matched / qMeaningful.length;
  const recall = matched / tMeaningful.length;
  let score = precision * 0.82 + recall * 0.18;
  if (qs.length >= 5 && (qs.includes(ts) || ts.includes(qs))) score = Math.max(score, 0.88);
  if (qMeaningful.length === 1 && qMeaningful[0]!.length < 5 && qs !== ts) score *= 0.86;
  return Math.min(1, score);
}

export interface RankedTitle<T> {
  value: T;
  title: string;
  confidence: number;
}

/** Order candidates by title confidence and discard weak matches. */
export function rankTitles<T extends { title: string }>(query: string, candidates: T[]): RankedTitle<T>[] {
  const seen = new Set<string>();
  return candidates
    .filter(candidate => typeof candidate.title === 'string' && candidate.title.trim())
    .map(value => ({ value, title: value.title.trim(), confidence: matchScore(query, value.title) }))
    .filter(result => result.confidence >= 0.42)
    .filter(result => {
      const key = normalizeGameName(result.title);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => b.confidence - a.confidence);
}

/** A result is selectable only when it is strong and not tied with another plausible title. */
export function isReliableMatch<T>(ranked: RankedTitle<T>[], query: string): boolean {
  const best = ranked[0];
  if (!best) return false;
  const normalizedQuery = canonicalizeGameName(query);
  const exact = canonicalizeGameName(best.title) === normalizedQuery;
  const minimum = normalizedQuery.replace(/\s/g, '').length < 5 ? 0.86 : 0.76;
  if (best.confidence < minimum) return false;
  if (exact && best.confidence >= 0.97) return true;
  const runnerUp = ranked[1];
  const queryWords = normalizedQuery.split(' ').filter(Boolean).length;
  const bestWords = normalizeGameName(best.title).split(' ').filter(Boolean).length;
  const runnerWords = runnerUp ? normalizeGameName(runnerUp.title).split(' ').filter(Boolean).length : -1;
  if (bestWords === queryWords && best.confidence >= 0.84 && runnerWords !== queryWords) return true;
  return !runnerUp || best.confidence - runnerUp.confidence >= 0.09;
}

export function lookupAliases(): Readonly<Record<string, readonly string[]>> {
  return ALIASES;
}
