import type { Paired } from './signaling.js'; import type { SessionMsg } from './wire.js';
import { HostSession, type ClientStats, type QualityRequest } from './session.js'; import type { GameLibrary } from './library.js'; import type { MetaStore } from './meta.js';
import type { InputSink } from './input.js'; import type { MediaSink } from './capture.js';

/** Thin view of a WebRTC peer (libdatachannel). The host is always the offerer; the phone answers. */
export interface PeerHandle {
  onLocalDescription(cb: (sdp: string, type: string) => void): void; onLocalCandidate(cb: (cand: string, mid: string) => void): void; onState(cb: (s: string) => void): void;
  onChannelOpen(cb: () => void): void; onChannelMessage(cb: (s: string) => void): void; onChannelClosed(cb: () => void): void;
  /** Creates the tracks + data channel; the offer is produced right after. */
  start(): void;
  setRemoteDescription(sdp: string, type: string): void; addRemoteCandidate(cand: string, mid: string): void;
  sendChannel(s: string): void; sendVideo(rtp: Buffer): void; sendAudio(rtp: Buffer): void; close(): void;
}
export type PeerFactory = () => PeerHandle;
export interface SignalOut { sendSession(m: Omit<SessionMsg, 'from' | 'seq'>): void }
export interface Media { start(sink: MediaSink): Promise<void>; stop(): void; setBitrate?(kbps: number): void; setQuality?(q: { width?: number; height?: number; fps?: number; kbps?: number }): void; readonly quality?: { width: number; height: number; fps: number; kbps: number } }
export interface StreamDeps {
  out: SignalOut; peer: Paired; sessionId: string; makePeer: PeerFactory; media: Media; lib: GameLibrary; meta?: MetaStore; sink: InputSink;
  log: (e: string, f?: object) => void; onEnd: (why: string) => void; onLaunch?: (gameId: string) => object | null | void; onStats?: (s: ClientStats) => void; onState?: (s: string) => void;
  graceMs?: number; maxRenegotiations?: number;
  /** The phone's quality menu: apply a request, get the resulting settings back. */
  quality?: { apply(q: QualityRequest): object; current(): object };
  /** PC facts for the phone's "PC Host" screen (CPU / GPU / RAM, OS). */
  hostInfo?: () => object; infoEveryMs?: number;
}
const MAX_ICE = 128;

/** One phone <-> PC streaming session: offer/answer/ICE over signaling, then video/audio RTP out and input/library over the data channel. */
export class StreamSession {
  private p?: PeerHandle; private session?: HostSession; private pendingIce: { c: string; mid: string }[] = []; private haveAnswer = false;
  private ended = false; private renegs = 0; private timer?: ReturnType<typeof setTimeout>; private gen = 0; private open = false; private infoTimer?: ReturnType<typeof setInterval>;
  state = 'starting';
  constructor(private d: StreamDeps) {}

  start() { this.negotiate(); }
  private setState(s: string) { this.state = s; this.d.onState?.(s); }
  private negotiate() {
    const gen = ++this.gen, p = this.p = this.d.makePeer(); this.haveAnswer = false; this.pendingIce = []; this.open = false;
    const live = () => !this.ended && gen === this.gen;
    p.onLocalDescription((sdp, type) => { if (live() && type === 'offer') this.signal('offer', sdp); });
    p.onLocalCandidate((c, mid) => { if (live() && c) this.signal('ice', JSON.stringify({ candidate: c.startsWith('a=') ? c.slice(2) : c, sdpMid: mid })); });
    p.onChannelOpen(() => { if (!live()) return; this.open = true; this.setState('streaming'); this.session = new HostSession(this.d.lib, this.d.sink, o => this.sendChannel(o), this.d.log, this.d.meta, { onStats: s => this.d.onStats?.(s), onQuality: q => { if (this.d.quality) this.sendChannel({ type: 'quality', ...this.d.quality.apply(q) }); }, onLaunch: id => this.d.onLaunch?.(id) ?? null }); void this.startMedia(gen); this.pushInfo(); });
    p.onChannelMessage(m => { if (live()) this.session?.onMessage(m); });
    p.onChannelClosed(() => { if (live()) { this.open = false; clearInterval(this.infoTimer); this.lost('channel closed'); } });
    p.onState(s => {
      if (!live()) return; this.d.log('rtc_state', { s });
      if (s === 'connected') { clearTimeout(this.timer); this.renegs = 0; }
      else if (s === 'disconnected' || s === 'failed') this.lost(s);
      else if (s === 'closed' && !this.ended) this.lost('closed');
    });
    p.start();
  }
  private async startMedia(gen: number) {
    try { await this.d.media.start({ video: b => this.p?.sendVideo(b), audio: b => this.p?.sendAudio(b) }); }
    catch (e) { if (gen === this.gen) this.sendChannel({ type: 'error', message: 'The PC could not start screen capture.' }); this.d.log('media_start_failed', { err: e instanceof Error ? e.message : String(e) }); }
  }
  /** Sends the current quality + PC facts now and every few seconds while the channel is open. */
  private pushInfo() {
    // Prefer landscape on the phone as soon as the data channel opens (hidden control; phone may ignore).
    this.sendChannel({ type: 'preferOrientation', orientation: 'landscape' });
    const send = () => {
      if (this.d.quality) this.sendChannel({ type: 'quality', ...this.d.quality.current() });
      if (this.d.hostInfo) this.sendChannel({ type: 'host.info', ...this.d.hostInfo() });
      this.sendChannel({ type: 'preferOrientation', orientation: 'landscape' });
    };
    send(); clearInterval(this.infoTimer); this.infoTimer = setInterval(send, this.d.infoEveryMs ?? 5000); (this.infoTimer as any).unref?.();
  }
  private sendChannel(o: object) { try { this.p?.sendChannel(JSON.stringify(o)); } catch { /* channel not open */ } }
  private signal(kind: 'offer' | 'ice' | 'bye', data: string) { try { this.d.out.sendSession({ t: 'signal', to: this.d.peer.id, sessionId: this.d.sessionId, kind, data }); } catch (e) { this.d.log('signal_send_failed', { kind }); } }

  /** Verified signal from the phone (HostSignaling already checked the signature, target and sequence number). */
  onSignal(m: SessionMsg) {
    if (this.ended || m.sessionId !== this.d.sessionId || !this.p) return;
    if (m.kind === 'answer' && typeof m.data === 'string') {
      try { this.p.setRemoteDescription(m.data, 'answer'); this.haveAnswer = true; for (const i of this.pendingIce.splice(0)) this.p.addRemoteCandidate(i.c, i.mid); this.setState('negotiating'); }
      catch (e) { this.d.log('answer_rejected', { err: e instanceof Error ? e.message : String(e) }); this.end('bad answer'); }
    } else if (m.kind === 'ice' && typeof m.data === 'string') {
      let c: any; try { c = JSON.parse(m.data); } catch { return; }
      if (!c || typeof c.candidate !== 'string' || c.candidate.length > 512) return;
      const mid = typeof c.sdpMid === 'string' ? c.sdpMid.slice(0, 32) : '0';
      if (!this.haveAnswer) { if (this.pendingIce.length < MAX_ICE) this.pendingIce.push({ c: c.candidate, mid }); }
      else { try { this.p.addRemoteCandidate(c.candidate, mid); } catch { /* stale candidate */ } }
    } else if (m.kind === 'bye') this.end('phone left');
  }
  /** Link dropped. Give it a few seconds to recover by itself, then build a fresh offer on the same session (the phone answers it). */
  private lost(why: string) {
    if (this.ended) return; this.session?.onDisconnect(); this.setState('reconnecting');
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      if (this.ended) return;
      if (++this.renegs > (this.d.maxRenegotiations ?? 3)) return this.end('connection lost');
      this.d.log('renegotiate', { n: this.renegs, why });
      try { this.p?.close(); } catch { /* ignore */ } this.d.media.stop(); this.negotiate();
    }, this.d.graceMs ?? 5000);
  }
  end(why: string) {
    if (this.ended) return; this.ended = true; clearTimeout(this.timer); clearInterval(this.infoTimer); this.gen++;
    this.session?.onDisconnect(); this.d.media.stop(); this.signal('bye', why);
    try { this.p?.close(); } catch { /* ignore */ } this.p = undefined; this.setState('ended'); this.d.onEnd(why);
  }
  get active() { return !this.ended; }
  get peerId() { return this.d.peer.id; }
  setBitrate(k: number) { this.d.media.setBitrate?.(k); }
}
