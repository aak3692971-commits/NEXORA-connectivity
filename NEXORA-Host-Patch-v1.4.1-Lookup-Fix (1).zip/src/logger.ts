import fs from 'node:fs'; import path from 'node:path';
import type { Dirs } from './paths.js';
export interface LogEntry { t: number; event: string; f?: Record<string, unknown> }
const SECRET = /pin|key|token|sig|nonce|password|path|exe|cwd/i;
/** Daily JSON-lines log under logs/ (7 days kept) plus a small in-memory tail for the UI. Never writes secrets or file paths. */
export class Logger {
  private ring: LogEntry[] = [];
  constructor(private d: Dirs, private keepDays = 7, private echo = false) { this.prune(); }
  log = (event: string, f?: object) => {
    const clean: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(f ?? {})) clean[k] = SECRET.test(k) ? '[hidden]' : typeof v === 'string' ? v.slice(0, 200) : v;
    const e: LogEntry = { t: Date.now(), event, f: Object.keys(clean).length ? clean : undefined };
    this.ring.push(e); if (this.ring.length > 200) this.ring.shift();
    try { fs.appendFileSync(path.join(this.d.logs, `host-${new Date(e.t).toISOString().slice(0, 10)}.log`), JSON.stringify(e) + '\n'); } catch { /* logging must never crash the host */ }
    if (this.echo) console.log(new Date(e.t).toISOString().slice(11, 19), event, e.f ?? '');
  };
  recent(n = 100) { return this.ring.slice(-n); }
  private prune() {
    try {
      const cutoff = Date.now() - this.keepDays * 864e5;
      for (const f of fs.readdirSync(this.d.logs)) { const p = path.join(this.d.logs, f); if (/^host-.*\.log$/.test(f) && fs.statSync(p).mtimeMs < cutoff) fs.rmSync(p); }
    } catch { /* ignore */ }
  }
}
