declare module 'ws' { const x: any; export const WebSocketServer: any; export default x; }
