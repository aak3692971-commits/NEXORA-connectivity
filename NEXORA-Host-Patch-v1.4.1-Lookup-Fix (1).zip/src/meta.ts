import fs from 'node:fs';
import path from 'node:path';
import { JsonStore } from './store.js';
import type { Dirs } from './paths.js';
import {
  canonicalizeGameName, isReliableMatch, matchScore, rankTitles,
  type LookupSource,
} from './game-lookup.js';

export interface GameMeta {
  rev: number;
  title: string;
  canonicalId?: string;
  confidence?: number;
  description: string;
  source: LookupSource;
  hasCover: boolean;
  genres?: string[];
  releaseDate?: string;
  developer?: string;
  publisher?: string;
  platforms?: string[];
  screenshots?: string[];
  url?: string;
  platformIds?: Partial<Record<LookupSource, string>>;
}
export interface MetaSuggestion {
  title: string;
  source: LookupSource;
  confidence: number;
  url?: string;
}
export interface MetaWire {
  type: 'meta';
  gameId: string;
  rev: number;
  title: string;
  description: string;
  source: string;
  cover?: string;
}
export type Fetcher = (url: string, init?: {
  method?: string;
  headers?: Record<string, string>;
  body?: string;
  signal?: any;
}) => Promise<{
  ok: boolean;
  status: number;
  json(): Promise<any>;
  arrayBuffer(): Promise<ArrayBuffer>;
  headers: { get(k: string): string | null };
}>;

export const MAX_COVER_BYTES = 150_000;
const IMAGE_HOSTS = [
  /(^|\.)steamstatic\.com$/,
  /(^|\.)akamaihd\.net$/,
  /(^|\.)steampowered\.com$/,
  /^media\.rawg\.io$/,
  /(^|\.)wikimedia\.org$/,
  /(^|\.)wikipedia\.org$/,
  /(^|\.)gog-statics\.com$/,
  /(^|\.)unrealengine\.com$/,
  /(^|\.)epicgames\.com$/,
];
const TIMEOUT_MS = 6000;
const MAX_DESCRIPTION = 500;
const MAX_SCREENSHOTS = 8;

interface LookupCandidate {
  title: string;
  source: LookupSource;
  id?: string;
  description?: string;
  imageUrl?: string;
  screenshots?: string[];
  releaseDate?: string;
  developer?: string;
  publisher?: string;
  genres?: string[];
  platforms?: string[];
  productType?: string;
  url?: string;
  confidence?: number;
  raw?: any;
}

/** "eldenring_x64.exe" / "Cyberpunk2077" -> readable guess for the search box. */
export function cleanName(file: string): string {
  return file.replace(/\.exe$/i, '').replace(/[_\-.]+/g, ' ')
    .replace(/\b(x64|x86|win64|win32|shipping|launcher|game)\b/gi, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2').replace(/([a-zA-Z])(\d)/g, '$1 $2')
    .replace(/\s+/g, ' ').trim();
}

function stripHtml(s: string): string {
  return s.replace(/<\s*(br|\/p|\/li|\/div)[^>]*>/gi, ' ')
    .replace(/<[^>]*>/g, '')
    .replace(/&quot;/g, '"').replace(/&amp;/g, '&')
    .replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([a-f\d]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/\s+/g, ' ').trim();
}

function listOfStrings(value: unknown, key?: string): string[] {
  if (!Array.isArray(value)) return [];
  return value.map(item => typeof item === 'string' ? item : key && item && typeof item[key] === 'string' ? item[key] : '')
    .filter(Boolean).slice(0, MAX_SCREENSHOTS);
}

function cleanUrl(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  try {
    const url = new URL(value.startsWith('//') ? `https:${value}` : value);
    return url.protocol === 'https:' ? url.toString() : undefined;
  } catch { return undefined; }
}

function normalizeDate(value: unknown): string | undefined {
  if (typeof value !== 'string' || !value.trim()) return undefined;
  const v = value.trim();
  const dotted = /^(\d{4})\.(\d{2})\.(\d{2})$/.exec(v);
  return dotted ? `${dotted[1]}-${dotted[2]}-${dotted[3]}` : v.slice(0, 40);
}

function coverFromEpic(images: any[]): string | undefined {
  if (!Array.isArray(images)) return undefined;
  const priority = ['Thumbnail', 'OfferImageWide', 'DieselStoreFrontWide', 'VaultClosed'];
  for (const kind of priority) {
    const image = images.find(x => x?.type === kind && typeof x.url === 'string');
    if (image) return cleanUrl(image.url);
  }
  return cleanUrl(images.find(x => typeof x?.url === 'string')?.url);
}

function epicAttribute(attributes: any[], names: string[]): string | undefined {
  if (!Array.isArray(attributes)) return undefined;
  const wanted = new Set(names.map(x => x.toLowerCase()));
  const item = attributes.find(x => typeof x?.key === 'string' && wanted.has(x.key.toLowerCase()));
  return typeof item?.value === 'string' ? item.value.trim() || undefined : undefined;
}

/** Detects an image's real type from its signature, not the response header. */
export function sniffImage(b: Buffer): 'image/jpeg' | 'image/png' | 'image/webp' | null {
  if (b.length > 12 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'image/jpeg';
  if (b.length > 12 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (b.length > 12 && b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP') return 'image/webp';
  return null;
}

const EPIC_QUERY = `query searchStoreQuery(
  $count: Int, $country: String!, $keywords: String, $locale: String,
  $namespace: String, $sortBy: String, $sortDir: String, $start: Int, $tag: String
) {
  Catalog {
    searchStore(count: $count, country: $country, keywords: $keywords, locale: $locale,
      namespace: $namespace, sortBy: $sortBy, sortDir: $sortDir, start: $start, tag: $tag) {
      elements {
        title id namespace description effectiveDate keyImages { type url }
        seller { name } productSlug urlSlug url categories { path }
        customAttributes { key value }
      }
      paging { count total }
    }
  }
}`;

export class MetaStore {
  private idx: JsonStore<Record<string, GameMeta>>;
  private dir: string;
  private chain: Promise<unknown> = Promise.resolve();
  private pending = new Map<string, LookupCandidate[]>();

  constructor(
    d: Dirs,
    private fetcher: Fetcher = (u, i) => fetch(u, i as any) as any,
    private opts: { rawgKey?: string | null; enabled?: boolean } = {},
  ) {
    this.dir = path.join(d.cache, 'meta');
    fs.mkdirSync(this.dir, { recursive: true });
    this.idx = new JsonStore(path.join(this.dir, 'index.json'), {});
  }

  setEnabled(on: boolean) { this.opts.enabled = on; }
  get(id: string): GameMeta | null { return this.idx.load()[id] ?? null; }
  rev(id: string): number | undefined { return this.get(id)?.rev; }
  suggestions(id: string): MetaSuggestion[] {
    return (this.pending.get(id) ?? []).slice(0, 5).map(c => ({
      title: c.title, source: c.source, confidence: c.confidence ?? 0, ...(c.url ? { url: c.url } : {}),
    }));
  }
  private coverPath(id: string) { return path.join(this.dir, id.replace(/[^a-f0-9]/gi, '') + '.img'); }
  cover(id: string): { mime: string; data: Buffer } | null {
    try {
      const data = fs.readFileSync(this.coverPath(id));
      const mime = sniffImage(data);
      return mime ? { mime, data } : null;
    } catch { return null; }
  }
  remove(id: string) {
    const all = this.idx.load();
    delete all[id];
    this.idx.save(all);
    this.pending.delete(id);
    fs.rmSync(this.coverPath(id), { force: true });
  }
  wire(id: string): MetaWire | null {
    const m = this.get(id);
    if (!m) return null;
    const c = m.hasCover ? this.cover(id) : null;
    return {
      type: 'meta', gameId: id, rev: m.rev, title: m.title, description: m.description, source: m.source,
      ...(c ? { cover: `data:${c.mime};base64,${c.data.toString('base64')}` } : {}),
    };
  }

  lookup(id: string, name: string): Promise<GameMeta | null> {
    if (this.opts.enabled === false) {
      this.pending.delete(id);
      return Promise.resolve(null);
    }
    this.pending.delete(id);
    const run = this.chain.then(() => this.doLookup(id, name).catch(() => null));
    this.chain = run.catch(() => {});
    return run;
  }

  async chooseSuggestion(id: string, index: number): Promise<GameMeta | null> {
    if (!Number.isInteger(index) || index < 0 || index > 4) throw new Error('Invalid game suggestion');
    const candidate = this.pending.get(id)?.[index];
    if (!candidate) throw new Error('That lookup suggestion is no longer available. Refresh the game info and try again.');
    const hydrated = await this.hydrate(candidate).catch(() => candidate);
    if (hydrated.source === 'steam' && hydrated.productType && hydrated.productType !== 'game') {
      throw new Error('That Steam result is not a game. Choose another suggestion.');
    }
    const result = await this.commit(id, hydrated);
    this.pending.delete(id);
    return result;
  }

  private async json(url: string, init: { method?: string; headers?: Record<string, string>; body?: string } = {}): Promise<any> {
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), TIMEOUT_MS);
    try {
      const r = await this.fetcher(url, { ...init, signal: ac.signal });
      if (!r.ok) throw new Error(`http ${r.status}`);
      return await r.json();
    } finally { clearTimeout(t); }
  }

  private async image(url: string): Promise<Buffer | null> {
    let u: URL;
    try { u = new URL(url); } catch { return null; }
    if (u.protocol !== 'https:' || !IMAGE_HOSTS.some(re => re.test(u.hostname))) return null;
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), TIMEOUT_MS);
    try {
      const r = await this.fetcher(u.toString(), { signal: ac.signal });
      if (!r.ok) return null;
      const len = Number(r.headers.get('content-length') ?? 0);
      if (len > MAX_COVER_BYTES) return null;
      const b = Buffer.from(await r.arrayBuffer());
      return b.length <= MAX_COVER_BYTES && sniffImage(b) ? b : null;
    } catch { return null; } finally { clearTimeout(t); }
  }

  private async doLookup(id: string, name: string): Promise<GameMeta | null> {
    const query = canonicalizeGameName(name.trim());
    if (!query) return null;
    const alternatives: LookupCandidate[] = [];
    const providers: Array<() => Promise<LookupCandidate[]>> = [
      () => this.steam(query),
      () => this.gog(query),
      () => this.epic(query),
      ...(this.opts.rawgKey ? [() => this.rawg(query, this.opts.rawgKey!)] : []),
      () => this.wikipedia(query),
    ];

    for (const search of providers) {
      let candidates: LookupCandidate[] = [];
      try { candidates = await search(); } catch { /* a store being offline must not block later sources */ }
      const ranked = rankTitles(query, candidates);
      if (isReliableMatch(ranked, query)) {
        const chosen = { ...ranked[0]!.value, confidence: ranked[0]!.confidence };
        const hydrated = await this.hydrate(chosen).catch(() => chosen);
        if (!(hydrated.source === 'steam' && hydrated.productType && hydrated.productType !== 'game')) {
          this.pending.delete(id);
          return this.commit(id, hydrated);
        }
        for (const result of ranked.slice(1, 5)) {
          alternatives.push({ ...result.value, confidence: result.confidence });
        }
        continue;
      }
      for (const result of ranked.slice(0, 5)) {
        const candidate = { ...result.value, confidence: result.confidence };
        const prior = alternatives.findIndex(x => canonicalizeGameName(x.title) === canonicalizeGameName(candidate.title));
        if (prior < 0) alternatives.push(candidate);
        else if ((candidate.confidence ?? 0) > (alternatives[prior]!.confidence ?? 0)) alternatives[prior] = candidate;
      }
    }

    if (alternatives.length) {
      alternatives.sort((a, b) => (b.confidence ?? 0) - (a.confidence ?? 0));
      this.pending.set(id, alternatives.slice(0, 5));
    }
    return null;
  }

  private async hydrate(candidate: LookupCandidate): Promise<LookupCandidate> {
    if (candidate.source === 'steam' && candidate.id) {
      const details = await this.json(`https://store.steampowered.com/api/appdetails?appids=${encodeURIComponent(candidate.id)}&l=english`);
      const d = details?.[candidate.id]?.success ? details[candidate.id].data : null;
      if (!d) return candidate;
      const platforms = d.platforms
        ? Object.entries(d.platforms).filter(([, available]) => available).map(([name]) => name === 'windows' ? 'Windows' : name === 'mac' ? 'macOS' : 'Linux')
        : [];
      return {
        ...candidate,
        title: String(d.name ?? candidate.title),
        description: stripHtml(String(d.short_description ?? d.detailed_description ?? '')),
        imageUrl: cleanUrl(d.header_image) ?? candidate.imageUrl,
        screenshots: listOfStrings(d.screenshots?.map((x: any) => x?.path_full)),
        releaseDate: normalizeDate(d.release_date?.date),
        developer: listOfStrings(d.developers).join(', '),
        publisher: listOfStrings(d.publishers).join(', '),
        genres: listOfStrings(d.genres, 'description'),
        platforms,
        productType: typeof d.type === 'string' ? d.type.toLowerCase() : undefined,
        url: `https://store.steampowered.com/app/${encodeURIComponent(candidate.id)}/`,
      };
    }
    if (candidate.source === 'gog' && candidate.id) {
      const details = await this.json(`https://api.gog.com/products/${encodeURIComponent(candidate.id)}?expand=description`);
      const images = details?.images ?? {};
      const description = details?.description?.lead ?? details?.description?.full ?? '';
      return {
        ...candidate,
        title: String(details?.title ?? candidate.title),
        description: stripHtml(String(description)),
        imageUrl: cleanUrl(images.background) ?? candidate.imageUrl,
        releaseDate: normalizeDate(details?.release_date) ?? candidate.releaseDate,
        url: cleanUrl(details?.links?.product_card) ?? candidate.url,
      };
    }
    if (candidate.source === 'rawg' && candidate.id && this.opts.rawgKey) {
      const d = await this.json(`https://api.rawg.io/api/games/${encodeURIComponent(candidate.id)}?key=${encodeURIComponent(this.opts.rawgKey)}`);
      return {
        ...candidate,
        title: String(d?.name ?? candidate.title),
        description: stripHtml(String(d?.description_raw ?? d?.description ?? candidate.description ?? '')),
        imageUrl: cleanUrl(d?.background_image) ?? candidate.imageUrl,
        screenshots: listOfStrings(d?.short_screenshots?.map((x: any) => x?.image)),
        releaseDate: normalizeDate(d?.released) ?? candidate.releaseDate,
        developer: listOfStrings(d?.developers, 'name').join(', ') || candidate.developer,
        publisher: listOfStrings(d?.publishers, 'name').join(', ') || candidate.publisher,
        genres: listOfStrings(d?.genres, 'name'),
        platforms: listOfStrings(d?.platforms?.map((x: any) => x?.platform), 'name'),
        url: cleanUrl(d?.website) ?? candidate.url,
      };
    }
    return candidate;
  }

  private async commit(id: string, found: LookupCandidate): Promise<GameMeta> {
    const imageUrl = cleanUrl(found.imageUrl);
    const img = imageUrl ? await this.image(imageUrl) : null;
    const canonicalId = canonicalizeGameName(found.title).replace(/\s+/g, '-');
    const meta: GameMeta = {
      rev: Date.now(),
      title: found.title.slice(0, 100),
      canonicalId,
      confidence: Math.round((found.confidence ?? 1) * 100) / 100,
      description: stripHtml(found.description ?? '').slice(0, MAX_DESCRIPTION),
      source: found.source,
      hasCover: !!img,
      genres: (found.genres ?? []).filter(Boolean).slice(0, 8),
      ...(found.releaseDate ? { releaseDate: found.releaseDate.slice(0, 40) } : {}),
      ...(found.developer ? { developer: found.developer.slice(0, 160) } : {}),
      ...(found.publisher ? { publisher: found.publisher.slice(0, 160) } : {}),
      ...(found.platforms?.length ? { platforms: found.platforms.slice(0, 12) } : {}),
      ...(found.screenshots?.length ? { screenshots: found.screenshots.map(cleanUrl).filter((x): x is string => !!x).slice(0, MAX_SCREENSHOTS) } : {}),
      ...(found.url ? { url: cleanUrl(found.url) } : {}),
      ...(found.id ? { platformIds: { [found.source]: found.id } } : {}),
    };
    if (img) fs.writeFileSync(this.coverPath(id), img);
    else fs.rmSync(this.coverPath(id), { force: true });
    const all = this.idx.load();
    all[id] = meta;
    this.idx.save(all);
    return meta;
  }

  private async steam(q: string): Promise<LookupCandidate[]> {
    const s = await this.json(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(q)}&l=english&cc=US`);
    const items: any[] = Array.isArray(s?.items) ? s.items.filter((i: any) => i && Number.isInteger(i.id) && typeof i.name === 'string') : [];
    return items.slice(0, 20).map(i => ({
      title: i.name, id: String(i.id), source: 'steam' as const,
      imageUrl: cleanUrl(i.tiny_image),
      url: `https://store.steampowered.com/app/${i.id}/`,
      platforms: i.platforms ? Object.entries(i.platforms).filter(([, enabled]) => enabled).map(([p]) => p) : [],
    }));
  }

  private async gog(q: string): Promise<LookupCandidate[]> {
    const result = await this.json(`https://catalog.gog.com/v1/catalog?query=${encodeURIComponent(q)}&limit=25&productType=in%3Agame&locale=en-US&countryCode=US`);
    const products: any[] = Array.isArray(result?.products) ? result.products.filter((p: any) => p && p.id && typeof p.title === 'string' && p.productType !== 'dlc') : [];
    return products.slice(0, 25).map(p => {
      const slug = String(p.slug ?? '');
      const screenshots = listOfStrings(p.screenshots).map(s => s.replace('{formatter}', '600x338'));
      return {
        title: p.title, id: String(p.id), source: 'gog' as const,
        description: stripHtml(String(p.description ?? '')),
        imageUrl: cleanUrl(p.coverHorizontal) ?? cleanUrl(p.coverVertical),
        screenshots,
        releaseDate: normalizeDate(p.releaseDate ?? p.storeReleaseDate),
        developer: listOfStrings(p.developers).join(', '),
        publisher: listOfStrings(p.publishers).join(', '),
        genres: listOfStrings(p.genres, 'name'),
        platforms: listOfStrings(p.operatingSystems).map(x => x === 'osx' ? 'macOS' : x.charAt(0).toUpperCase() + x.slice(1)),
        url: cleanUrl(p.storeLink) ?? (slug ? `https://www.gog.com/game/${encodeURIComponent(slug)}` : undefined),
        raw: p,
      };
    });
  }

  private async epic(q: string): Promise<LookupCandidate[]> {
    const data = await this.json('https://store.epicgames.com/graphql', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        accept: 'application/json',
        origin: 'https://store.epicgames.com',
        referer: 'https://store.epicgames.com/',
      },
      body: JSON.stringify({
        query: EPIC_QUERY,
        variables: {
          count: 20, country: 'US', keywords: q, locale: 'en-US', namespace: 'epic',
          sortBy: 'relevancy', sortDir: 'DESC', start: 0,
          category: 'games/edition/base|bundles/games|editors',
        },
      }),
    });
    const products: any[] = data?.data?.Catalog?.searchStore?.elements ?? [];
    return products.filter((p: any) => p && p.id && typeof p.title === 'string').slice(0, 20).map(p => {
      const attrs = Array.isArray(p.customAttributes) ? p.customAttributes : [];
      const slug = String(p.productSlug || p.urlSlug || '');
      return {
        title: p.title, id: String(p.id), source: 'epic' as const,
        description: stripHtml(String(p.description ?? '')),
        imageUrl: coverFromEpic(p.keyImages ?? []),
        releaseDate: normalizeDate(p.releaseDate ?? p.effectiveDate),
        developer: epicAttribute(attrs, ['developerName', 'developer']),
        publisher: epicAttribute(attrs, ['publisherName', 'publisher']) ?? p.seller?.name,
        genres: listOfStrings(p.categories, 'path').map(x => x.split('/').filter(Boolean).pop() ?? x),
        platforms: ['PC'],
        url: cleanUrl(p.url) ?? (slug ? `https://store.epicgames.com/en-US/p/${encodeURIComponent(slug)}` : undefined),
      };
    });
  }

  private async rawg(q: string, key: string): Promise<LookupCandidate[]> {
    const result = await this.json(`https://api.rawg.io/api/games?search=${encodeURIComponent(q)}&page_size=10&key=${encodeURIComponent(key)}`);
    const games: any[] = Array.isArray(result?.results) ? result.results.filter((g: any) => g && Number.isInteger(g.id) && typeof g.name === 'string') : [];
    return games.map(g => ({
      title: g.name, id: String(g.id), source: 'rawg' as const,
      description: stripHtml(String(g.description_raw ?? '')),
      imageUrl: cleanUrl(g.background_image),
      screenshots: listOfStrings(g.short_screenshots?.map((x: any) => x?.image)),
      releaseDate: normalizeDate(g.released),
      genres: listOfStrings(g.genres, 'name'),
      platforms: listOfStrings(g.platforms?.map((x: any) => x?.platform), 'name'),
      url: cleanUrl(g.website) ?? (g.slug ? `https://rawg.io/games/${encodeURIComponent(g.slug)}` : undefined),
    }));
  }

  /** Non-store fallback, retained for tools and apps that are not games. */
  private async wikipedia(q: string): Promise<LookupCandidate[]> {
    const search = await this.json(`https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(q)}&limit=5&namespace=0&format=json&origin=*`);
    const titles: string[] = Array.isArray(search?.[1]) ? search[1].filter((t: any) => typeof t === 'string') : [];
    const ranked = rankTitles(q, titles.map(title => ({ title })));
    const results: LookupCandidate[] = [];
    for (const match of ranked.slice(0, 5)) {
      const page = await this.json(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(match.title.replace(/ /g, '_'))}`);
      if (!page || page.type === 'disambiguation') continue;
      results.push({
        title: String(page.title || match.title),
        source: 'wikipedia',
        description: stripHtml(String(page.extract || page.description || '')),
        imageUrl: cleanUrl(page.thumbnail?.source) ?? cleanUrl(page.originalimage?.source),
        url: cleanUrl(page.content_urls?.desktop?.page),
      });
    }
    return results;
  }
}

/** Exposed for tests to ensure candidate confidence is computed the same way at each storefront. */
export const lookupInternals = { matchScore };
