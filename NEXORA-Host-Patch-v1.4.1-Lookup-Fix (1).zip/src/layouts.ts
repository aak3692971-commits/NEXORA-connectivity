/**
 * On-screen control layouts for the phone.
 * Host stores templates + per-game choice; phone renders transparent keys.
 * Layouts are recommendations — the phone can turn them off or switch touch/cursor.
 */
import fs from 'node:fs';
import path from 'node:path';
import { JsonStore } from './store.js';
import type { Dirs } from './paths.js';

export type InputMode = 'touch' | 'cursor' | 'auto';
export type LayoutKind =
  | 'fps'
  | 'action'
  | 'racing'
  | 'rpg'
  | 'strategy'
  | 'platformer'
  | 'sports'
  | 'fighting'
  | 'generic';

/** One on-screen control. Coordinates are 0..1 of the landscape screen. */
export interface LayoutKey {
  id: string;
  /** What the host injects (keyboard name from input map, or mouse). */
  action: string;
  label: string;
  /** Letter / icon tint */
  color: string;
  x: number;
  y: number;
  w: number;
  h: number;
  shape?: 'circle' | 'roundrect' | 'stick';
  /** 0..1 glass opacity for the key face */
  opacity?: number;
}

export interface ControlLayout {
  id: string;
  name: string;
  kind: LayoutKind;
  /** Built-in vs user-edited copy */
  builtin: boolean;
  /** Overall glass transparency 0.15..0.85 */
  transparency: number;
  keys: LayoutKey[];
  updatedAt: number;
}

export interface GameLayoutPrefs {
  layoutId: string | null; // null = auto from genre
  inputMode: InputMode;
  layoutsEnabled: boolean;
  preferLandscape: boolean;
}

const KINDS: LayoutKind[] = [
  'fps', 'action', 'racing', 'rpg', 'strategy', 'platformer', 'sports', 'fighting', 'generic',
];

const GENRE_RULES: { kind: LayoutKind; re: RegExp }[] = [
  { kind: 'fps', re: /\b(fps|shooter|first.person|call of duty|counter[- ]?strike|valorant|apex|overwatch|doom|halo|battlefield|pubg|fortnite|destiny|quake|cs2|cs:?go|rainbow six)\b/i },
  { kind: 'racing', re: /\b(racing|race|forza|gran turismo|need for speed|f1|rally|dirt|assetto|hot wheels|driveclub)\b/i },
  { kind: 'fighting', re: /\b(fighter|fighting|tekken|street fighter|mortal kombat|smash|guilty gear|mk\d|injustice)\b/i },
  { kind: 'sports', re: /\b(fifa|nba|madden|pes|football|soccer|tennis|golf|nhl|mlb|wii sports|cricket|rugby|boxing|ufc|wwe|hockey|baseball|espn|rocket league)\b/i },
  { kind: 'strategy', re: /\b(strategy|rts|city.?builder|civilization|civ\s?\d|age of empires|total war|starcraft|simcity|anno|management)\b/i },
  { kind: 'rpg', re: /\b(rpg|role.?playing|elderscrolls|skyrim|witcher|elden|dark souls|final fantasy|dragon age|diablo|path of exile|baldur|cyberpunk|mass effect|zelda|souls)\b/i },
  { kind: 'platformer', re: /\b(platform|mario|sonic|hollow knight|celeste|metroid|rayman|crash bandicoot)\b/i },
  // Open-world / third-person action (RDR2, GTA, etc.) → action pad layout
  { kind: 'action', re: /\b(action|adventure|open.?world|third.?person|gta|grand theft|red dead|rdr2?|god of war|assassins? creed|spider-?man|batman|devil may cry|sekiro|ghost of tsushima|horizon|days gone|watch dogs|mad max|just cause|sleeping dogs|yakuza|like a dragon|tomb raider|uncharted)\b/i },
];

export function inferLayoutKind(name: string, genres: string[] = [], description = ''): LayoutKind {
  const blob = [name, ...genres, description.slice(0, 280)].join(' ');
  for (const g of genres) {
    const hit = GENRE_RULES.find(r => r.re.test(g));
    if (hit) return hit.kind;
  }
  for (const r of GENRE_RULES) if (r.re.test(blob)) return r.kind;
  return 'generic';
}

function k(
  id: string,
  action: string,
  label: string,
  color: string,
  x: number,
  y: number,
  w: number,
  h: number,
  shape: LayoutKey['shape'] = 'circle',
): LayoutKey {
  return { id, action, label, color, x, y, w, h, shape, opacity: 0.35 };
}

function builtin(id: LayoutKind, name: string, keys: LayoutKey[]): ControlLayout {
  return { id, name, kind: id, builtin: true, transparency: 0.4, keys, updatedAt: 0 };
}

/** Built-in landscape layouts (phone is always expected in landscape). */
export function builtinLayouts(): ControlLayout[] {
  return [
    builtin('fps', 'FPS / Shooter', [
      k('ls', 'STICK_L', '', '#5ec8ff', 0.14, 0.62, 0.16, 0.28, 'stick'),
      k('rs', 'STICK_R', '', '#ff8e5e', 0.78, 0.55, 0.14, 0.26, 'stick'),
      k('lt', 'LT', 'LT', '#7aa2ff', 0.06, 0.12, 0.12, 0.1, 'roundrect'),
      k('rt', 'RT', 'RT', '#ff7a90', 0.82, 0.12, 0.12, 0.1, 'roundrect'),
      k('lb', 'LB', 'LB', '#9ad0ff', 0.06, 0.24, 0.1, 0.08, 'roundrect'),
      k('rb', 'RB', 'RB', '#ffb08a', 0.84, 0.24, 0.1, 0.08, 'roundrect'),
      k('a', 'A', 'A', '#3dde8a', 0.88, 0.72, 0.08, 0.12),
      k('b', 'B', 'B', '#ff6b7a', 0.8, 0.8, 0.08, 0.12),
      k('x', 'X', 'X', '#5ba3ff', 0.8, 0.64, 0.08, 0.12),
      k('y', 'Y', 'Y', '#f0c14a', 0.72, 0.72, 0.08, 0.12),
      k('pause', 'START', '☰', '#c8d6ea', 0.48, 0.08, 0.06, 0.08, 'roundrect'),
    ]),
    builtin('action', 'Action / Adventure', [
      k('ls', 'STICK_L', '', '#5ec8ff', 0.13, 0.6, 0.15, 0.28, 'stick'),
      k('a', 'A', 'A', '#3dde8a', 0.86, 0.7, 0.09, 0.14),
      k('b', 'B', 'B', '#ff6b7a', 0.78, 0.8, 0.08, 0.12),
      k('x', 'X', 'X', '#5ba3ff', 0.78, 0.6, 0.08, 0.12),
      k('y', 'Y', 'Y', '#f0c14a', 0.7, 0.7, 0.08, 0.12),
      k('rt', 'RT', 'ATK', '#ff7a90', 0.84, 0.14, 0.12, 0.1, 'roundrect'),
      k('lt', 'LT', 'AIM', '#7aa2ff', 0.04, 0.14, 0.12, 0.1, 'roundrect'),
      k('pause', 'START', '☰', '#c8d6ea', 0.48, 0.08, 0.06, 0.08, 'roundrect'),
    ]),
    builtin('racing', 'Racing', [
      k('steer', 'STICK_L', '', '#5ec8ff', 0.14, 0.58, 0.18, 0.32, 'stick'),
      k('gas', 'RT', 'GAS', '#3dde8a', 0.78, 0.55, 0.16, 0.28, 'roundrect'),
      k('brake', 'LT', 'BRK', '#ff6b7a', 0.6, 0.62, 0.12, 0.2, 'roundrect'),
      k('nitro', 'A', 'N2O', '#f0c14a', 0.86, 0.22, 0.1, 0.12, 'roundrect'),
      k('look', 'STICK_R', '', '#ff8e5e', 0.72, 0.22, 0.12, 0.18, 'stick'),
      k('pause', 'START', '☰', '#c8d6ea', 0.48, 0.08, 0.06, 0.08, 'roundrect'),
    ]),
    builtin('rpg', 'RPG', [
      k('ls', 'STICK_L', '', '#5ec8ff', 0.13, 0.6, 0.15, 0.28, 'stick'),
      k('a', 'A', 'A', '#3dde8a', 0.86, 0.72, 0.08, 0.12),
      k('b', 'B', 'B', '#ff6b7a', 0.78, 0.8, 0.08, 0.12),
      k('x', 'X', 'X', '#5ba3ff', 0.78, 0.64, 0.08, 0.12),
      k('y', 'Y', 'Y', '#f0c14a', 0.7, 0.72, 0.08, 0.12),
      k('menu', 'START', 'MENU', '#c8d6ea', 0.88, 0.12, 0.1, 0.08, 'roundrect'),
      k('map', 'BACK', 'MAP', '#9ad0ff', 0.04, 0.12, 0.1, 0.08, 'roundrect'),
      k('lb', 'LB', 'LB', '#9ad0ff', 0.06, 0.28, 0.1, 0.08, 'roundrect'),
      k('rb', 'RB', 'RB', '#ffb08a', 0.84, 0.28, 0.1, 0.08, 'roundrect'),
    ]),
    builtin('strategy', 'Strategy / Cursor', [
      k('cursor', 'CURSOR', '🖱', '#eaf1ff', 0.5, 0.5, 0.08, 0.12),
      k('lmb', 'MOUSE_LEFT', 'LMB', '#3dde8a', 0.78, 0.72, 0.12, 0.12, 'roundrect'),
      k('rmb', 'MOUSE_RIGHT', 'RMB', '#ff6b7a', 0.9, 0.72, 0.08, 0.12, 'roundrect'),
      k('wasd', 'STICK_L', 'MOVE', '#5ec8ff', 0.12, 0.62, 0.16, 0.26, 'stick'),
      k('space', 'A', 'SPC', '#f0c14a', 0.42, 0.82, 0.16, 0.1, 'roundrect'),
      k('esc', 'START', 'ESC', '#c8d6ea', 0.06, 0.1, 0.08, 0.08, 'roundrect'),
    ]),
    builtin('platformer', 'Platformer', [
      k('ls', 'STICK_L', '', '#5ec8ff', 0.14, 0.62, 0.16, 0.28, 'stick'),
      k('a', 'A', 'JUMP', '#3dde8a', 0.82, 0.68, 0.12, 0.16, 'roundrect'),
      k('b', 'B', 'RUN', '#ff6b7a', 0.7, 0.76, 0.1, 0.12, 'roundrect'),
      k('x', 'X', 'ACT', '#5ba3ff', 0.88, 0.5, 0.08, 0.12),
      k('pause', 'START', '☰', '#c8d6ea', 0.48, 0.08, 0.06, 0.08, 'roundrect'),
    ]),
    builtin('sports', 'Sports / Cricket', [
      k('ls', 'STICK_L', '', '#5ec8ff', 0.14, 0.6, 0.15, 0.28, 'stick'),
      k('a', 'A', 'A', '#3dde8a', 0.86, 0.7, 0.09, 0.14),
      k('b', 'B', 'B', '#ff6b7a', 0.76, 0.8, 0.08, 0.12),
      k('x', 'X', 'X', '#5ba3ff', 0.76, 0.6, 0.08, 0.12),
      k('y', 'Y', 'Y', '#f0c14a', 0.68, 0.7, 0.08, 0.12),
      k('sprint', 'RT', 'RT', '#ff8e5e', 0.84, 0.14, 0.12, 0.1, 'roundrect'),
      k('lt', 'LT', 'LT', '#7aa2ff', 0.04, 0.14, 0.12, 0.1, 'roundrect'),
      k('pause', 'START', '☰', '#c8d6ea', 0.48, 0.08, 0.06, 0.08, 'roundrect'),
    ]),
    builtin('fighting', 'Fighting', [
      k('ls', 'STICK_L', '', '#5ec8ff', 0.14, 0.58, 0.16, 0.3, 'stick'),
      k('lp', 'X', 'LP', '#5ba3ff', 0.7, 0.58, 0.08, 0.12),
      k('hp', 'Y', 'HP', '#f0c14a', 0.8, 0.5, 0.08, 0.12),
      k('lk', 'A', 'LK', '#3dde8a', 0.8, 0.72, 0.08, 0.12),
      k('hk', 'B', 'HK', '#ff6b7a', 0.9, 0.64, 0.08, 0.12),
      k('pause', 'START', '☰', '#c8d6ea', 0.48, 0.08, 0.06, 0.08, 'roundrect'),
    ]),
    builtin('generic', 'Generic pad', [
      k('ls', 'STICK_L', '', '#5ec8ff', 0.14, 0.6, 0.15, 0.28, 'stick'),
      k('rs', 'STICK_R', '', '#ff8e5e', 0.72, 0.62, 0.12, 0.22, 'stick'),
      k('a', 'A', 'A', '#3dde8a', 0.88, 0.72, 0.08, 0.12),
      k('b', 'B', 'B', '#ff6b7a', 0.8, 0.8, 0.08, 0.12),
      k('x', 'X', 'X', '#5ba3ff', 0.8, 0.64, 0.08, 0.12),
      k('y', 'Y', 'Y', '#f0c14a', 0.72, 0.72, 0.08, 0.12),
      k('pause', 'START', '☰', '#c8d6ea', 0.48, 0.08, 0.06, 0.08, 'roundrect'),
    ]),
  ];
}

const DEFAULT_PREFS: GameLayoutPrefs = {
  layoutId: null,
  inputMode: 'auto',
  layoutsEnabled: true,
  preferLandscape: true,
};

export class LayoutStore {
  private customs: JsonStore<ControlLayout[]>;
  private prefs: JsonStore<Record<string, GameLayoutPrefs>>;

  constructor(private d: Dirs) {
    this.customs = new JsonStore(path.join(d.layouts, 'custom.json'), []);
    this.prefs = new JsonStore(path.join(d.layouts, 'prefs.json'), {});
  }

  list(): ControlLayout[] {
    const built = builtinLayouts();
    const custom = this.customs.load().filter(c => c && c.id && Array.isArray(c.keys));
    const byId = new Map<string, ControlLayout>();
    for (const b of built) byId.set(b.id, b);
    for (const c of custom) byId.set(c.id, { ...c, builtin: false });
    return [...byId.values()];
  }

  get(id: string): ControlLayout | null {
    return this.list().find(l => l.id === id) ?? null;
  }

  /** Save an edited layout (copies builtin → custom id if needed). */
  save(layout: ControlLayout): ControlLayout {
    const id = layout.builtin ? `${layout.kind}-custom` : layout.id;
    const next: ControlLayout = {
      ...layout,
      id,
      builtin: false,
      transparency: Math.min(0.85, Math.max(0.15, layout.transparency ?? 0.4)),
      keys: (layout.keys || []).slice(0, 24).map(normalizeKey),
      updatedAt: Date.now(),
    };
    const all = this.customs.load().filter(x => x.id !== next.id);
    all.push(next);
    this.customs.save(all);
    return next;
  }

  prefsFor(gameId: string): GameLayoutPrefs {
    const all = this.prefs.load();
    return { ...DEFAULT_PREFS, ...(all[gameId] || {}) };
  }

  setPrefs(gameId: string, patch: Partial<GameLayoutPrefs>) {
    const all = this.prefs.load();
    all[gameId] = { ...DEFAULT_PREFS, ...(all[gameId] || {}), ...patch };
    this.prefs.save(all);
    return all[gameId];
  }

  /**
   * Resolve what the phone should use for a game.
   * genres/description come from meta lookup when available.
   */
  resolveForGame(
    gameId: string,
    gameName: string,
    genres: string[] = [],
    description = '',
  ): {
    prefs: GameLayoutPrefs;
    kind: LayoutKind;
    layout: ControlLayout | null;
    inputMode: InputMode;
    autoLayout: boolean;
  } {
    const prefs = this.prefsFor(gameId);
    const kind = inferLayoutKind(gameName, genres, description);
    // Strong match only auto-selects a gamepad layout. Unknown apps (Firefox, tools) → no layout.
    const autoLayout = kind !== 'generic' || genres.some(g => /game|sport|action|rpg|shooter|racing/i.test(g));
    let layout: ControlLayout | null = null;
    const wantLayout = prefs.layoutsEnabled && (prefs.layoutId || autoLayout);
    if (wantLayout) {
      if (prefs.layoutId) layout = this.get(prefs.layoutId);
      if (!layout && autoLayout) layout = this.get(kind) || null;
      // Never force generic pad on unknown software unless user picked a layout id
      if (!layout && prefs.layoutId) layout = this.get('generic');
    }
    // Default input: touch only (cursor only if user chooses or strategy + auto)
    let inputMode: InputMode = prefs.inputMode;
    if (inputMode === 'auto') {
      inputMode = kind === 'strategy' && autoLayout ? 'cursor' : 'touch';
    }
    return { prefs, kind, layout, inputMode, autoLayout };
  }
}

function normalizeKey(k: LayoutKey): LayoutKey {
  return {
    id: String(k.id || 'k').slice(0, 32),
    action: String(k.action || 'A').slice(0, 32),
    label: String(k.label ?? '').slice(0, 8),
    color: /^#[0-9a-fA-F]{3,8}$/.test(k.color || '') ? k.color : '#eaf1ff',
    x: clamp01(k.x),
    y: clamp01(k.y),
    w: Math.min(0.4, Math.max(0.04, Number(k.w) || 0.1)),
    h: Math.min(0.4, Math.max(0.04, Number(k.h) || 0.1)),
    shape: k.shape === 'roundrect' || k.shape === 'stick' ? k.shape : 'circle',
    opacity: Math.min(0.9, Math.max(0.1, Number(k.opacity) || 0.35)),
  };
}
const clamp01 = (v: unknown) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : 0.5;
};

/** Host encode capability for the phone quality menu. */
export function resolutionCapabilities(opts: {
  encoder: string | null | undefined;
  width: number;
  height: number;
  maxBitrateKbps: number;
  rttMs?: number | null;
  lossPct?: number | null;
}): { id: string; label: string; width: number; height: number; supported: boolean; reason?: string }[] {
  const presets = [
    { id: '720p', label: '720p', width: 1280, height: 720, minKbps: 3000 },
    { id: '1080p', label: '1080p', width: 1920, height: 1080, minKbps: 6000 },
    { id: '1440p', label: '1440p', width: 2560, height: 1440, minKbps: 12000 },
  ];
  const soft = !opts.encoder || opts.encoder === 'none' || opts.encoder === 'x264';
  const netBad = (opts.rttMs != null && opts.rttMs > 80) || (opts.lossPct != null && opts.lossPct > 5);
  return presets.map(p => {
    let supported = true;
    let reason: string | undefined;
    if (opts.maxBitrateKbps < p.minKbps) {
      supported = false;
      reason = 'Bitrate limit too low';
    } else if (p.height >= 1440 && soft) {
      supported = false;
      reason = 'Needs hardware encoder (NVENC/QSV/AMF)';
    } else if (p.height >= 1440 && netBad) {
      supported = false;
      reason = 'Network too slow/lossy right now';
    }
    return { id: p.id, label: p.label, width: p.width, height: p.height, supported, reason };
  });
}
