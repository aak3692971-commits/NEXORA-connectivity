export interface LinkStats { lossPct: number; rttMs: number }
/** Picks a video bitrate from the phone's reported loss/RTT. Steps down fast, up slowly, never outside [min,max]. */
export class AdaptiveBitrate {
  private tiers: number[]; private idx: number; private lastChange = 0; private goodSince = 0;
  constructor(min: number, max: number, start: number, private downCooldownMs = 8000, private upAfterMs = 15000) {
    const all = [2500, 4000, 6000, 8000, 10000, 12000, 16000, 20000];
    this.tiers = [...new Set([min, ...all.filter(t => t > min && t < max), max])].sort((a, b) => a - b);
    this.idx = this.tiers.reduce((best, t, i) => Math.abs(t - start) < Math.abs(this.tiers[best]! - start) ? i : best, 0);
  }
  get bitrate() { return this.tiers[this.idx]!; }
  /** Feed one stats report (about every 2 s). Returns the new bitrate when it should change, else null. */
  feed(s: LinkStats, now: number): number | null {
    const bad = s.lossPct > 3 || s.rttMs > 150, good = s.lossPct < .5 && s.rttMs < 60;
    if (!good) this.goodSince = 0; else if (!this.goodSince) this.goodSince = now;
    if (bad && this.idx > 0 && now - this.lastChange >= this.downCooldownMs) { this.idx--; this.lastChange = now; this.goodSince = 0; return this.bitrate; }
    if (good && this.goodSince && now - this.goodSince >= this.upAfterMs && now - this.lastChange >= this.upAfterMs && this.idx < this.tiers.length - 1) { this.idx++; this.lastChange = now; this.goodSince = now; return this.bitrate; }
    return null;
  }
}
