import path from 'node:path'; import { Patcher } from './patcher.js'; import { spawn } from 'node:child_process'; import { randomBytes } from 'node:crypto';
import { dirs, type Dirs } from './paths.js'; import { loadConfig, saveConfigPatch, type Config } from './config.js'; import { Logger } from './logger.js';
import { loadIdentity, type Identity } from './identity.js'; import { GameLibrary, type GameProfile } from './library.js';
import { MetaStore, cleanName, type Fetcher } from './meta.js'; import { HostSignaling, type PairRequest, type Paired } from './signaling.js';
import { Capture, pickEncoder, listAudioDevices, hasFilter, type Encoder } from './capture.js'; import { InputMapper, type OsInput } from './inputmap.js';
import { StreamSession, type PeerFactory } from './stream.js'; import { AdaptiveBitrate } from './adaptive.js';
import type { Spawner } from './library.js'; import type { QualityRequest } from './session.js'; import { SysMetrics } from './sysmetrics.js'; import os from 'node:os'; import { startSignalingServer } from './server/signaling-server.js'; import { RemoteAccess } from './remote.js'; import { LayoutStore, resolutionCapabilities } from './layouts.js';

export interface AppOptions {
  /** Folder the app runs from (portable/dev layout) so it can update itself from a zip; undefined when installed. */ appRoot?: string; restart?: () => void;
  root?: string; fetcher?: Fetcher; WS?: new (u: string) => any; makePeer?: PeerFactory; osInput?: OsInput; spawner?: Spawner;
  encoder?: Encoder | null; signalingMode?: 'local' | 'remote'; echo?: boolean; remote?: boolean; env?: Record<string, string | undefined>; pairTimeoutMs?: number; captureOverrides?: { videoInput?: string[]; audioInput?: string[] };
}
const PAIR_TIMEOUT_MS = 60_000;

/** Everything the host does, with no UI attached. The web UI (ui.ts) and main.ts only call this class. */
/** Turns up to ~20 minutes of samples into column arrays of at most 120 points, plus the time they cover. */
function series<T extends { t: number }, K extends string>(rows: T[], pick: (r: T) => Record<K, number>): Record<K, number[]> & { spanSec: number } {
  const step = Math.max(1, Math.ceil(rows.length / 120)), out: any = { spanSec: rows.length > 1 ? Math.round((rows[rows.length - 1]!.t - rows[0]!.t) / 1000) : 0 };
  for (let i = 0; i < rows.length; i += step) for (const [k, v] of Object.entries(pick(rows[i]!))) (out[k] ??= []).push(v);
  for (const k of Object.keys(pick({ t: 0, cpu: 0, gpu: 0, ram: 0, kbps: 0, rtt: 0 } as any))) out[k] ??= [];
  return out;
}
export class HostApp {
  readonly d: Dirs; readonly cfg: Config; readonly log: Logger; readonly id: Identity; readonly lib: GameLibrary; readonly meta: MetaStore; readonly sig: HostSignaling; readonly layouts: LayoutStore; readonly patcher: Patcher;
  readonly uiToken = randomBytes(16).toString('hex');
  encoder: Encoder | null | undefined = undefined;          // undefined = still probing
  private pin: { pin: string; expiresAt: number } | null = null; private status = 'disconnected';
  private pairs = new Map<string, { req: PairRequest; resolve: (ok: boolean) => void; expiresAt: number }>();
  private stream?: StreamSession; private adaptive?: AdaptiveBitrate; private lastStats?: { rttMs: number; lossPct: number; fps: number; bitrateKbps: number };
  private metaState = new Map<string, 'searching' | 'found' | 'none'>(); private encoderReady: Promise<void>; private audioDevices: string[] = [];
  private autoBitrate = false; readonly metrics = new SysMetrics(); private net: { t: number; rtt: number; kbps: number; fps: number }[] = []; private startedAt = Date.now();
  private remote?: RemoteAccess; private effCapture: 'ddagrab' | 'gdigrab'; private lastError: string | null = null; private server?: { port: number; close(): Promise<void>; onlineClients?(): string[] }; private serverPort = 0;

  constructor(private o: AppOptions = {}) {
    this.d = dirs(o.root); this.patcher = new Patcher(o.appRoot ?? null, path.join(this.d.root, 'backups')); this.cfg = loadConfig(this.d, o.env); this.log = new Logger(this.d, 7, o.echo);
    this.effCapture = this.cfg.capture; this.id = loadIdentity(this.d); this.lib = new GameLibrary(this.d, o.spawner);
    this.meta = new MetaStore(this.d, o.fetcher, { rawgKey: this.cfg.rawgKey, enabled: this.cfg.lookupGameInfo });
    this.layouts = new LayoutStore(this.d);
    this.sig = new HostSignaling(this.id, this.d, this.cfg.signalingUrl, {
      onPin: (pin, ttl) => { this.pin = { pin, expiresAt: Date.now() + ttl * 1000 }; },
      onPairRequest: r => this.askPair(r),
      onSession: (p, sid) => { this.sig.touch(p.id); void this.startSession(p, sid); },
      onSignal: (p, m) => { if (this.stream?.peerId === p.id) this.stream.onSignal(m); },
      onStatus: s => { this.status = s; this.log.log('signaling', { s }); },
    }, this.cfg.hostName, o.WS as any);
    this.encoderReady = o.encoder !== undefined ? Promise.resolve().then(() => { this.encoder = o.encoder!; }) : this.probe();
  }
  private async probe() {
    this.encoder = await pickEncoder(this.cfg.ffmpegPath, this.cfg.encoder);
    this.log.log('encoder', { encoder: this.encoder ?? 'none' });
    if (!this.encoder) this.lastError = 'ffmpeg was not found or cannot encode video. Put ffmpeg.exe next to the host or set ffmpegPath in config/config.json.';
    else if (process.platform === 'win32') {
      this.audioDevices = await listAudioDevices(this.cfg.ffmpegPath);
      if (this.cfg.capture === 'ddagrab' && !(await hasFilter(this.cfg.ffmpegPath, 'ddagrab'))) { this.effCapture = 'gdigrab'; this.log.log('capture_fallback', { to: 'gdigrab', why: 'this ffmpeg has no ddagrab (needs 6.0+)' }); }
    }
  }
  /** Native pieces are loaded after construction (they may be missing); the host still runs without them and says what is missing. */
  setBindings(b: { makePeer?: PeerFactory; osInput?: OsInput }) { if (b.makePeer) this.o.makePeer = b.makePeer; if (b.osInput) this.o.osInput = b.osInput; }
  get mode() { return this.o.signalingMode ?? this.cfg.signalingMode; }
  /** Addresses a phone on the same network can type in. */
  phoneAddresses(): string[] {
    if (this.mode !== 'local' || !this.serverPort) return [];
    // Skip virtual adapters (VirtualBox, VMware, WSL, Hyper-V, Docker ...): their addresses are not reachable from a phone and used to be listed first.
    const VIRTUAL = /virtual|vmware|vbox|hyper-v|vethernet|wsl|docker|loopback|bluetooth|pseudo|npcap/i;
    const collect = (skipVirtual: boolean) => { const o: string[] = []; for (const [name, list] of Object.entries(os.networkInterfaces())) { if (skipVirtual && VIRTUAL.test(name)) continue; for (const a of list ?? []) if (a.family === 'IPv4' && !a.internal && !a.address.startsWith('169.254.')) o.push(a.address); } return o; };
    const out = collect(true).length ? collect(true) : collect(false);
    const rank = (a: string) => (a.startsWith('192.168.56.') || a.startsWith('192.168.99.') ? 6 : a.startsWith('192.168.') ? 0 : a.startsWith('10.') ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(a) ? 2 : /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(a) ? 4 : 3);   // 100.64/10 = Tailscale-style VPN: valid, but a normal LAN address is preferred
    return [...new Set(out)].sort((x, y) => rank(x) - rank(y)).map(a => `${a}:${this.serverPort}`);
  }
  /** Windows treats a Wi-Fi marked "Public" as hostile and drops the phone's connection even when the firewall rule exists. Tell the user instead of failing silently. */
  private async checkNetworkProfile() {
    if (process.platform !== 'win32' || this.mode !== 'local') return;
    const out = await new Promise<string>(res => { let o = ''; try { const c = spawn('powershell.exe', ['-NoProfile', '-Command', "(Get-NetConnectionProfile | Where-Object { $_.IPv4Connectivity -ne 'Disconnected' } | ForEach-Object { [string]$_.NetworkCategory }) -join ','"], { windowsHide: true }); const t = setTimeout(() => { try { c.kill(); } catch { /* gone */ } res(o); }, 8000); c.stdout?.on('data', d => (o += d)); c.once('error', () => { clearTimeout(t); res(''); }); c.once('exit', () => { clearTimeout(t); res(o); }); } catch { res(''); } });
    this.log.log('network_profile', { categories: out.trim() });
    if (/public/i.test(out) && !/private|domainauthenticated/i.test(out) && !this.lastError) this.warn('Windows has this network set to "Public", which blocks your phone. Open Settings > Network & internet > Wi-Fi > your network > Network profile type > Private.');
  }
  /** Starts the built-in signaling server (default) and connects to it, or connects to the remote server from config. */
  async start() {
    if (this.mode === 'local') {
      try { this.server = await startSignalingServer({ port: this.cfg.serverPort, pinTtlSec: 300, log: this.log.log, info: () => ({ name: this.cfg.hostName, deviceId: this.id.deviceId, publicKey: this.id.publicKey, port: this.serverPort, addresses: this.connectAddresses() }) }); }
      catch (e: any) {
        // Never silently pick another port: the phone remembers this one.
        this.lastError = e?.code === 'EADDRINUSE' ? `Port ${this.cfg.serverPort} is already in use. Is NEXORA Host already running? Close the other window, or change serverPort in config/config.json.` : 'Could not start the pairing server: ' + String(e?.message ?? e).slice(0, 120);
        this.log.log('server_failed', { code: e?.code }); return;
      }
      this.serverPort = this.server.port; this.sig.setUrl(`ws://127.0.0.1:${this.server.port}/api/ws`); this.log.log('server_started', { port: this.serverPort });
      if (this.o.remote && this.cfg.remoteAccess) { this.remote = new RemoteAccess({ tcpPort: this.serverPort, log: this.log.log }); void this.remote.start().catch(() => {}); }
    }
    this.metrics.start(); this.sig.connect(); void this.checkNetworkProfile().catch(() => {});
  }
  /** Everything a phone can try, same-network addresses first, then the public one (when the router was opened). */
  connectAddresses(): string[] { const pub = this.remote?.address; return [...this.phoneAddresses(), ...(pub ? [pub] : [])]; }
  stop() { void this.remote?.stop().catch(() => {}); this.metrics.stop(); this.stream?.end('host stopped'); this.sig.close(); void this.server?.close(); this.server = undefined; for (const p of this.pairs.values()) p.resolve(false); }
  ready() { return this.encoderReady; }
  /** Shown in the control panel until the next session starts fine. */
  warn(msg: string) { this.lastError = msg; }

  // ---- pairing ----
  openPairing() { this.pin = null; this.sig.openPairing(); }
  private askPair(r: PairRequest): Promise<boolean> {
    return new Promise(resolve => {
      const expiresAt = Date.now() + (this.o.pairTimeoutMs ?? PAIR_TIMEOUT_MS); this.pairs.set(r.clientId, { req: r, resolve, expiresAt });
      this.log.log('pair_request', { name: r.clientName });
      const t = setTimeout(() => this.answerPair(r.clientId, false), this.o.pairTimeoutMs ?? PAIR_TIMEOUT_MS); (t as any).unref?.();
    });
  }
  answerPair(clientId: string, allow: boolean) { const p = this.pairs.get(clientId); if (!p) return false; this.pairs.delete(clientId); p.resolve(allow); this.pin = null; this.log.log(allow ? 'pair_approved' : 'pair_declined', { name: p.req.clientName }); return true; }
  revoke(id: string) { if (this.stream?.peerId === id) this.stream.end('revoked'); this.sig.revoke(id); this.log.log('device_revoked'); }

  // ---- games + info lookup ----
  async addGame(p: { name?: string; exe: string; cwd?: string }): Promise<GameProfile> {
    const g = this.lib.add({ name: p.name?.trim() || cleanName(path.basename(p.exe)), exe: p.exe, cwd: p.cwd });
    this.log.log('game_added', { name: g.name }); void this.lookupMeta(g.id, g.name); return g;
  }
  /** Looks the game up on the internet (cover + description). Never throws; the status shows in the UI. */
  async lookupMeta(id: string, name: string) {
    this.metaState.set(id, 'searching');
    const m = await this.meta.lookup(id, name).catch(() => null);
    const suggestions = this.meta.suggestions(id);
    this.metaState.set(id, m ? 'found' : suggestions.length ? 'ambiguous' : 'none');
    this.log.log('game_info', { name, found: !!m, ambiguous: suggestions.length > 0, source: m?.source });
    return m;
  }
  async chooseMeta(id: string, index: number) {
    const m = await this.meta.chooseSuggestion(id, index);
    this.metaState.set(id, m ? 'found' : 'none');
    this.log.log('game_info_selected', { source: m?.source, found: !!m });
    return m;
  }
  renameGame(id: string, name: string) { this.lib.rename(id, name); void this.lookupMeta(id, name.trim()); }
  removeGame(id: string) { if (this.lib.isRunning(id)) this.lib.stop(id); this.lib.remove(id); this.meta.remove(id); this.metaState.delete(id); }
  refreshMeta(id: string) { const g = this.lib.list().find(x => x.id === id); if (!g) throw new Error('Game not found'); return this.lookupMeta(id, g.name); }

  // ---- streaming ----
  private async startSession(peer: Paired, sessionId: string) {
    this.stream?.end('replaced by a new session');
    await this.encoderReady;
    if (!this.encoder) { this.sig.sendSession({ t: 'signal', to: peer.id, sessionId, kind: 'bye', data: 'no encoder' }); this.log.log('session_refused', { why: 'no encoder' }); return; }
    if (!this.o.makePeer) { this.log.log('session_refused', { why: 'no WebRTC binding' }); this.lastError = 'The WebRTC component (node-datachannel) is not installed. Run "npm install" next to the host.'; this.sig.sendSession({ t: 'signal', to: peer.id, sessionId, kind: 'bye', data: 'host not ready' }); return; }
    const cap = new Capture({ ...this.cfg, capture: this.effCapture }, this.encoder, this.log.log, this.o.spawner as any, this.o.captureOverrides ?? {}, why => { this.lastError = why; this.stream?.end('capture failed'); });
    const mapper = new InputMapper(this.o.osInput ?? { key() {}, mouseMove() {}, mouseButton() {} });
    this.adaptive = new AdaptiveBitrate(this.cfg.minBitrateKbps, this.cfg.maxBitrateKbps, this.cfg.bitrateKbps); this.autoBitrate = this.cfg.adaptiveBitrate;
    const s: StreamSession = this.stream = new StreamSession({
      out: this.sig, peer, sessionId, makePeer: this.o.makePeer, media: cap, quality: this.qualityFor(cap), hostInfo: () => this.hostInfo(), lib: this.lib, meta: this.meta, sink: mapper, log: this.log.log,
      onEnd: why => { this.log.log('session_end', { why }); if (this.stream === s) { this.stream = undefined; this.lastStats = undefined; } },
      onLaunch: id => this.layoutPayload(id), onStats: st => { this.lastStats = st; this.net.push({ t: Date.now(), rtt: st.rttMs, kbps: st.bitrateKbps, fps: st.fps }); if (this.net.length > 620) this.net.shift(); if (this.autoBitrate) { const nb = this.adaptive?.feed(st, Date.now()); if (nb) { this.log.log('bitrate', { kbps: nb }); cap.setBitrate(nb); } } },
    });
    this.lastError = null; this.log.log('session_start', { peer: peer.name }); s.start();
  }
  /** The phone's quality menu: translates a request into capture settings for this session only (nothing is written to config). */
  private qualityFor(cap: Capture) {
    const SIZE = { '720p': [1280, 720], '1080p': [1920, 1080], '1440p': [2560, 1440] } as const;
    const current = () => { const q = cap.quality; const label = q.height >= 1440 ? '1440p' : q.height >= 1080 ? '1080p' : '720p'; return { preset: label, width: q.width, height: q.height, fps: q.fps, kbps: q.kbps, auto: this.autoBitrate }; };
    return { current, apply: (r: QualityRequest) => {
      const patch: { width?: number; height?: number; fps?: number; kbps?: number } = {};
      if (r.preset) { [patch.width, patch.height] = SIZE[r.preset]; }
      if (r.fps) patch.fps = r.fps;
      if (r.bitrate === 'auto') { this.autoBitrate = true; this.adaptive = new AdaptiveBitrate(this.cfg.minBitrateKbps, this.cfg.maxBitrateKbps, cap.quality.kbps); }
      else if (typeof r.bitrate === 'number') { this.autoBitrate = false; patch.kbps = r.bitrate; }
      cap.setQuality(patch); return current();
    } };
  }
  /** PC facts shown on the phone's "PC Host" screen. */
  private hostInfo() { const m = this.metrics.read(); return { name: this.cfg.hostName, os: process.platform === 'win32' ? os.version() : `${os.type()} ${os.release()}`, cpu: m.cpuPct, cpuGhz: m.cpuGhz, gpu: m.gpuPct, gpuName: m.gpuName, gpuUsedGb: m.gpuUsedGb, gpuTotalGb: m.gpuTotalGb, ram: m.ramPct, ramUsedGb: m.ramUsedGb, ramTotalGb: m.ramTotalGb, encoder: this.encoder ?? null }; }
  endSession() { this.stream?.end('stopped from the PC'); }

  snapshot() {
    const now = Date.now(), online = new Set(this.server?.onlineClients?.() ?? []), games = this.lib.list();
    const ip = this.phoneAddresses()[0]?.split(':')[0] ?? null;
    return {
      host: { name: this.cfg.hostName, deviceId: this.id.deviceId, signaling: this.status, mode: this.mode, phoneAddresses: this.phoneAddresses(), ip, uptimeSec: Math.round(os.uptime()), platform: process.platform === 'win32' ? os.version() : `${os.type()} ${os.release()}`, appUptimeSec: Math.round((now - this.startedAt) / 1000), version: this.version, server: this.cfg.signalingUrl.replace(/^wss?:\/\//, '').split('/')[0] },
      connection: { signaling: this.status === 'connected', lan: this.mode === 'local' ? this.serverPort > 0 && !!ip : null, webrtc: !!this.o.makePeer && !!this.encoder, relay: this.cfg.turnUrls.length > 0 && !!this.cfg.turnUser ? 'configured' : 'not needed on Wi-Fi' },
      remote: { enabled: this.cfg.remoteAccess && this.mode === 'local', state: this.remote?.state ?? 'off', address: this.remote?.address ?? null, detail: this.remote?.detail ?? (this.cfg.remoteAccess ? 'Starting…' : 'Remote access is off.') },
      qr: this.pin && this.pin.expiresAt > now && this.phoneAddresses()[0] ? `nexora://pair?a=${this.phoneAddresses()[0]}&p=${this.pin.pin}` : null,
      pin: this.pin && this.pin.expiresAt > now ? { pin: this.pin.pin, secondsLeft: Math.round((this.pin.expiresAt - now) / 1000) } : null,
      pairRequests: [...this.pairs.values()].map(p => ({ clientId: p.req.clientId, name: p.req.clientName, secondsLeft: Math.max(0, Math.round((p.expiresAt - now) / 1000)) })),
      paired: this.sig.pairedList().map(p => ({ id: p.id, name: p.name, pairedAt: p.pairedAt, lastSeen: p.lastSeen ?? null, online: online.has(p.id) || this.stream?.peerId === p.id, streaming: this.stream?.peerId === p.id })),
      games: games.map(g => {
        const m = this.meta.get(g.id);
        const resolved = this.layouts.resolveForGame(g.id, g.name, m?.genres ?? [], m?.description ?? '');
        return {
          id: g.id, name: g.name, lastPlayed: g.lastPlayed ?? null, playMs: g.playMs ?? 0, running: this.lib.isRunning(g.id),
          info: this.metaState.get(g.id) ?? (m ? 'found' : 'none'), description: m?.description ?? '', source: m?.source ?? null,
          hasCover: !!m?.hasCover, rev: m?.rev ?? 0, genres: m?.genres ?? [],
          developer: m?.developer ?? '', publisher: m?.publisher ?? '', releaseDate: m?.releaseDate ?? '',
          platforms: m?.platforms ?? [], screenshots: m?.screenshots ?? [], url: m?.url ?? '',
          platformIds: m?.platformIds ?? {}, confidence: m?.confidence ?? null, suggestions: this.meta.suggestions(g.id),
          layoutKind: resolved.kind, layoutId: resolved.layout?.id ?? null, inputMode: resolved.inputMode,
          layoutsEnabled: resolved.prefs.layoutsEnabled && !!resolved.layout, preferLandscape: resolved.prefs.preferLandscape, autoLayout: resolved.autoLayout,
        };
      }),
      totalPlayMs: games.reduce((a, g) => a + (g.playMs ?? 0), 0),
      stream: this.stream ? { state: this.stream.state, peerId: this.stream.peerId, stats: this.lastStats ?? null, bitrateKbps: this.adaptive?.bitrate ?? this.cfg.bitrateKbps } : null,
      video: { capture: this.effCapture, relay: this.cfg.turnUrls.length > 0 && !!this.cfg.turnUser, encoder: this.encoder === undefined ? 'checking…' : this.encoder ?? 'none', size: `${this.cfg.width}×${this.cfg.height} @ ${this.cfg.fps}`, width: this.cfg.width, height: this.cfg.height, fps: this.cfg.fps, kbps: this.cfg.bitrateKbps, adaptive: this.cfg.adaptiveBitrate },
      audio: { device: this.cfg.audioDevice, devices: this.audioDevices },
      metrics: this.metrics.read(), history: series(this.metrics.history, h => ({ cpu: h.cpu, gpu: h.gpu, ram: h.ram })), net: series(this.net, n => ({ kbps: n.kbps, rtt: n.rtt })),
      settings: { lookupGameInfo: this.cfg.lookupGameInfo, hostName: this.cfg.hostName, encoder: this.cfg.encoder, width: this.cfg.width, height: this.cfg.height, fps: this.cfg.fps, bitrateKbps: this.cfg.bitrateKbps, adaptiveBitrate: this.cfg.adaptiveBitrate },
      capabilities: resolutionCapabilities({
        encoder: this.encoder === undefined ? null : this.encoder,
        width: this.cfg.width, height: this.cfg.height, maxBitrateKbps: this.cfg.maxBitrateKbps,
        rttMs: this.lastStats?.rttMs ?? null, lossPct: this.lastStats?.lossPct ?? null,
      }),
      layoutCatalog: this.layouts.list().map(l => ({ id: l.id, name: l.name, kind: l.kind, builtin: l.builtin, keyCount: l.keys.length, transparency: l.transparency })),
      error: this.lastError, logs: this.log.recent(80),
    };
  }
  version = '1.0.0';
  /** Applies a validated subset of settings. Video settings take effect on the next stream; the host name after a restart. */
  updateSettings(p: Record<string, unknown>) {
    const allowed = ['remoteAccess', 'hostName', 'encoder', 'width', 'height', 'fps', 'bitrateKbps', 'adaptiveBitrate', 'lookupGameInfo'] as const;
    const patch: Record<string, unknown> = {}; for (const k of allowed) if (k in p) patch[k] = p[k];
    saveConfigPatch(this.d, patch as Partial<Config>);
    const fresh = loadConfig(this.d, this.o.env); const encChanged = fresh.encoder !== this.cfg.encoder;
    Object.assign(this.cfg as Config, { hostName: fresh.hostName, encoder: fresh.encoder, width: fresh.width, height: fresh.height, fps: fresh.fps, bitrateKbps: fresh.bitrateKbps, adaptiveBitrate: fresh.adaptiveBitrate, lookupGameInfo: fresh.lookupGameInfo });
    this.meta.setEnabled?.(fresh.lookupGameInfo);
    this.adaptive = undefined; if (encChanged) { this.encoder = undefined; this.encoderReady = this.probe(); }
    this.log.log('settings_saved', { keys: Object.keys(patch).join(',') });
  }
  setAudioDevice(name: string | null) { (this.cfg as Config).audioDevice = name; saveConfigPatch(this.d, { audioDevice: name }); }
  /** Native file picker on Windows (PowerShell OpenFileDialog). Resolves with the chosen .exe path or null. */
  openGameLocation(gameId: string) {
    const g = this.lib.list().find(x => x.id === gameId);
    if (!g) throw new Error('Game not found');
    if (process.platform !== 'win32') throw new Error('Explorer location is only available on Windows.');
    const exe = path.resolve(g.exe);
    spawn('explorer.exe', ['/select,', exe], { windowsHide: true, detached: true, stdio: 'ignore' }).unref();
  }
  setGameLayout(gameId: string, patch: { layoutId?: string | null; inputMode?: 'touch' | 'cursor' | 'auto'; layoutsEnabled?: boolean; preferLandscape?: boolean }) {
    if (!this.lib.list().some(g => g.id === gameId)) throw new Error('Game not found');
    return this.layouts.setPrefs(gameId, patch);
  }
  saveLayout(layout: any) { return this.layouts.save(layout); }
  /** Payload the phone uses when a game is launched / session opens. */
  layoutPayload(gameId: string) {
    const g = this.lib.list().find(x => x.id === gameId);
    if (!g) return null;
    const m = this.meta.get(gameId);
    const r = this.layouts.resolveForGame(gameId, g.name, m?.genres ?? [], m?.description ?? '');
    return {
      type: 'layout.offer' as const,
      gameId,
      gameName: g.name,
      kind: r.kind,
      inputMode: r.inputMode,
      layoutsEnabled: r.prefs.layoutsEnabled,
      preferLandscape: r.prefs.preferLandscape !== false,
      preferOrientation: 'landscape' as const,
      layout: r.layout,
      capabilities: resolutionCapabilities({
        encoder: this.encoder === undefined ? null : this.encoder,
        width: this.cfg.width, height: this.cfg.height, maxBitrateKbps: this.cfg.maxBitrateKbps,
        rttMs: this.lastStats?.rttMs ?? null, lossPct: this.lastStats?.lossPct ?? null,
      }),
    };
  }
  /** Windows file/folder picker for the update screen when the Electron dialog is not available. */
  pickPath(kind: 'zip' | 'folder'): Promise<string | null> {
    if (process.platform !== 'win32') return Promise.reject(new Error('The picker is only available on Windows.'));
    const ps = "Add-Type -AssemblyName System.Windows.Forms; " + (kind === 'zip' ? "$f=New-Object System.Windows.Forms.OpenFileDialog; $f.Filter='Zip files (*.zip)|*.zip'; if($f.ShowDialog() -eq 'OK'){[Console]::Out.Write($f.FileName)}" : "$f=New-Object System.Windows.Forms.FolderBrowserDialog; if($f.ShowDialog() -eq 'OK'){[Console]::Out.Write($f.SelectedPath)}");
    return new Promise((res, rej) => { let out = ''; const c = spawn('powershell.exe', ['-NoProfile', '-STA', '-Command', ps], { windowsHide: false }); c.stdout.on('data', d => (out += d)); c.once('error', rej); c.once('exit', () => res(out.trim() || null)); });
  }
  /** Restarts the app after an update (only when a shell provided a restart hook). */
  restartApp(): boolean { if (!this.o.restart) return false; setTimeout(() => this.o.restart!(), 300); return true; }
  pickExe(): Promise<string | null> {
    if (process.platform !== 'win32') return Promise.reject(new Error('File picker is only available on Windows. Type the path instead.'));
    const ps = "Add-Type -AssemblyName System.Windows.Forms; $f=New-Object System.Windows.Forms.OpenFileDialog; $f.Filter='Games (*.exe)|*.exe'; if($f.ShowDialog() -eq 'OK'){[Console]::Out.Write($f.FileName)}";
    return new Promise((res, rej) => { let out = ''; const c = spawn('powershell.exe', ['-NoProfile', '-STA', '-Command', ps], { windowsHide: false }); c.stdout.on('data', d => (out += d)); c.once('error', rej); c.once('exit', () => res(out.trim() || null)); });
  }
}
