import fs from 'node:fs'; import path from 'node:path';
/** Portable layout: everything lives next to the app (or NEXORA_HOME). No registry, no %AppData%. */
export function dirs(root = process.env.NEXORA_HOME || process.cwd()) {
  const d = Object.fromEntries(['config','games','layouts','logs','cache','data'].map(n => [n, path.join(root, n)])) as Record<'config'|'games'|'layouts'|'logs'|'cache'|'data', string>;
  for (const p of Object.values(d)) fs.mkdirSync(p, { recursive: true });
  return { root, ...d };
}
export type Dirs = ReturnType<typeof dirs>;
