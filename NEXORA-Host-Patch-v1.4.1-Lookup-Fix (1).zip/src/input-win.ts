import type { OsInput } from './inputmap.js';

/** Windows keyboard + mouse injection through user32!SendInput (via koffi FFI). Hardware scancodes are used because many games ignore virtual-key events.
 *  NOT TESTABLE in the Linux sandbox this was written in: verify on a real Windows PC. Run the host as Administrator if the game itself runs elevated. */
const SC: Record<string, [number, boolean]> = {   // [scancode, extended]
  ESC: [0x01, false], TAB: [0x0f, false], ENTER: [0x1c, false], SPACE: [0x39, false], SHIFT: [0x2a, false], CTRL: [0x1d, false], ALT: [0x38, false],
  Q: [0x10, false], W: [0x11, false], E: [0x12, false], R: [0x13, false], T: [0x14, false], Y: [0x15, false], U: [0x16, false], I: [0x17, false], O: [0x18, false], P: [0x19, false],
  A: [0x1e, false], S: [0x1f, false], D: [0x20, false], F: [0x21, false], G: [0x22, false], H: [0x23, false], J: [0x24, false], K: [0x25, false], L: [0x26, false],
  Z: [0x2c, false], X: [0x2d, false], C: [0x2e, false], V: [0x2f, false], B: [0x30, false], N: [0x31, false], M: [0x32, false],
  '1': [0x02, false], '2': [0x03, false], '3': [0x04, false], '4': [0x05, false], '5': [0x06, false], '6': [0x07, false], '7': [0x08, false], '8': [0x09, false], '9': [0x0a, false], '0': [0x0b, false],
  UP: [0x48, true], DOWN: [0x50, true], LEFT: [0x4b, true], RIGHT: [0x4d, true],
  BACKSPACE: [0x0e, false], DELETE: [0x53, true], F1: [0x3b, false], F2: [0x3c, false], F3: [0x3d, false], F4: [0x3e, false], F5: [0x3f, false], F6: [0x40, false], F7: [0x41, false], F8: [0x42, false], F9: [0x43, false], F10: [0x44, false], F11: [0x57, false], F12: [0x58, false],
};
export const supportedKeys = () => Object.keys(SC);

export async function createWindowsInput(log: (e: string, f?: object) => void = () => {}): Promise<OsInput> {
  const koffi = (await import('koffi')).default;
  const user32 = koffi.load('user32.dll');
  const MOUSEINPUT = koffi.struct('MOUSEINPUT', { dx: 'int32', dy: 'int32', mouseData: 'uint32', dwFlags: 'uint32', time: 'uint32', dwExtraInfo: 'uintptr' });
  const KEYBDINPUT = koffi.struct('KEYBDINPUT', { wVk: 'uint16', wScan: 'uint16', dwFlags: 'uint32', time: 'uint32', dwExtraInfo: 'uintptr' });
  // Win32 INPUT = { DWORD type; union { MOUSEINPUT mi; KEYBDINPUT ki; HARDWAREINPUT hi; } } -> 40 bytes on x64 (the union is 32 bytes, 8-aligned).
  const INPUT_U = koffi.union('INPUT_U', { mi: MOUSEINPUT, ki: KEYBDINPUT });
  const INPUT = koffi.struct('INPUT', { type: 'uint32', u: INPUT_U });
  const SIZE = koffi.sizeof(INPUT);
  if (SIZE !== 40 && SIZE !== 28) throw new Error('Unexpected INPUT struct size ' + SIZE);   // 40 = 64-bit Windows, 28 = 32-bit
  const SendInput = user32.func('uint32 __stdcall SendInput(uint32 cInputs, INPUT *pInputs, int cbSize)');
  const sendKb = (ki: object) => SendInput(1, { type: 1, u: { ki } }, SIZE);
  const sendMi = (mi: object) => SendInput(1, { type: 0, u: { mi } }, SIZE);
  const KEYUP = 0x2, SCAN = 0x8, EXT = 0x1;
  const MOVE = 0x1, LDOWN = 0x2, LUP = 0x4, RDOWN = 0x8, RUP = 0x10;
  const warned = new Set<string>();
  return {
    key(name, down) {
      const sc = SC[name]; if (!sc) { if (!warned.has(name)) { warned.add(name); log('input_unknown_key', { name }); } return; }
      if (sendKb({ wVk: 0, wScan: sc[0], dwFlags: SCAN | (sc[1] ? EXT : 0) | (down ? 0 : KEYUP), time: 0, dwExtraInfo: 0 }) !== 1) log('input_send_failed', { kind: 'key' });
    },
    mouseMove(dx, dy) { if (!dx && !dy) return; if (sendMi({ dx, dy, mouseData: 0, dwFlags: MOVE, time: 0, dwExtraInfo: 0 }) !== 1) log('input_send_failed', { kind: 'mouse' }); },
    mouseButton(b, down) { const f = b === 'left' ? (down ? LDOWN : LUP) : (down ? RDOWN : RUP); sendMi({ dx: 0, dy: 0, mouseData: 0, dwFlags: f, time: 0, dwExtraInfo: 0 }); },
  };
}
/** Dev/CI backend for non-Windows machines: records instead of injecting. */
export function createLogInput(log: (e: string, f?: object) => void): OsInput {
  return { key: (name, down) => log('os_key', { name, down }), mouseMove: (dx, dy) => log('os_mouse', { dx, dy }), mouseButton: (b, down) => log('os_button', { b, down }) };
}
