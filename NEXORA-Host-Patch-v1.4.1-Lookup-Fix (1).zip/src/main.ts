import { spawn } from 'node:child_process';
import { HostApp } from './app.js'; import { buildIceServers } from './config.js'; import { startUi } from './ui.js'; import { loadNodePeerFactory } from './rtc-node.js'; import { createWindowsInput, createLogInput } from './input-win.js';

const app = new HostApp({ echo: true, remote: true });
try { app.setBindings({ makePeer: await loadNodePeerFactory(buildIceServers(app.cfg)) }); } catch (e) { app.log.log('webrtc_missing', { err: e instanceof Error ? e.message.slice(0, 120) : 'unknown' }); app.warn('The WebRTC component (node-datachannel) is not installed, so streaming cannot start. Run "npm install" in this folder.'); }
try { app.setBindings({ osInput: process.platform === 'win32' ? await createWindowsInput(app.log.log) : createLogInput(app.log.log) }); } catch (e) { app.log.log('input_backend_missing', { err: e instanceof Error ? e.message.slice(0, 120) : 'unknown' }); app.setBindings({ osInput: createLogInput(app.log.log) }); }
await app.ready();
await app.start();
const ui = await startUi(app);
console.log(`\nNEXORA Host is running.\nOpen the control panel:  ${ui.url}\nIdentity: ${app.id.deviceId}\n${app.phoneAddresses().length ? 'Type this address into the NEXORA phone app: ' + app.phoneAddresses()[0] + '\n' : ''}`);
if (app.cfg.openBrowser) { try { spawn(process.platform === 'win32' ? 'cmd' : process.platform === 'darwin' ? 'open' : 'xdg-open', process.platform === 'win32' ? ['/c', 'start', '', ui.url] : [ui.url], { stdio: 'ignore', detached: true }).unref(); } catch { /* user can open the URL above */ } }
const quit = () => { app.stop(); ui.close(); process.exit(0); };
process.on('SIGINT', quit); process.on('SIGTERM', quit);
