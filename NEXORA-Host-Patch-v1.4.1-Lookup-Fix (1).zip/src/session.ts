import { InputGate, type InputSink } from './input.js'; import type { GameLibrary } from './library.js'; import type { MetaStore } from './meta.js';
export interface ClientStats { rttMs: number; lossPct: number; fps: number; bitrateKbps: number }
export interface QualityRequest { preset?: '720p' | '1080p' | '1440p'; fps?: number; bitrate?: 'auto' | number }
export interface SessionHooks { onStats?(s: ClientStats): void; onLibraryRequest?(): void; onQuality?(q: QualityRequest): void; onLaunch?(gameId: string): object | null | void }
const PRESETS = new Set(['720p', '1080p', '1440p']); const FPS = new Set([30, 60, 90, 120]);
/** Only known presets and numbers in range get through; anything else is dropped. */
export function cleanQuality(m: any): QualityRequest | null {
  const q: QualityRequest = {};
  if (typeof m?.preset === 'string' && PRESETS.has(m.preset)) q.preset = m.preset;
  if (typeof m?.fps === 'number' && FPS.has(m.fps)) q.fps = m.fps;
  if (m?.bitrate === 'auto') q.bitrate = 'auto'; else if (typeof m?.bitrate === 'number' && Number.isFinite(m.bitrate) && m.bitrate >= 1000 && m.bitrate <= 80000) q.bitrate = Math.round(m.bitrate);
  return Object.keys(q).length ? q : null;
}
const n = (v: unknown, lo: number, hi: number) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : 0);

/** Handles the receiver's data-channel messages (contract: nexora-mobile/docs/HOST_CONTRACT.md). Transport-agnostic. */
export class HostSession {
  private gate: InputGate;
  constructor(private lib: GameLibrary, sink: InputSink, private send: (o: object) => void, private log: (e: string, f?: object) => void = () => {}, private meta?: MetaStore, private hooks: SessionHooks = {}) { this.gate = new InputGate(sink); }
  onMessage(raw: string) {
    if (raw.length > 4096) return;
    let m: any; try { m = JSON.parse(raw); } catch { return; }
    if (m?.type === 'library.request') {
      this.hooks.onLibraryRequest?.();
      this.send({ type: 'library', games: this.lib.toWire().map(g => ({ ...g, metaRev: this.meta?.rev(g.id) })) });
    } else if (m?.type === 'meta.request' && typeof m.gameId === 'string') {
      const w = this.meta?.wire(m.gameId); if (w) this.send(w); else this.send({ type: 'meta', gameId: m.gameId, none: true });
    } else if (m?.type === 'stats') {
      this.hooks.onStats?.({ rttMs: n(m.rttMs, 0, 5000), lossPct: n(m.lossPct, 0, 100), fps: n(m.fps, 0, 240), bitrateKbps: n(m.bitrateKbps, 0, 100000) });
    } else if (m?.type === 'quality.set') {
      const q = cleanQuality(m); if (q) { this.log('quality_set', q as object); this.hooks.onQuality?.(q); }
    } else if (m?.type === 'launch' && typeof m.gameId === 'string') {
      try {
        this.lib.launch(m.gameId, code => { this.log('game_exit', { code }); this.send({ type: 'game.exited' }); });
        this.log('game_launch');
        const offer = this.hooks.onLaunch?.(m.gameId);
        if (offer) this.send(offer);
        // Always prefer landscape for gameplay (phone may ignore).
        this.send({ type: 'preferOrientation', orientation: 'landscape' });
      } catch (e) { this.send({ type: 'error', message: e instanceof Error ? e.message : 'Could not start the game' }); }
    } else this.gate.handle(m);
  }
  /** Phone dropped: release held inputs but leave the game running so a reconnect can resume. */
  onDisconnect() { this.gate.releaseAll(); }
}
