export type InputEvent = { kind: 'button'; control: string; pressed: boolean } | { kind: 'axis'; control: 'moveX' | 'moveY'; value: number } | { kind: 'pointer'; dx: number; dy: number };
const CONTROL = /^[A-Za-z0-9_]{1,24}$/;
const num = (v: unknown) => typeof v === 'number' && Number.isFinite(v);
/** Validates an untrusted data-channel frame. Returns null for anything malformed. */
export function parseInput(m: any): { seq: number; ev: InputEvent } | null {
  if (!m || m.v !== 1 || !num(m.seq)) return null;
  if (m.type === 'button' && typeof m.control === 'string' && CONTROL.test(m.control) && typeof m.pressed === 'boolean') return { seq: m.seq, ev: { kind: 'button', control: m.control, pressed: m.pressed } };
  if (m.type === 'axis' && (m.control === 'moveX' || m.control === 'moveY') && num(m.value)) return { seq: m.seq, ev: { kind: 'axis', control: m.control, value: Math.max(-1, Math.min(1, m.value)) } };
  if (m.type === 'pointer' && num(m.dx) && num(m.dy)) return { seq: m.seq, ev: { kind: 'pointer', dx: Math.max(-500, Math.min(500, m.dx)), dy: Math.max(-500, Math.min(500, m.dy)) } };
  return null;
}
export interface InputSink { apply(e: InputEvent): void }
/** Drops duplicate/stale frames and releases everything still held when the phone disconnects (no stuck keys). */
export class InputGate {
  private last = -1; private held = new Set<string>(); private axes = new Set<string>();
  constructor(private sink: InputSink) {}
  handle(m: unknown) {
    const p = parseInput(m); if (!p || p.seq <= this.last) return; this.last = p.seq;
    const e = p.ev;
    if (e.kind === 'button') e.pressed ? this.held.add(e.control) : this.held.delete(e.control);
    if (e.kind === 'axis') e.value ? this.axes.add(e.control) : this.axes.delete(e.control);
    this.sink.apply(e);
  }
  releaseAll() { for (const c of this.held) this.sink.apply({ kind: 'button', control: c, pressed: false }); for (const c of this.axes) this.sink.apply({ kind: 'axis', control: c as 'moveX', value: 0 }); this.held.clear(); this.axes.clear(); this.last = -1; }
}
