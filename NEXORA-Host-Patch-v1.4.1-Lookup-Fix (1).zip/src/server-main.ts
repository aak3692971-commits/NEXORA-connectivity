import { startSignalingServer } from './server/signaling-server.js';
const port = Number(process.env.PORT) || 47801;
const s = await startSignalingServer({ port, trustProxy: process.env.TRUST_PROXY === '1', log: (e, f) => console.log(new Date().toISOString().slice(11, 19), e, f ?? '') });
console.log(`NEXORA signaling server (protocol v2) listening on :${s.port}  ws path: /api/ws`);
