import { createHash, createPrivateKey, generateKeyPairSync, sign } from 'node:crypto';
import path from 'node:path'; import { JsonStore } from './store.js'; import type { Dirs } from './paths.js';
export interface Identity { deviceId: string; publicKey: string; sign(bytes: Buffer): string }
/** Ed25519 identity, created once. NOTE: stored unencrypted in data/ (portable). Windows DPAPI wrapping is a later hardening step. */
export function loadIdentity(d: Dirs): Identity {
  const store = new JsonStore<{ pkcs8?: string; pub?: string }>(path.join(d.data, 'identity.json'), {});
  let s = store.load();
  if (!s.pkcs8 || !s.pub) {
    const kp = generateKeyPairSync('ed25519');
    s = { pkcs8: kp.privateKey.export({ format: 'der', type: 'pkcs8' }).toString('base64url'), pub: kp.publicKey.export({ format: 'der', type: 'spki' }).subarray(-32).toString('base64url') };
    store.save(s);
  }
  const key = createPrivateKey({ key: Buffer.from(s.pkcs8!, 'base64url'), format: 'der', type: 'pkcs8' });
  const deviceId = createHash('sha256').update(Buffer.from(s.pub!, 'base64url')).digest().subarray(0, 16).toString('hex');
  return { deviceId, publicKey: s.pub!, sign: (b) => sign(null, b, key).toString('base64url') };
}
