import path from 'node:path'; import fs from 'node:fs';
import { JsonStore } from './store.js';
import type { Dirs } from './paths.js';

export type EncoderChoice = 'auto' | 'nvenc' | 'qsv' | 'amf' | 'x264';
export interface Config {
  signalingMode: 'local' | 'remote'; serverPort: number; signalingUrl: string; hostName: string; uiPort: number; openBrowser: boolean;
  encoder: EncoderChoice; capture: 'ddagrab' | 'gdigrab';
  width: number; height: number; fps: number;
  bitrateKbps: number; minBitrateKbps: number; maxBitrateKbps: number; adaptiveBitrate: boolean;
  audioDevice: string | null; ffmpegPath: string;
  stunUrls: string[]; turnUrls: string[]; turnUser: string | null; turnPass: string | null; rawgKey: string | null; lookupGameInfo: boolean; remoteAccess: boolean;
}
export const DEFAULTS: Config = {
  signalingMode: 'local', serverPort: 47801,
  signalingUrl: 'ws://127.0.0.1:47801/api/ws',
  hostName: 'NEXORA-PC', uiPort: 47800, openBrowser: true,
  encoder: 'auto', capture: 'ddagrab', width: 1920, height: 1080, fps: 60,
  bitrateKbps: 6000, minBitrateKbps: 2500, maxBitrateKbps: 12000, adaptiveBitrate: false,
  audioDevice: null, ffmpegPath: 'ffmpeg',
  stunUrls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302', 'stun:stun.cloudflare.com:3478'], turnUrls: [], turnUser: null, turnPass: null, rawgKey: null, lookupGameInfo: true, remoteAccess: true,
};
const clamp = (v: unknown, lo: number, hi: number, d: number) => { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : d; };
const str = (v: unknown, d: string, max = 200) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : d);

/** Reads config/config.json, fills gaps with defaults, clamps everything. Writes the defaults on first run so the file is easy to find. */
export function loadConfig(d: Dirs, env: Record<string, string | undefined> = process.env): Config {
  const store = new JsonStore<Partial<Config>>(path.join(d.config, 'config.json'), {});
  const raw: any = store.load();
  const first = Object.keys(raw).length === 0;
  const min = clamp(raw.minBitrateKbps, 500, 50000, DEFAULTS.minBitrateKbps);
  const max = Math.max(min, clamp(raw.maxBitrateKbps, 500, 80000, DEFAULTS.maxBitrateKbps));
  const c: Config = {
    signalingMode: raw.signalingMode === 'remote' || env.NEXORA_SIGNALING_URL ? 'remote' : 'local', serverPort: clamp(raw.serverPort, 1024, 65535, DEFAULTS.serverPort),
    signalingUrl: str(env.NEXORA_SIGNALING_URL ?? raw.signalingUrl, DEFAULTS.signalingUrl, 300),
    hostName: str(raw.hostName, (process.env.COMPUTERNAME || process.env.HOSTNAME || DEFAULTS.hostName).toString().slice(0, 48), 48),
    uiPort: clamp(raw.uiPort, 1024, 65535, DEFAULTS.uiPort),
    openBrowser: raw.openBrowser !== false,
    encoder: (['auto', 'nvenc', 'qsv', 'amf', 'x264'] as const).includes(raw.encoder) ? raw.encoder : DEFAULTS.encoder,
    capture: raw.capture === 'gdigrab' ? 'gdigrab' : 'ddagrab',
    width: clamp(raw.width, 320, 3840, DEFAULTS.width) & ~1, height: clamp(raw.height, 240, 2160, DEFAULTS.height) & ~1,
    fps: clamp(raw.fps, 15, 120, DEFAULTS.fps),
    bitrateKbps: Math.min(max, Math.max(min, clamp(raw.bitrateKbps, 500, 80000, DEFAULTS.bitrateKbps))), minBitrateKbps: min, maxBitrateKbps: max,
    adaptiveBitrate: raw.adaptiveBitrate === true,
    audioDevice: typeof raw.audioDevice === 'string' && raw.audioDevice.trim() ? raw.audioDevice.trim().slice(0, 200) : null,
    ffmpegPath: resolveFfmpeg(d.root, str(raw.ffmpegPath, DEFAULTS.ffmpegPath, 300)),
    stunUrls: Array.isArray(raw.stunUrls) ? raw.stunUrls.filter((u: unknown) => typeof u === 'string' && /^stuns?:/.test(u)).slice(0, 4) : DEFAULTS.stunUrls,
    turnUrls: Array.isArray(raw.turnUrls) ? raw.turnUrls.filter((u: unknown) => typeof u === 'string' && /^turns?:/.test(u)).slice(0, 4) : [],
    turnUser: typeof raw.turnUser === 'string' && raw.turnUser.trim() ? raw.turnUser.trim().slice(0, 200) : null,
    turnPass: typeof raw.turnPass === 'string' && raw.turnPass ? raw.turnPass.slice(0, 200) : null,
    rawgKey: typeof raw.rawgKey === 'string' && raw.rawgKey.trim() ? raw.rawgKey.trim() : null,
    lookupGameInfo: raw.lookupGameInfo !== false,
    remoteAccess: raw.remoteAccess !== false,
  };
  if (!c.stunUrls.length) c.stunUrls = DEFAULTS.stunUrls;
  if (first) store.save(c);
  return c;
}
export function saveConfigPatch(d: Dirs, patch: Partial<Config>) {
  const store = new JsonStore<Partial<Config>>(path.join(d.config, 'config.json'), {});
  store.save({ ...store.load(), ...patch });
}

/** "ffmpeg" means: use ffmpeg.exe from the NEXORA folder if it is there, else whatever is on PATH. An explicit path is used as given. */
export function resolveFfmpeg(root: string, configured: string): string {
  if (configured !== 'ffmpeg') return configured;
  const res = (process as any).resourcesPath as string | undefined;                       // set inside the installed desktop app: ffmpeg.exe ships next to the app
  for (const base of [root, ...(res ? [res] : [])]) for (const rel of ['ffmpeg.exe', 'ffmpeg', path.join('bin', 'ffmpeg.exe'), path.join('ffmpeg', 'bin', 'ffmpeg.exe')]) { const p = path.join(base, rel); try { if (fs.statSync(p).isFile()) return p; } catch { /* not there */ } }
  return configured;
}
/** ICE servers in libdatachannel's string format. TURN is only used when the user configured one: a relay is how a phone on mobile data reaches a PC behind a strict router. */
export function buildIceServers(c: Pick<Config, 'stunUrls' | 'turnUrls' | 'turnUser' | 'turnPass'>): string[] {
  const out = [...c.stunUrls];
  if (c.turnUser && c.turnPass) for (const u of c.turnUrls) {
    const m = /^(turns?):([^?]+)(\?.*)?$/.exec(u); if (m) out.push(`${m[1]}:${encodeURIComponent(c.turnUser)}:${encodeURIComponent(c.turnPass)}@${m[2]}${m[3] ?? ''}`);
  }
  return out;
}
