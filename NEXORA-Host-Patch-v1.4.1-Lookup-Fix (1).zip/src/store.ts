import fs from 'node:fs'; import path from 'node:path'; import { randomBytes } from 'node:crypto';
/** Small JSON file with atomic writes (tmp + rename) so a crash never leaves a half-written file. */
export class JsonStore<T> {
  constructor(private file: string, private fallback: T) {}
  load(): T { try { return JSON.parse(fs.readFileSync(this.file, 'utf8')) as T; } catch { return structuredClone(this.fallback); } }
  save(v: T) { const tmp = this.file + '.' + randomBytes(4).toString('hex') + '.tmp'; fs.mkdirSync(path.dirname(this.file), { recursive: true }); fs.writeFileSync(tmp, JSON.stringify(v, null, 2)); fs.renameSync(tmp, this.file); }
}
