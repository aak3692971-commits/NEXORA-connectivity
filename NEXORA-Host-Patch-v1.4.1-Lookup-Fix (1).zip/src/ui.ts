import { fileURLToPath } from 'node:url'; import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import { timingSafeEqual } from 'node:crypto'; import type { AddressInfo } from 'node:net';
import type { HostApp } from './app.js';

const MAX_BODY = 8192;
const CSP = "default-src 'self'; img-src 'self' blob: data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'";
const same = (a: string, b: string) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && timingSafeEqual(x, y); };

/** Local control panel. Bound to 127.0.0.1 only. Every API call needs the per-run token, a JSON content-type and a local Host header,
 *  so a web page you happen to visit cannot add games or approve a phone (CSRF / DNS-rebinding). */
export function startUi(app: HostApp, port = app.cfg.uiPort): Promise<{ server: http.Server; port: number; url: string; close(): void }> {
  // Plain string paths (not URL objects): Electron's asar layer only sees inside app.asar for string paths, so a URL read fails in the installed app.
  const here = path.dirname(fileURLToPath(import.meta.url));
  const res = (process as any).resourcesPath as string | undefined;
  const candidates = [path.join(here, 'ui', 'index.html'), path.join(here, '..', 'dist', 'ui', 'index.html'), ...(res ? [path.join(res, 'app.asar', 'dist', 'ui', 'index.html'), path.join(res, 'app', 'dist', 'ui', 'index.html')] : [])];
  let page: Buffer | undefined; const tried: string[] = [];
  for (const c of candidates) { try { page = fs.readFileSync(c); break; } catch (e: any) { tried.push(`${c} (${e?.code ?? 'error'})`); } }
  if (!page) return Promise.reject(new Error('Control panel page not found. Looked in: ' + tried.join('; ')));
  let actual = port;
  const server = http.createServer(async (req, res) => {
    const send = (code: number, body: unknown, type = 'application/json') => { res.writeHead(code, { 'content-type': type, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'content-security-policy': CSP }); res.end(type === 'application/json' ? JSON.stringify(body) : body as any); };
    try {
      const host = String(req.headers.host ?? ''); if (host !== `127.0.0.1:${actual}` && host !== `localhost:${actual}`) return send(403, { error: 'bad host' });
      const u = new URL(req.url ?? '/', 'http://x'); const p = u.pathname;
      if (req.method === 'GET' && p === '/') return send(200, page, 'text/html; charset=utf-8');
      if (p === '/favicon.ico') { res.writeHead(204); return res.end(); }
      if (req.method === 'GET' && /^\/assets\/[a-z0-9-]+\.png$/.test(p)) { try { const b = fs.readFileSync(path.join(here, 'ui', 'assets', p.slice(8))); res.writeHead(200, { 'content-type': 'image/png', 'cache-control': 'private, max-age=86400', 'x-content-type-options': 'nosniff' }); return void res.end(b); } catch { return send(404, { error: 'no asset' }); } }
      const tok = String(req.headers['x-nexora-token'] ?? (req.method === 'GET' && (p.startsWith('/api/cover/') || p === '/hero') ? u.searchParams.get('t') ?? '' : ''));
      if (!same(tok, app.uiToken)) return send(401, { error: 'unauthorized' });
      if (req.method === 'GET' && p === '/api/state') return send(200, app.snapshot());
      if (req.method === 'GET' && p === '/api/patch/status') return send(200, app.patcher.state());
      if (req.method === 'GET' && p === '/api/patch/info') return send(200, app.patcher.info());
      if (req.method === 'GET' && p === '/controller-card') {
        const f = path.join(here, 'ui', 'controller-card.jpg');
        try { const b = fs.readFileSync(f); res.writeHead(200, { 'content-type': 'image/jpeg', 'cache-control': 'private, max-age=3600', 'x-content-type-options': 'nosniff' }); return void res.end(b); } catch { return send(404, { error: 'no controller card' }); }
      }
      if (req.method === 'GET' && p === '/hero') {                                                 // optional custom artwork: <data folder>/hero.jpg|png|webp
        for (const [ext, mime] of [['jpg', 'image/jpeg'], ['png', 'image/png'], ['webp', 'image/webp']] as const) { const f = path.join(app.d.root, 'hero.' + ext); try { const b = fs.readFileSync(f); res.writeHead(200, { 'content-type': mime, 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff' }); return void res.end(b); } catch { /* try next */ } }
        for (const [f, mime] of [[path.join(here, 'ui', 'empty-hero.jpg'), 'image/jpeg']] as const) { try { const b = fs.readFileSync(f); res.writeHead(200, { 'content-type': mime, 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff' }); return void res.end(b); } catch {} }
        return send(404, { error: 'no hero' });
      }
      if (req.method === 'GET' && p.startsWith('/api/cover/')) { const c = app.meta.cover(decodeURIComponent(p.slice(11))); if (!c) return send(404, { error: 'no cover' }); res.writeHead(200, { 'content-type': c.mime, 'cache-control': 'private, max-age=3600', 'x-content-type-options': 'nosniff' }); return res.end(c.data); }
      if (req.method !== 'POST') return send(405, { error: 'method' });
      if (!String(req.headers['content-type'] ?? '').startsWith('application/json')) return send(415, { error: 'json only' });
      let raw = ''; for await (const ch of req) { raw += ch; if (raw.length > MAX_BODY) return send(413, { error: 'too large' }); }
      let b: any = {}; try { b = raw ? JSON.parse(raw) : {}; } catch { return send(400, { error: 'bad json' }); }
      const s = (v: unknown, max = 300) => (typeof v === 'string' ? v.slice(0, max) : '');
      switch (p) {
        case '/api/pair/open': app.openPairing(); return send(200, { ok: true });
        case '/api/pair/answer': return send(200, { ok: app.answerPair(s(b.clientId, 64), b.allow === true) });
        case '/api/paired/revoke': app.revoke(s(b.id, 64)); return send(200, { ok: true });
        case '/api/games': { const g = await app.addGame({ name: s(b.name, 80), exe: s(b.exe) }); return send(200, { ok: true, id: g.id }); }
        case '/api/patch/apply': app.patcher.start('patch', s(b.zip, 520), s(b.backupDir, 520)); return send(200, { ok: true });
        case '/api/patch/rollback': app.patcher.rollbackLast(); return send(200, { ok: true });
        case '/api/patch/restore': app.patcher.start('restore', s(b.zip, 520)); return send(200, { ok: true });
        case '/api/patch/pick': return send(200, { path: await app.pickPath(b.kind === 'folder' ? 'folder' : 'zip') });
        case '/api/patch/restart': return send(200, { ok: app.restartApp() });
        case '/api/games/pick': return send(200, { exe: await app.pickExe() });
        case '/api/games/rename': app.renameGame(s(b.id, 64), s(b.name, 80)); return send(200, { ok: true });
        case '/api/games/resolve': await app.chooseMeta(s(b.id, 64), Number.isInteger(b.index) ? b.index : -1); return send(200, { ok: true });
        case '/api/games/remove': app.removeGame(s(b.id, 64)); return send(200, { ok: true });
        case '/api/games/open-location': app.openGameLocation(s(b.id, 64)); return send(200, { ok: true });
        case '/api/games/refresh': void app.refreshMeta(s(b.id, 64)); return send(200, { ok: true });
        case '/api/games/layout': return send(200, { ok: true, prefs: app.setGameLayout(s(b.id, 64), {
          layoutId: b.layoutId === null ? null : (typeof b.layoutId === 'string' ? s(b.layoutId, 64) : undefined),
          inputMode: b.inputMode === 'touch' || b.inputMode === 'cursor' || b.inputMode === 'auto' ? b.inputMode : undefined,
          layoutsEnabled: typeof b.layoutsEnabled === 'boolean' ? b.layoutsEnabled : undefined,
          preferLandscape: typeof b.preferLandscape === 'boolean' ? b.preferLandscape : undefined,
        }) });
        case '/api/layouts/save': return send(200, { ok: true, layout: app.saveLayout(b.layout) });
        case '/api/session/end': app.endSession(); return send(200, { ok: true });
        case '/api/settings': app.updateSettings(b && typeof b === 'object' ? b : {}); return send(200, { ok: true });
        case '/api/audio': app.setAudioDevice(s(b.device, 200) || null); return send(200, { ok: true });
        default: return send(404, { error: 'not found' });
      }
    } catch (e) { send(400, { error: e instanceof Error ? e.message : 'error' }); }
  });
  const listenOn = (pt: number) => new Promise<{ server: http.Server; port: number; url: string; close(): void }>((ok, bad) => { server.once('error', bad); server.listen(pt, '127.0.0.1', () => { actual = (server.address() as AddressInfo).port; ok({ server, port: actual, url: `http://127.0.0.1:${actual}/#t=${app.uiToken}`, close: () => server.close() }); }); });
  // The panel port is only used by this PC's own window, so if it is taken (another copy, a leftover process) just use a free one.
  return listenOn(port).catch((e: any) => { if (e?.code === 'EADDRINUSE' && port !== 0) { server.removeAllListeners('error'); return listenOn(0); } throw e; });
}
