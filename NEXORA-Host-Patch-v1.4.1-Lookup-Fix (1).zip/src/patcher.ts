// Installs an update from a .zip, saving a backup of the current version first, and rolls back from that backup.
// No dependencies: a small zip reader/writer on top of node:zlib. Everything is reported through `state()` for a progress bar.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { spawn } from 'node:child_process';

export interface PatchState {
  busy: boolean; op: 'patch' | 'restore' | null; phase: string; pct: number; done: boolean;
  error: string | null; backupFile: string | null; from: string | null; to: string | null; restart: boolean;
}
interface Ent { name: string; dir: boolean; read(): Buffer }
interface Item { rel: string; ent: Ent }

const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
export function crc32(b: Buffer): number { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]!) & 0xff]! ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
const tick = () => new Promise<void>(r => setImmediate(r));

export function readZip(buf: Buffer): Ent[] {
  let e = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('That file is not a zip file.');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out: Ent[] = [];
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('The zip file is damaged.');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), cs = buf.readUInt32LE(p + 20), us = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/'); p += 46 + nl + el + cl;
    if (flags & 1) throw new Error('Password-protected zip files are not supported.');
    out.push({ name, dir: name.endsWith('/'), read() {
      if (buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('The zip file is damaged.');
      const s = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(s, s + cs);
      if (method !== 0 && method !== 8) throw new Error('This zip uses a compression NEXORA cannot read.');
      const d = method === 0 ? Buffer.from(raw) : zlib.inflateRawSync(raw);
      if (d.length !== us || crc32(d) !== crc) throw new Error('The zip file is damaged.');
      return d;
    } });
  }
  return out;
}

export async function writeZip(file: string, items: { name: string; data: Buffer }[], each?: (i: number) => void): Promise<void> {
  const parts: Buffer[] = [], cd: Buffer[] = []; let off = 0;
  for (let i = 0; i < items.length; i++) {
    const it = items[i]!, name = Buffer.from(it.name, 'utf8'), data = zlib.deflateRawSync(it.data), crc = crc32(it.data);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8); h.writeUInt16LE(0x21, 12);
    h.writeUInt32LE(crc, 14); h.writeUInt32LE(data.length, 18); h.writeUInt32LE(it.data.length, 22); h.writeUInt16LE(name.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10); c.writeUInt16LE(0x21, 14);
    c.writeUInt32LE(crc, 16); c.writeUInt32LE(data.length, 20); c.writeUInt32LE(it.data.length, 24); c.writeUInt16LE(name.length, 28); c.writeUInt32LE(off, 42);
    parts.push(h, name, data); cd.push(c, name); off += 30 + name.length + data.length;
    each?.(i); if (i % 8 === 7) await tick();
  }
  const cdb = Buffer.concat(cd), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(items.length, 8); end.writeUInt16LE(items.length, 10); end.writeUInt32LE(cdb.length, 12); end.writeUInt32LE(off, 16);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.part'; fs.writeFileSync(tmp, Buffer.concat([...parts, cdb, end])); fs.renameSync(tmp, file);
}

const SKIP = new Set(['node_modules', '.git', 'release', '__MACOSX', 'nexora-data', 'backups', 'config', 'games', 'layouts', 'logs', 'cache', 'data']); // never touch user data
const KNOWN = new Set(['src', 'dist', 'electron', 'scripts', 'build', 'test']);
/** Forward-slash relative path that stays inside the app folder, or null. */
export function safeRel(name: string): string | null {
  const parts = name.replace(/\\/g, '/').split('/').filter(x => x && x !== '.');
  if (!parts.length || parts.some(x => x === '..' || x.includes(':'))) return null;
  return parts.join('/');
}
function walk(dir: string, base = dir, out: string[] = []): string[] {
  if (!fs.existsSync(dir)) return out;
  for (const n of fs.readdirSync(dir, { withFileTypes: true })) { const f = path.join(dir, n.name); n.isDirectory() ? walk(f, base, out) : out.push(path.relative(base, f).split(path.sep).join('/')); }
  return out;
}
const stamp = () => { const d = new Date(), z = (n: number) => String(n).padStart(2, '0'); return `${d.getFullYear()}${z(d.getMonth() + 1)}${z(d.getDate())}-${z(d.getHours())}${z(d.getMinutes())}${z(d.getSeconds())}`; };
const idle = (): PatchState => ({ busy: false, op: null, phase: '', pct: 0, done: false, error: null, backupFile: null, from: null, to: null, restart: false });

export class Patcher {
  readonly root: string | null; readonly backupDir: string; private st: PatchState = idle();
  constructor(root: string | null, backupDir: string) { this.root = root; this.backupDir = backupDir; }

  state(): PatchState { return { ...this.st }; }
  /** True when the app folder can be written to (an installed copy in Program Files is not, unless the installer opened it up). */
  private writable(): boolean {
    if (!this.root) return false;
    if (/\.asar([\\/]|$)/i.test(this.root)) return false;
    const t = path.join(this.root, `.nx-write-test-${process.pid}-${Date.now()}`);
    try {
      fs.writeFileSync(t, 'x', { flag: 'wx' });
      fs.unlinkSync(t);
      return true;
    } catch {
      try { fs.unlinkSync(t); } catch { /* no test file was created */ }
      return false;
    }
  }
  private pointer() { return path.join(this.root!, 'last-backup.json'); }
  /** The backup made by the most recent update, if it still exists. */
  lastBackup(): string | null {
    if (!this.root) return null;
    try { const f = JSON.parse(fs.readFileSync(this.pointer(), 'utf8')).file; return typeof f === 'string' && fs.existsSync(f) ? f : null; } catch { return null; }
  }
  info() {
    const reason = !this.root ? 'Updating from a zip is not available in this build.'
      : !fs.existsSync(path.join(this.root, 'package.json')) ? 'NEXORA could not locate its installed application files.'
      : !this.writable() ? 'This NEXORA install folder is protected by Windows. Run the latest NEXORA Setup once using the Windows account that will use NEXORA; your settings and games stay in your profile.' : '';
    return { supported: !reason, reason, version: this.version(), backupDir: this.backupDir, lastBackup: this.lastBackup() };
  }
  private version(): string | null { try { return JSON.parse(fs.readFileSync(path.join(this.root!, 'package.json'), 'utf8')).version ?? null; } catch { return null; } }
  private set(phase: string, pct: number) { this.st.phase = phase; this.st.pct = Math.max(this.st.pct, Math.min(100, Math.round(pct))); }

  /** Starts an update or a restore and returns at once; watch state() for progress. */
  start(op: 'patch' | 'restore', zip: string, backupDir?: string): void {
    const i = this.info(); if (!i.supported) throw new Error(i.reason);
    if (this.st.busy) throw new Error('An update is already running.');
    if (!zip || !fs.existsSync(zip)) throw new Error('Could not find that file.');
    this.st = { ...idle(), busy: true, op, from: this.version(), phase: 'Starting…' };
    const dir = backupDir && backupDir.trim() ? backupDir : this.backupDir;
    void (op === 'patch' ? this.patch(zip, dir) : this.restore(zip)).catch(e => { this.st.error = e instanceof Error ? e.message : String(e); }).finally(() => { this.st.busy = false; if (!this.st.error) { this.st.done = true; this.st.pct = 100; this.st.restart = true; } });
  }

  /** One-click undo of the most recent update. */
  rollbackLast(): void {
    const f = this.lastBackup(); if (!f) throw new Error('There is no update to roll back yet.');
    this.start('restore', f);
  }

  private normalize(ents: Ent[]): Item[] {
    let list = ents.filter(e => !e.dir).map(e => ({ rel: safeRel(e.name), ent: e })).filter((x): x is Item => !!x.rel);
    const first = new Set(list.map(x => x.rel.split('/')[0]));
    if (first.size === 1 && !KNOWN.has([...first][0]!) && list.every(x => x.rel.includes('/'))) list = list.map(x => ({ ...x, rel: x.rel.split('/').slice(1).join('/') }));
    return list.filter(x => !SKIP.has(x.rel.split('/')[0]!) && !x.rel.endsWith('.nxtmp'));
  }

  private async backup(file: string, rels: string[], meta: Record<string, unknown>): Promise<void> {
    const root = this.root!, set = new Set(rels), dist = walk(path.join(root, 'dist')).map(x => 'dist/' + x); for (const d of dist) set.add(d);
    const have = [...set].filter(r => fs.existsSync(path.join(root, r)));
    const items: { name: string; data: Buffer }[] = [{ name: 'nexora-backup.json', data: Buffer.from(JSON.stringify({ app: 'nexora-host', kind: 'backup', created: new Date().toISOString(), version: this.version(), dist: true, ...meta }, null, 1)) }];
    for (let i = 0; i < have.length; i++) { items.push({ name: 'files/' + have[i], data: fs.readFileSync(path.join(root, have[i]!)) }); if (i % 20 === 19) await tick(); }
    await writeZip(file, items, i => this.set('Saving a backup of your current version…', 10 + 28 * (i / items.length)));
  }

  private put(rel: string, data: Buffer) {
    const dst = path.join(this.root!, rel), tmp = dst + '.nxtmp'; fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.writeFileSync(tmp, data);
    for (let t = 0; ; t++) { try { fs.renameSync(tmp, dst); return; } catch (e: any) { if (t >= 6 || !['EPERM', 'EBUSY', 'EACCES'].includes(e?.code)) { try { fs.unlinkSync(tmp); } catch { /* ignore */ } throw e; } Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 150); } }
  }

  /** Puts a backup's files back, removes files the update had added and drops build output that is not in the backup. */
  private async applyBackup(ents: Ent[], from: number, to: number): Promise<void> {
    const root = this.root!, mf = ents.find(e => e.name === 'nexora-backup.json');
    let meta: any; try { meta = JSON.parse(mf!.read().toString('utf8')); } catch { throw new Error('This does not look like a NEXORA backup file.'); }
    if (meta?.app !== 'nexora-host' || meta?.kind !== 'backup') throw new Error('This does not look like a NEXORA backup file.');
    const files = ents.filter(e => e.name.startsWith('files/') && !e.dir), keep = new Set<string>();
    for (let i = 0; i < files.length; i++) {
      const rel = safeRel(files[i]!.name.slice(6)); if (!rel || SKIP.has(rel.split('/')[0]!)) continue;
      keep.add(rel); this.put(rel, files[i]!.read()); this.set('Putting your files back…', from + (to - from) * 0.85 * (i / files.length)); if (i % 10 === 9) await tick();
    }
    for (const rel of Array.isArray(meta.added) ? meta.added : []) { const r = safeRel(String(rel)); if (r && !keep.has(r) && !SKIP.has(r.split('/')[0]!)) try { fs.unlinkSync(path.join(root, r)); } catch { /* already gone */ } }
    if (meta.dist) for (const r of walk(path.join(root, 'dist')).map(x => 'dist/' + x)) if (!keep.has(r)) try { fs.unlinkSync(path.join(root, r)); } catch { /* ignore */ }
  }

  private async patch(zip: string, backupDir: string): Promise<void> {
    const root = this.root!; this.set('Checking the update…', 2);
    let items: Item[]; try { items = this.normalize(readZip(fs.readFileSync(zip))); } catch (e: any) { throw new Error(e?.message || 'Could not read that file.'); }
    const pk = items.find(x => x.rel === 'package.json'); let to: string | null = null;
    if (pk) { try { const j = JSON.parse(pk.ent.read().toString('utf8')); if (j.name && j.name !== 'nexora-host') throw 0; to = j.version ?? null; } catch { throw new Error('This zip is not a NEXORA update.'); } }
    if (!items.some(x => /^(src|dist|electron|scripts|build)\//.test(x.rel)) && !pk) throw new Error('This zip is not a NEXORA update.');
    this.st.to = to;
    const hasDist = items.some(x => x.rel.startsWith('dist/')), needsBuild = !hasDist && items.some(x => /^(src|electron|scripts)\//.test(x.rel) || x.rel === 'package.json');
    if (needsBuild && !(fs.existsSync(path.join(root, 'node_modules', 'esbuild')) && (fs.existsSync(path.join(root, 'scripts', 'build.mjs')) || items.some(x => x.rel === 'scripts/build.mjs'))))
      throw new Error('This update has to be built, and the tools for that are not installed on this PC. Nothing was changed.');
    this.set('Checking the update…', 8);
    const replaced = items.filter(x => fs.existsSync(path.join(root, x.rel))).map(x => x.rel), added = items.filter(x => !fs.existsSync(path.join(root, x.rel))).map(x => x.rel);
    const bf = path.join(backupDir, `NEXORA-backup-v${this.st.from ?? 'x'}-${stamp()}.zip`);
    try { await this.backup(bf, replaced, { patch: path.basename(zip), added }); } catch (e: any) { throw new Error('Could not save the backup there (' + (e?.code || e?.message) + '). Nothing was changed. Pick another backup folder.'); }
    this.st.backupFile = bf; try { fs.writeFileSync(this.pointer(), JSON.stringify({ file: bf, version: this.st.from, made: new Date().toISOString() })); } catch { /* the app still works; rollback.bat falls back to searching */ }
    this.set('Installing files…', 40);
    try {
      for (let i = 0; i < items.length; i++) { this.put(items[i]!.rel, items[i]!.ent.read()); this.set('Installing files…', 40 + (needsBuild ? 30 : 52) * ((i + 1) / items.length)); if (i % 10 === 9) await tick(); }
      if (needsBuild) await this.build();
      for (const f of ['dist/main.mjs', 'dist/preload.cjs', 'dist/ui/index.html']) if (!fs.existsSync(path.join(root, f))) throw new Error('The new version is incomplete (' + f + ' is missing).');
    } catch (e: any) {
      this.set('Something went wrong. Putting your old version back…', this.st.pct);
      try { await this.applyBackup(readZip(fs.readFileSync(bf)), 70, 98); } catch { /* best effort */ }
      throw new Error('The update could not be installed, so your previous version was put back. (' + String(e?.message || e).slice(0, 300) + ')');
    }
    this.set('Finishing…', 99);
  }

  private build(): Promise<void> {
    this.set('Building the new version…', 72);
    return new Promise<void>((res, rej) => {
      const c = spawn(process.execPath, ['scripts/build.mjs'], { cwd: this.root!, env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }, windowsHide: true }); let err = '';
      c.stdout.on('data', () => { /* drain */ }); c.stderr.on('data', d => (err += d));
      const t = setInterval(() => this.set('Building the new version…', Math.min(95, this.st.pct + 1)), 1500), to = setTimeout(() => { c.kill(); rej(new Error('Building took too long.')); }, 240_000);
      c.once('error', rej); c.once('exit', code => { clearInterval(t); clearTimeout(to); code === 0 ? res() : rej(new Error(err.trim().split('\n').slice(-4).join(' ') || 'The build failed.')); });
    });
  }

  private async restore(zip: string): Promise<void> {
    const root = this.root!; this.set('Checking the backup…', 2);
    let ents: Ent[]; try { ents = readZip(fs.readFileSync(zip)); } catch (e: any) { throw new Error(e?.message || 'Could not read that file.'); }
    const mf = ents.find(e => e.name === 'nexora-backup.json'); let meta: any;
    try { meta = JSON.parse(mf!.read().toString('utf8')); if (meta.app !== 'nexora-host' || meta.kind !== 'backup') throw 0; } catch { throw new Error('This zip is not a NEXORA backup.'); }
    this.st.to = meta.version ?? null;
    const restoreFiles = ents.filter(e => e.name.startsWith('files/') && !e.dir);
    // Validate every payload before writing the safety copy or changing the installation.
    for (const e of restoreFiles) e.read();
    const files = restoreFiles.map(e => safeRel(e.name.slice(6))).filter((x): x is string => !!x);
    const sf = path.join(this.backupDir, `NEXORA-before-restore-v${this.st.from ?? 'x'}-${stamp()}.zip`);
    try { await this.backup(sf, [...files, ...(Array.isArray(meta.added) ? meta.added : [])].filter(r => !SKIP.has(String(r).split('/')[0]!)), { restoredFrom: path.basename(zip) }); } catch (e: any) { throw new Error('Could not save a safety copy first (' + (e?.code || e?.message) + '). Nothing was changed.'); }
    this.st.backupFile = sf;
    try { fs.writeFileSync(this.pointer(), JSON.stringify({ file: sf, version: this.st.from, made: new Date().toISOString() })); } catch { /* the standalone rollback script can still find the backup */ }
    this.set('Putting your files back…', 40);
    try { await this.applyBackup(ents, 40, 98); } catch (e: any) { throw new Error('The restore failed (' + String(e?.message || e).slice(0, 300) + '). A safety copy of the previous state is at ' + sf); }
    if (!fs.existsSync(path.join(root, 'dist', 'main.mjs'))) this.st.phase = 'Done (the app will rebuild on next start)';
    this.set('Finishing…', 99);
  }
}
