import { UDP_BEGIN, UDP_END } from './remote.js'; import type { PeerFactory, PeerHandle } from './stream.js';
import { AUDIO_PT, AUDIO_SSRC, H264_FMTP, VIDEO_PT, VIDEO_SSRC } from './capture.js';

/** libdatachannel binding (npm: node-datachannel). Loaded lazily so the rest of the host runs and tests without it.
 *  NOT TESTABLE in the sandbox this was written in (no network to install the native binary): check it on the first real Windows run. */
export async function loadNodePeerFactory(stun: string[]): Promise<PeerFactory> {
  const mod: any = await import('node-datachannel'); const ndc = mod.default ?? mod;
  try { ndc.initLogger?.('Warning'); } catch { /* optional */ }
  return () => {
    const pc = new ndc.PeerConnection('nexora-host', { iceServers: stun, portRangeBegin: UDP_BEGIN, portRangeEnd: UDP_END });
    let video: any, audio: any, dc: any;
    const cbs: any = {};
    const h: PeerHandle = {
      onLocalDescription: cb => pc.onLocalDescription(cb), onLocalCandidate: cb => pc.onLocalCandidate(cb), onState: cb => pc.onStateChange(cb),
      onChannelOpen: cb => (cbs.open = cb), onChannelMessage: cb => (cbs.msg = cb), onChannelClosed: cb => (cbs.closed = cb),
      start() {
        const v = new ndc.Video('video', 'SendOnly'); v.addH264Codec(VIDEO_PT, H264_FMTP); v.addSSRC(VIDEO_SSRC, 'nexora-video', 'nexora', 'video');
        video = pc.addTrack(v); video.setMediaHandler(new ndc.RtcpReceivingSession());
        const a = new ndc.Audio('audio', 'SendOnly'); a.addOpusCodec(AUDIO_PT); a.addSSRC(AUDIO_SSRC, 'nexora-audio', 'nexora', 'audio');
        audio = pc.addTrack(a); audio.setMediaHandler(new ndc.RtcpReceivingSession());
        dc = pc.createDataChannel('nexora', { ordered: true });
        dc.onOpen(() => cbs.open?.()); dc.onMessage((m: unknown) => { if (typeof m === 'string') cbs.msg?.(m); }); dc.onClosed(() => cbs.closed?.());
      },
      setRemoteDescription: (sdp, type) => pc.setRemoteDescription(sdp, type), addRemoteCandidate: (c, mid) => pc.addRemoteCandidate(c, mid),
      sendChannel: s => { if (dc?.isOpen()) dc.sendMessage(s); },
      sendVideo: b => { if (video?.isOpen()) video.sendMessageBinary(b); }, sendAudio: b => { if (audio?.isOpen()) audio.sendMessageBinary(b); },
      close() { for (const x of [dc, video, audio]) { try { x?.close(); } catch { /* closed */ } } try { pc.close(); } catch { /* closed */ } },
    };
    return h;
  };
}
