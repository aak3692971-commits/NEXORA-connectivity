import http from 'node:http'; import { createHash, randomBytes, randomInt } from 'node:crypto'; import type { AddressInfo } from 'node:net';
import { WebSocketServer } from 'ws';
import { authBytes, sessionBytes, V, verifyB64u } from '../wire.js';

/** NEXORA signaling server, protocol v2. Only introduces a phone and a PC (pairing PIN, allow-list, session set-up, relaying signed WebRTC
 *  messages). It never sees video, audio or input, and it cannot forge a signal: peers verify each other's Ed25519 signatures themselves. */
interface Conn { ws: any; ip: string; nonce: string; role?: 'host' | 'client'; id?: string; pub?: string; name: string; bad: number; badSince: number; alive: boolean }
export interface ServerOpts { info?: () => object; port?: number; host?: string; pinTtlSec?: number; pairTimeoutSec?: number; maxConnsPerIp?: number; maxBadPins?: number; trustProxy?: boolean; log?: (e: string, f?: object) => void }
const ID = /^[0-9a-f]{32}$/, SID = /^[A-Za-z0-9_-]{8,64}$/;
const str = (v: unknown, max: number) => (typeof v === 'string' ? v.slice(0, max) : '');

export function startSignalingServer(o: ServerOpts = {}): Promise<{ port: number; close(): Promise<void>; stats(): { hosts: number; clients: number }; onlineClients(): string[] }> {
  const log = o.log ?? (() => {}), pinTtl = o.pinTtlSec ?? 120, pairTimeout = o.pairTimeoutSec ?? 60, maxConns = o.maxConnsPerIp ?? 20, maxBad = o.maxBadPins ?? 5;
  const hosts = new Map<string, Conn>(), clients = new Map<string, Conn>();
  const allow = new Map<string, Set<string>>();                                   // hostId -> allowed clientIds
  const pins = new Map<string, { hostId: string; exp: number }>();
  const pending = new Map<string, { hostId: string; clientId: string; timer: ReturnType<typeof setTimeout> }>();   // clientId -> awaiting host decision
  const sessions = new Map<string, { host: string; client: string }>(); const perIp = new Map<string, number>();
  // Wrong-PIN counter per IP address (not per socket): reconnecting must not reset it, or the 6 digits could be brute-forced.
  const badByIp = new Map<string, { n: number; since: number }>();

  const send = (c: Conn | undefined, m: object) => { try { if (c && c.ws.readyState === 1) c.ws.send(JSON.stringify({ protocolVersion: V, ...m })); } catch { /* peer gone */ } };
  const err = (c: Conn, code: string, message = code) => send(c, { t: 'error', code, message });
  const server = http.createServer((req, res) => {
    // The phone's "Find my PC" scan calls /nexora/discover from the app's web view, so CORS is open. It only reveals what pairing shows anyway (name, public key); no secret is exposed.
    const cors = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'GET, OPTIONS', 'access-control-allow-private-network': 'true', 'cache-control': 'no-store' };
    const path = (req.url ?? '').split('?')[0];
    if (req.method === 'OPTIONS') { res.writeHead(204, cors); return void res.end(); }
    if (req.method === 'GET' && path === '/health') { res.writeHead(200, { ...cors, 'content-type': 'application/json' }); return void res.end(JSON.stringify({ ok: true, protocol: V })); }
    if (req.method === 'GET' && path === '/nexora/discover' && o.info) { res.writeHead(200, { ...cors, 'content-type': 'application/json' }); return void res.end(JSON.stringify({ app: 'nexora', protocol: V, ...o.info() })); }
    res.writeHead(404, cors); res.end();
  });
  const wss = new WebSocketServer({ noServer: true, maxPayload: 65536 });
  server.on('upgrade', (req, socket, head) => {
    const fwd = o.trustProxy ? String(req.headers['x-forwarded-for'] ?? '').split(',')[0]!.trim().slice(0, 64) : ''; const ip = fwd || String(req.socket.remoteAddress ?? ''); const n = perIp.get(ip) ?? 0;
    if (!/^\/(api\/)?ws$/.test((req.url ?? '').split('?')[0]!) || n >= maxConns) { socket.write('HTTP/1.1 ' + (n >= maxConns ? '429 Too Many Requests' : '404 Not Found') + '\r\nConnection: close\r\n\r\n'); return socket.destroy(); }
    wss.handleUpgrade(req, socket, head, (ws: any) => wss.emit('connection', ws, ip));
  });
  const dropPins = (hostId: string) => { for (const [p, v] of pins) if (v.hostId === hostId) pins.delete(p); };
  const forget = (c: Conn) => {
    if (c.role === 'host' && c.id && hosts.get(c.id) === c) { hosts.delete(c.id); dropPins(c.id); for (const [cid, p] of pending) if (p.hostId === c.id) { clearTimeout(p.timer); pending.delete(cid); send(clients.get(cid), { t: 'pair.rejected', reason: 'host_offline' }); } }
    if (c.role === 'client' && c.id && clients.get(c.id) === c) { clients.delete(c.id); const p = pending.get(c.id); if (p) { clearTimeout(p.timer); pending.delete(c.id); } }
  };
  const sweep = setInterval(() => { for (const [p, v] of pins) if (v.exp < Date.now()) pins.delete(p); for (const c of [...hosts.values(), ...clients.values()]) { if (!c.alive) { try { c.ws.terminate(); } catch { /* gone */ } continue; } c.alive = false; try { c.ws.ping(); } catch { /* gone */ } } }, 25_000); sweep.unref?.();

  wss.on('connection', (ws: any, ip: string) => {
    perIp.set(ip, (perIp.get(ip) ?? 0) + 1);
    const c: Conn = { ws, ip, nonce: randomBytes(16).toString('base64url'), name: '', bad: 0, badSince: 0, alive: true };
    ws.on('pong', () => { c.alive = true; });
    send(c, { t: 'hello', nonce: c.nonce });
    const authTimer = setTimeout(() => { if (!c.id) ws.close(4401, 'auth timeout'); }, 10_000);
    ws.on('close', () => { clearTimeout(authTimer); perIp.set(ip, Math.max(0, (perIp.get(ip) ?? 1) - 1)); forget(c); });
    ws.on('error', () => {});
    ws.on('message', (raw: Buffer) => { let m: any; try { m = JSON.parse(raw.toString('utf8')); } catch { return; } if (m && typeof m === 'object') handle(c, m); });
  });

  function handle(c: Conn, m: any) {
    if (m.protocolVersion !== V) return err(c, 'protocol_version', 'This server speaks NEXORA signaling v2');
    if (!c.id) {
      if (m.t !== 'auth') return;
      const role = m.role === 'host' || m.role === 'client' ? m.role : null, id = str(m.deviceId, 64), pub = str(m.publicKey, 64), sig = str(m.sig, 120);
      if (!role || !ID.test(id) || !pub) return err(c, 'bad_auth');
      let ok = false; try { ok = createHash('sha256').update(Buffer.from(pub, 'base64url')).digest().subarray(0, 16).toString('hex') === id && Buffer.from(pub, 'base64url').length === 32 && verifyB64u(pub, authBytes(role, id, c.nonce), sig); } catch { ok = false; }
      if (!ok) { err(c, 'bad_auth', 'Signature check failed'); return c.ws.close(4403, 'bad auth'); }
      const table = role === 'host' ? hosts : clients; const old = table.get(id); if (old && old !== c) { old.id = undefined; try { old.ws.close(4000, 'replaced'); } catch { /* gone */ } }
      c.role = role; c.id = id; c.pub = pub; c.name = str(m.name, 48) || (role === 'host' ? 'NEXORA PC' : 'Phone'); table.set(id, c);
      log('auth', { role, name: c.name }); return send(c, { t: 'ready' });
    }
    if (c.role === 'host') fromHost(c, m); else fromClient(c, m);
  }
  function fromHost(c: Conn, m: any) {
    switch (m.t) {
      case 'allow.set': {
        const ids = Array.isArray(m.clientIds) ? m.clientIds.filter((x: unknown) => typeof x === 'string' && ID.test(x)).slice(0, 64) : []; const set = new Set<string>(ids); allow.set(c.id!, set);
        for (const [sid, s] of sessions) if (s.host === c.id && !set.has(s.client)) { sessions.delete(sid); send(clients.get(s.client), { t: 'session.updated', sessionId: sid, state: 'Closed' }); }
        return;
      }
      case 'pair.open': { dropPins(c.id!); let pin = ''; do pin = String(randomInt(0, 1_000_000)).padStart(6, '0'); while (pins.has(pin)); pins.set(pin, { hostId: c.id!, exp: Date.now() + pinTtl * 1000 }); return send(c, { t: 'pair.opened', pin, expiresInSec: pinTtl }); }
      case 'pair.accept': case 'pair.reject': {
        const cid = str(m.clientId, 64), p = pending.get(cid); if (!p || p.hostId !== c.id) return; clearTimeout(p.timer); pending.delete(cid); const cl = clients.get(cid);
        if (m.t === 'pair.accept') { dropPins(c.id!); send(cl, { t: 'pair.accepted', hostId: c.id, hostPublicKey: c.pub, hostName: c.name }); } else send(cl, { t: 'pair.rejected', reason: 'declined' });
        return;
      }
      case 'signal': case 'session.state': return relay(c, m);
    }
  }
  function fromClient(c: Conn, m: any) {
    switch (m.t) {
      case 'pair.join': {
        const now = Date.now(); let b = badByIp.get(c.ip); if (!b || now - b.since > 600_000) { b = { n: 0, since: now }; badByIp.set(c.ip, b); } if (b.n >= maxBad) return err(c, 'rate_limited', 'Too many wrong codes');
        const pin = str(m.pin, 6), e = /^\d{6}$/.test(pin) ? pins.get(pin) : undefined, host = e && e.exp > now ? hosts.get(e.hostId) : undefined;
        if (!e || !host) { b.n++; if (badByIp.size > 1000) badByIp.delete(badByIp.keys().next().value!); return err(c, 'invalid_pin'); }
        if (pending.has(c.id!)) return;
        const timer = setTimeout(() => { pending.delete(c.id!); send(c, { t: 'pair.rejected', reason: 'timeout' }); }, pairTimeout * 1000); (timer as any).unref?.();
        pending.set(c.id!, { hostId: host.id!, clientId: c.id!, timer }); pins.delete(pin);
        send(c, { t: 'pair.pending' }); return send(host, { t: 'pair.request', clientId: c.id, clientPublicKey: c.pub, clientName: c.name });
      }
      case 'session.open': {
        const to = str(m.to, 64), sid = str(m.sessionId, 64), host = hosts.get(to);
        if (!ID.test(to) || !SID.test(sid) || !Number.isInteger(m.seq) || !verifyB64u(c.pub!, sessionBytes({ t: 'session.open', from: c.id!, to, sessionId: sid, seq: m.seq }), str(m.sig, 120))) return err(c, 'bad_session');
        if (!allow.get(to)?.has(c.id!)) return err(c, 'not_paired', 'This phone is not approved on that PC');
        if (!host) return err(c, 'host_offline', 'The PC is offline');
        for (const [k, s] of sessions) if (s.host === to && s.client === c.id) sessions.delete(k);
        sessions.set(sid, { host: to, client: c.id! }); if (sessions.size > 500) sessions.delete(sessions.keys().next().value!);
        send(host, { t: 'session.created', sessionId: sid, peerId: c.id }); return send(c, { t: 'session.created', sessionId: sid, peerId: to });
      }
      case 'signal': case 'session.state': return relay(c, m);
    }
  }
  /** Forwards a signed session message to the other side of an existing session and stamps the real sender. The receiver re-verifies the signature. */
  function relay(c: Conn, m: any) {
    const sid = str(m.sessionId, 64), s = sessions.get(sid); if (!s) return;
    const mine = c.role === 'host' ? s.host === c.id : s.client === c.id; const to = str(m.to, 64); const other = c.role === 'host' ? s.client : s.host;
    if (!mine || to !== other || !Number.isInteger(m.seq)) return;
    const body = { sessionId: sid, to, from: c.id, seq: m.seq, sig: str(m.sig, 120) } as any;
    if (m.t === 'signal') { if (!['offer', 'answer', 'ice', 'bye'].includes(m.kind) || typeof m.data !== 'string' || m.data.length > 32768) return; Object.assign(body, { t: 'signal', kind: m.kind, data: m.data }); if (m.kind === 'bye') sessions.delete(sid); }
    else { const st = str(m.state, 20); Object.assign(body, { t: 'session.updated', state: st }); }
    send(c.role === 'host' ? clients.get(other) : hosts.get(other), body);
  }

  return new Promise((ok, bad) => {
    server.once('error', bad);
    server.listen(o.port ?? 0, o.host ?? '0.0.0.0', () => ok({ port: (server.address() as AddressInfo).port, stats: () => ({ hosts: hosts.size, clients: clients.size }), onlineClients: () => [...clients.keys()],
      close: () => new Promise<void>(res => { clearInterval(sweep); for (const c of [...hosts.values(), ...clients.values()]) try { c.ws.terminate(); } catch { /* gone */ } wss.close(); server.close(() => res()); }) }));
  });
}
