import { spawn, type ChildProcess } from 'node:child_process'; import dgram from 'node:dgram';
import type { Config } from './config.js';

export type Encoder = 'nvenc' | 'qsv' | 'amf' | 'x264';
export const VIDEO_PT = 96, AUDIO_PT = 111, VIDEO_SSRC = 0x4e585631, AUDIO_SSRC = 0x4e584131;
export const H264_FMTP = 'profile-level-id=42e02a;packetization-mode=1;level-asymmetry-allowed=1';
const GOP_SECONDS = 1;   // short GOP: the phone recovers from loss within ~1 s without needing the host to answer PLI requests

export interface VideoOpts { encoder: Encoder; capture: 'ddagrab' | 'gdigrab'; width: number; height: number; fps: number; bitrateKbps: number; port: number; inputArgs?: string[] }
const common = ['-hide_banner', '-loglevel', 'warning', '-nostdin'];

export function encoderArgs(e: Encoder, fps: number, kbps: number): string[] {
  const g = Math.round(fps * GOP_SECONDS), rate = ['-b:v', `${kbps}k`, '-maxrate', `${kbps}k`, '-bufsize', `${Math.round(kbps / 2)}k`];
  switch (e) {
    case 'nvenc': return ['-c:v', 'h264_nvenc', '-preset', 'p1', '-tune', 'll', '-rc', 'cbr', '-zerolatency', '1', '-profile:v', 'baseline', '-bf', '0', '-g', String(g), '-forced-idr', '1', ...rate];
    case 'qsv': return ['-c:v', 'h264_qsv', '-preset', 'veryfast', '-profile:v', 'baseline', '-look_ahead', '0', '-bf', '0', '-async_depth', '1', '-g', String(g), ...rate];
    case 'amf': return ['-c:v', 'h264_amf', '-usage', 'ultralowlatency', '-quality', 'speed', '-rc', 'cbr', '-profile:v', 'constrained_baseline', '-g', String(g), ...rate];
    default: return ['-c:v', 'libx264', '-preset', 'ultrafast', '-tune', 'zerolatency', '-profile:v', 'baseline', '-x264-params', `keyint=${g}:min-keyint=${g}:scenecut=0:repeat-headers=1:bframes=0`, '-g', String(g), ...rate];
  }
}
/** ffmpeg arguments: capture the desktop, scale/letterbox to the stream size, encode H.264 and send RTP to a local UDP port. */
export function buildVideoArgs(o: VideoOpts): string[] {
  const fit = `scale=${o.width}:${o.height}:force_original_aspect_ratio=decrease:flags=fast_bilinear,pad=${o.width}:${o.height}:(ow-iw)/2:(oh-ih)/2,format=yuv420p`;
  const input = o.inputArgs ?? (o.capture === 'ddagrab'
    ? ['-f', 'lavfi', '-i', `ddagrab=output_idx=0:framerate=${o.fps}:draw_mouse=1`]
    : ['-f', 'gdigrab', '-framerate', String(o.fps), '-draw_mouse', '1', '-i', 'desktop']);
  const pre = !o.inputArgs && o.capture === 'ddagrab' ? 'hwdownload,format=bgra,' : '';
  return [...common, ...input, '-an', '-vf', pre + fit, '-r', String(o.fps), ...encoderArgs(o.encoder, o.fps, o.bitrateKbps),
    '-bsf:v', 'dump_extra=freq=keyframe', '-f', 'rtp', '-payload_type', String(VIDEO_PT), '-ssrc', String(VIDEO_SSRC), '-flush_packets', '1', `rtp://127.0.0.1:${o.port}?pkt_size=1200`];
}
/** Audio: a DirectShow loopback device (e.g. "Stereo Mix" or "virtual-audio-capturer") -> Opus RTP. Returns null when no device is configured. */
export function buildAudioArgs(o: { audioDevice: string | null; port: number; inputArgs?: string[] }): string[] | null {
  const input = o.inputArgs ?? (o.audioDevice ? ['-f', 'dshow', '-audio_buffer_size', '50', '-i', `audio=${o.audioDevice}`] : null);
  if (!input) return null;
  return [...common, '-fflags', 'nobuffer', ...input, '-vn', '-c:a', 'libopus', '-b:a', '96k', '-application', 'lowdelay', '-frame_duration', '10', '-ar', '48000', '-ac', '2',
    '-f', 'rtp', '-payload_type', String(AUDIO_PT), '-ssrc', String(AUDIO_SSRC), '-flush_packets', '1', `rtp://127.0.0.1:${o.port}?pkt_size=1200`];
}
/** Extracts audio device names from `ffmpeg -list_devices true -f dshow -i dummy` output (both the old and the new format). */
export function parseDshowAudioDevices(stderr: string): string[] {
  const out: string[] = []; let inAudio = false;
  for (const line of stderr.split(/\r?\n/)) {
    if (/DirectShow audio devices/i.test(line)) { inAudio = true; continue; }
    if (/DirectShow video devices/i.test(line)) { inAudio = false; continue; }
    const m = /"([^"]+)"/.exec(line); if (!m || /alternative name/i.test(line)) continue;
    if (/\(audio\)/.test(line) || (inAudio && !/\(video\)/.test(line))) out.push(m[1]!);
  }
  return [...new Set(out)];
}
function run(ffmpeg: string, args: string[], spawner: typeof spawn, timeoutMs: number): Promise<{ code: number | null; err: string }> {
  return new Promise(res => {
    let err = ''; let child: ChildProcess; try { child = spawner(ffmpeg, args, { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true }); } catch { return res({ code: null, err: 'spawn failed' }); }
    const t = setTimeout(() => { child.kill(); res({ code: null, err: err + ' [timeout]' }); }, timeoutMs);
    child.stderr?.on('data', d => { err = (err + d).slice(-4000); });
    child.once('error', e => { clearTimeout(t); res({ code: null, err: String(e.message) }); });
    child.once('exit', code => { clearTimeout(t); res({ code, err }); });
  });
}
export async function hasFilter(ffmpeg: string, name: string, spawner: typeof spawn = spawn): Promise<boolean> {
  const r = await new Promise<string>(res => { let out = ''; let c: ChildProcess; try { c = spawner(ffmpeg, ['-hide_banner', '-filters'], { stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true }); } catch { return res(''); } const t = setTimeout(() => { c.kill(); res(out); }, 8000); c.stdout?.on('data', d => { out = (out + d).slice(-200000); }); c.once('error', () => { clearTimeout(t); res(''); }); c.once('exit', () => { clearTimeout(t); res(out); }); });
  return new RegExp(`\\s${name}\\s`).test(r);
}
export const listAudioDevices = async (ffmpeg: string, spawner: typeof spawn = spawn) => parseDshowAudioDevices((await run(ffmpeg, ['-hide_banner', '-list_devices', 'true', '-f', 'dshow', '-i', 'dummy'], spawner, 8000)).err);
/** A hardware encoder only counts if it can really encode one frame on this machine. */
export async function probeEncoder(ffmpeg: string, e: Encoder, spawner: typeof spawn = spawn): Promise<boolean> {
  const name = { nvenc: 'h264_nvenc', qsv: 'h264_qsv', amf: 'h264_amf', x264: 'libx264' }[e];
  return (await run(ffmpeg, [...common, '-f', 'lavfi', '-i', 'color=c=black:s=1280x720:r=30', '-frames:v', '2', '-c:v', name, '-f', 'null', '-'], spawner, 10000)).code === 0;
}
export async function pickEncoder(ffmpeg: string, want: Config['encoder'], spawner: typeof spawn = spawn): Promise<Encoder | null> {
  const order: Encoder[] = want === 'auto' ? ['nvenc', 'qsv', 'amf', 'x264'] : [want, 'x264'];
  for (const e of order) if (await probeEncoder(ffmpeg, e, spawner)) return e;
  return null;
}

export interface MediaSink { video(rtp: Buffer): void; audio(rtp: Buffer): void }
export interface Overrides { videoInput?: string[]; audioInput?: string[] }
type CapCfg = Pick<Config, 'ffmpegPath' | 'capture' | 'width' | 'height' | 'fps' | 'bitrateKbps' | 'audioDevice'>;
/** Owns the ffmpeg children and the two local UDP ports they send RTP to. Restarts a crashed encoder up to 3 times. */
export class Capture {
  private socks: { v?: dgram.Socket; a?: dgram.Socket } = {}; private procs: { v?: ChildProcess; a?: ChildProcess } = {};
  private ports = { v: 0, a: 0 }; private running = false; private kbps: number; private crashes = 0; private sink?: MediaSink;
  readonly counts = { video: 0, audio: 0, restarts: 0 };
  constructor(private cfg: CapCfg, private encoder: Encoder, private log: (e: string, f?: object) => void = () => {}, private spawner: typeof spawn = spawn, private over: Overrides = {}, private onFail?: (why: string) => void) { this.kbps = cfg.bitrateKbps; }
  get bitrate() { return this.kbps; }
  get active() { return this.running; }
  private bind(kind: 'v' | 'a', forward: (b: Buffer) => void): Promise<void> {
    return new Promise((ok, bad) => {
      const s = dgram.createSocket('udp4'); s.once('error', bad);
      s.on('message', m => { if (this.running) forward(m); });
      s.bind(0, '127.0.0.1', () => { this.ports[kind] = s.address().port; this.socks[kind] = s; ok(); });
    });
  }
  async start(sink: MediaSink) {
    if (this.running) return; this.sink = sink; this.crashes = 0;
    await this.bind('v', b => { this.counts.video++; sink.video(b); }); await this.bind('a', b => { this.counts.audio++; sink.audio(b); });
    this.running = true; this.spawnVideo(); this.spawnAudio();
  }
  private watch(kind: 'v' | 'a', p: ChildProcess) {
    let err = ''; let handled = false; p.stderr?.on('data', d => { err = (err + d).slice(-1500); });
    // 'error' (ffmpeg missing, blocked by antivirus, not executable) fires WITHOUT an 'exit' afterwards, so it must be handled like an exit or the phone waits on a black screen forever.
    const gone = (code: number | null) => {
      if (handled) return; handled = true;
      if (this.procs[kind] !== p) return;                 // replaced on purpose (bitrate change) or stopped
      this.procs[kind] = undefined; if (!this.running) return;
      this.log('ffmpeg_exit', { kind, code, tail: err.trim().slice(-300) });
      if (kind === 'a') return;                           // audio is optional: the video stream keeps going
      if (++this.crashes > 3) { this.running = false; this.onFail?.('Screen capture keeps failing: ' + (err.trim().split('\n').pop() ?? 'unknown error')); return; }
      setTimeout(() => { if (this.running) { this.counts.restarts++; this.spawnVideo(); } }, 1000);
    };
    p.once('error', e => { err += ' ' + e.message; gone(null); });
    p.once('exit', code => gone(code));
  }
  private spawnVideo() {
    const args = buildVideoArgs({ encoder: this.encoder, capture: this.cfg.capture, width: this.cfg.width, height: this.cfg.height, fps: this.cfg.fps, bitrateKbps: this.kbps, port: this.ports.v, inputArgs: this.over.videoInput });
    const p = this.procs.v = this.spawner(this.cfg.ffmpegPath, args, { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true }); this.watch('v', p);
    this.log('capture_start', { encoder: this.encoder, kbps: this.kbps, w: this.cfg.width, h: this.cfg.height, fps: this.cfg.fps });
  }
  private spawnAudio() {
    const args = buildAudioArgs({ audioDevice: this.cfg.audioDevice, port: this.ports.a, inputArgs: this.over.audioInput });
    if (!args) { this.log('audio_off', { why: 'no audioDevice configured' }); return; }
    const p = this.procs.a = this.spawner(this.cfg.ffmpegPath, args, { stdio: ['ignore', 'ignore', 'pipe'], windowsHide: true }); this.watch('a', p);
  }
  /** Changes resolution / frame rate / bitrate for the running stream (the phone's quality menu). ffmpeg is restarted once; the phone sees a short glitch and a new keyframe. Values are clamped. */
  setQuality(q: { width?: number; height?: number; fps?: number; kbps?: number }) {
    const c = (v: unknown, lo: number, hi: number, d: number) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(hi, Math.max(lo, Math.round(v))) : d);
    const w = c(q.width, 640, 3840, this.cfg.width) & ~1, h = c(q.height, 360, 2160, this.cfg.height) & ~1, f = c(q.fps, 15, 120, this.cfg.fps), k = c(q.kbps, 1000, 80000, this.kbps);
    if (w === this.cfg.width && h === this.cfg.height && f === this.cfg.fps && k === this.kbps) return;
    this.cfg = { ...this.cfg, width: w, height: h, fps: f }; this.kbps = k;
    if (!this.running) return;
    const old = this.procs.v; this.procs.v = undefined; old?.kill(); this.counts.restarts++; this.spawnVideo();
  }
  get quality() { return { width: this.cfg.width, height: this.cfg.height, fps: this.cfg.fps, kbps: this.kbps }; }
  /** ffmpeg cannot change bitrate while running, so the encoder is restarted (one short glitch). Callers rate-limit this. */
  setBitrate(kbps: number) {
    if (!this.running || Math.round(kbps) === this.kbps) return; this.kbps = Math.round(kbps);
    const old = this.procs.v; this.procs.v = undefined; old?.kill(); this.counts.restarts++; this.spawnVideo();
  }
  stop() {
    this.running = false;
    for (const k of ['v', 'a'] as const) { const p = this.procs[k]; this.procs[k] = undefined; try { p?.kill(); } catch { /* gone */ } try { this.socks[k]?.close(); } catch { /* closed */ } this.socks[k] = undefined; }
  }
}
