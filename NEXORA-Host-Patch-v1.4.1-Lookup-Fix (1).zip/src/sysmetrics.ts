import os from 'node:os'; import { spawn } from 'node:child_process';

export interface Metrics { cpuPct: number; cpuGhz: number; ramPct: number; ramUsedGb: number; ramTotalGb: number; gpuPct: number | null; gpuUsedGb: number | null; gpuTotalGb: number | null; gpuName: string | null }
const gb = (b: number) => Math.round(b / 1073741824 * 10) / 10;
const cpuTimes = () => { let idle = 0, total = 0; for (const c of os.cpus()) { const t = c.times; idle += t.idle; total += t.user + t.nice + t.sys + t.idle + t.irq; } return { idle, total }; };

/** Samples CPU / RAM (Node) and GPU (nvidia-smi, when an NVIDIA card is present) a couple of times per second. Never throws; GPU is null when unknown. */
export class SysMetrics {
  private prev = cpuTimes(); private cpu = 0; private gpu: { pct: number; used: number; total: number; name?: string } | null = null; private busy = false; private timer?: ReturnType<typeof setInterval>;
  readonly history: { t: number; cpu: number; gpu: number; ram: number }[] = [];
  constructor(private smi = 'nvidia-smi', private every = 2000) {}
  start() { if (this.timer) return; this.tick(); this.timer = setInterval(() => this.tick(), this.every); (this.timer as any).unref?.(); }
  stop() { clearInterval(this.timer); this.timer = undefined; }
  private tick() {
    const now = cpuTimes(), dt = now.total - this.prev.total, di = now.idle - this.prev.idle; this.prev = now;
    if (dt > 0) this.cpu = Math.max(0, Math.min(100, Math.round((1 - di / dt) * 100)));
    const m = this.read(); this.history.push({ t: Date.now(), cpu: m.cpuPct, gpu: m.gpuPct ?? 0, ram: m.ramPct }); if (this.history.length > 620) this.history.shift();
    if (!this.busy && this.smi) this.pollGpu();
  }
  private pollGpu() {
    this.busy = true; let out = ''; let done = false;
    const end = () => { if (done) return; done = true; this.busy = false; };
    try {
      const c = spawn(this.smi, ['--query-gpu=name,utilization.gpu,memory.used,memory.total', '--format=csv,noheader,nounits'], { stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true });
      const t = setTimeout(() => { try { c.kill(); } catch { /* gone */ } end(); }, 3000); (t as any).unref?.();
      c.stdout.on('data', d => (out += d));
      c.once('error', () => { clearTimeout(t); this.gpu = null; this.smi = ''; end(); });          // no NVIDIA driver: stop asking
      c.once('exit', () => { clearTimeout(t); const p = parseSmi(out); if (p) this.gpu = p; end(); });
    } catch { this.smi = ''; end(); }
  }
  read(): Metrics {
    const total = os.totalmem(), used = total - os.freemem();
    return { cpuPct: this.cpu, cpuGhz: Math.round((os.cpus()[0]?.speed ?? 0) / 100) / 10, ramPct: Math.round(used / total * 100), ramUsedGb: gb(used), ramTotalGb: gb(total),
      gpuPct: this.gpu ? this.gpu.pct : null, gpuUsedGb: this.gpu ? gb(this.gpu.used * 1048576) : null, gpuTotalGb: this.gpu ? gb(this.gpu.total * 1048576) : null, gpuName: this.gpu?.name ?? null };
  }
}
/** "NVIDIA GeForce RTX 3060, 42, 3012, 12288" (name, utilization %, MiB used, MiB total; the name is optional) -> numbers, or null for anything else. First GPU only. */
export function parseSmi(out: string): { pct: number; used: number; total: number; name?: string } | null {
  const line = out.split(/\r?\n/).find(l => l.trim()); if (!line) return null;
  const f = line.split(',').map(x => x.trim()); if (f.length < 3) return null;
  const nums = f.slice(-3).map(x => (/^\d+$/.test(x) ? +x : NaN)); if (nums.some(Number.isNaN)) return null;
  const name = f.slice(0, -3).join(', ').replace(/^NVIDIA\s+(GeForce\s+)?/i, '').slice(0, 40) || undefined;
  return { pct: nums[0]!, used: nums[1]!, total: nums[2]!, ...(name ? { name } : {}) };
}
