import dgram from 'node:dgram'; import http from 'node:http'; import os from 'node:os';
/** Remote access without any extra program or account: the PC asks the home router (UPnP) to forward the pairing port and a small UDP range,
 *  and learns its public address (STUN). The phone then reaches the PC from any network at <public address>:<port>.
 *  Honest limits: it needs a router with UPnP switched on and an ISP that gives a real public address (not CGNAT). The state below says which case you are in.
 *  No local imports on purpose: this file is tested on its own. */
export const UDP_BEGIN = 47810, UDP_END = 47819;
export type RemoteState = 'off' | 'checking' | 'open' | 'no-router' | 'cgnat' | 'failed';
type Log = (e: string, f?: object) => void;
export interface Igd { controlUrl: string; service: string; localIp: string }

const isPrivateOrCgnat = (ip: string) => /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.|169\.254\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.)/.test(ip);

// ---------- STUN: public address ----------
export function stunPublicIp(host = 'stun.l.google.com', port = 19302, timeoutMs = 2500): Promise<string | null> {
  return new Promise(res => {
    const s = dgram.createSocket('udp4'); const tx = Buffer.alloc(12); for (let i = 0; i < 12; i++) tx[i] = Math.floor(Math.random() * 256);
    const req = Buffer.alloc(20); req.writeUInt16BE(0x0001, 0); req.writeUInt16BE(0, 2); req.writeUInt32BE(0x2112a442, 4); tx.copy(req, 8);
    const done = (v: string | null) => { clearTimeout(t); try { s.close(); } catch { /* closed */ } res(v); };
    const t = setTimeout(() => done(null), timeoutMs); (t as any).unref?.();
    s.once('error', () => done(null));
    s.on('message', m => {
      if (m.length < 20 || m.readUInt16BE(0) !== 0x0101 || !m.subarray(8, 20).equals(tx)) return;
      let o = 20; const end = Math.min(m.length, 20 + m.readUInt16BE(2));
      while (o + 4 <= end) {
        const type = m.readUInt16BE(o), len = m.readUInt16BE(o + 2), v = o + 4;
        if ((type === 0x0020 || type === 0x0001) && len >= 8 && m[v + 1] === 0x01) {
          const b = [m[v + 4]!, m[v + 5]!, m[v + 6]!, m[v + 7]!]; if (type === 0x0020) { const c = [0x21, 0x12, 0xa4, 0x42]; for (let i = 0; i < 4; i++) b[i]! ^= c[i]!; }
          return done(b.join('.'));
        }
        o = v + len + ((4 - (len % 4)) % 4);
      }
      done(null);
    });
    s.send(req, port, host, e => { if (e) done(null); });
  });
}

// ---------- UPnP IGD ----------
const get = (url: string, timeoutMs: number) => new Promise<string>((ok, bad) => { const r = http.get(url, { timeout: timeoutMs }, res => { let b = ''; res.setEncoding('utf8'); res.on('data', d => { b += d; if (b.length > 200_000) r.destroy(); }); res.on('end', () => ok(b)); }); r.on('timeout', () => r.destroy(new Error('timeout'))); r.on('error', bad); });
function soap(i: Igd, action: string, args: Record<string, string | number>, timeoutMs = 4000): Promise<string> {
  const body = `<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:${action} xmlns:u="${i.service}">${Object.entries(args).map(([k, v]) => `<${k}>${v}</${k}>`).join('')}</u:${action}></s:Body></s:Envelope>`;
  return new Promise((ok, bad) => {
    const u = new URL(i.controlUrl);
    const r = http.request({ host: u.hostname, port: u.port, path: u.pathname + u.search, method: 'POST', timeout: timeoutMs, headers: { 'content-type': 'text/xml; charset="utf-8"', soapaction: `"${i.service}#${action}"`, 'content-length': Buffer.byteLength(body) } }, res => {
      let b = ''; res.setEncoding('utf8'); res.on('data', d => (b += d)); res.on('end', () => (res.statusCode === 200 && !/<errorCode>/.test(b) ? ok(b) : bad(new Error(`${action} refused: ${(/<errorDescription>([^<]*)/.exec(b)?.[1] ?? res.statusCode)}`))));
    });
    r.on('timeout', () => r.destroy(new Error('timeout'))); r.on('error', bad); r.end(body);
  });
}
export interface DiscoverOpts { targets?: { host: string; port: number }[]; timeoutMs?: number }
/** Finds the router: SSDP multicast on every real network interface. `targets` lets tests aim at a fake router. */
export async function discoverIgd(o: DiscoverOpts = {}): Promise<Igd | null> {
  const timeout = o.timeoutMs ?? 2500, STs = ['urn:schemas-upnp-org:device:InternetGatewayDevice:1', 'urn:schemas-upnp-org:device:InternetGatewayDevice:2'];
  const location = await new Promise<string | null>(res => {
    const socks: dgram.Socket[] = []; let fin = false;
    const done = (v: string | null) => { if (fin) return; fin = true; clearTimeout(t); for (const s of socks) { try { s.close(); } catch { /* closed */ } } res(v); };
    const t = setTimeout(() => done(null), timeout); (t as any).unref?.();
    const targets = o.targets ?? [{ host: '239.255.255.250', port: 1900 }];
    const binds: (string | undefined)[] = o.targets ? [undefined] : [...new Set(Object.values(os.networkInterfaces()).flatMap(l => (l ?? []).filter(a => a.family === 'IPv4' && !a.internal).map(a => a.address)))];
    if (!binds.length) return done(null);
    for (const addr of binds) {
      const s = dgram.createSocket({ type: 'udp4', reuseAddr: true }); socks.push(s); s.on('error', () => {});
      s.on('message', m => { const loc = /^location:\s*(\S+)/im.exec(m.toString('utf8'))?.[1]; if (loc && /^http:\/\//i.test(loc)) done(loc); });
      s.bind(0, addr, () => { for (const tg of targets) for (const st of STs) { const msg = Buffer.from(`M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: "ssdp:discover"\r\nMX: 1\r\nST: ${st}\r\n\r\n`); try { s.send(msg, tg.port, tg.host); } catch { /* interface down */ } } });
    }
  });
  if (!location) return null;
  try {
    const xml = await get(location, 3000);
    for (const blk of xml.split('<service>').slice(1)) {
      const type = /<serviceType>\s*(urn:schemas-upnp-org:service:WAN(?:IP|PPP)Connection:\d)\s*<\/serviceType>/.exec(blk)?.[1], ctl = /<controlURL>\s*([^<\s]+)\s*<\/controlURL>/.exec(blk)?.[1];
      if (type && ctl) { const controlUrl = new URL(ctl, location).toString(), gw = new URL(location);
        const localIp = await new Promise<string>((ok, bad) => { const s = dgram.createSocket('udp4'); s.once('error', bad); s.connect(Number(gw.port) || 80, gw.hostname, () => { const a = s.address().address; s.close(); ok(a); }); });
        return { controlUrl, service: type, localIp }; }
    }
  } catch { /* unreadable description */ }
  return null;
}
export const mapPort = (i: Igd, proto: 'TCP' | 'UDP', port: number, lease = 7200) => soap(i, 'AddPortMapping', { NewRemoteHost: '', NewExternalPort: port, NewProtocol: proto, NewInternalPort: port, NewInternalClient: i.localIp, NewEnabled: 1, NewPortMappingDescription: 'NEXORA Host', NewLeaseDuration: lease });
export const unmapPort = (i: Igd, proto: 'TCP' | 'UDP', port: number) => soap(i, 'DeletePortMapping', { NewRemoteHost: '', NewExternalPort: port, NewProtocol: proto });
export async function routerExternalIp(i: Igd): Promise<string | null> { try { return /<NewExternalIPAddress>([^<]*)</.exec(await soap(i, 'GetExternalIPAddress', {}))?.[1]?.trim() || null; } catch { return null; } }

// ---------- orchestration ----------
export class RemoteAccess {
  state: RemoteState = 'off'; publicIp: string | null = null; detail = 'Remote access is off.';
  private igd?: Igd; private timer?: ReturnType<typeof setInterval>; private stopped = false; private o: { tcpPort: number; log?: Log; discover?: DiscoverOpts; stun?: { host: string; port: number } };
  constructor(o: { tcpPort: number; log?: Log; discover?: DiscoverOpts; stun?: { host: string; port: number } }) { this.o = o; }
  get address(): string | null { return this.state === 'open' && this.publicIp ? `${this.publicIp}:${this.o.tcpPort}` : null; }
  async start() {
    this.stopped = false; this.state = 'checking'; this.detail = 'Opening your router for remote play…';
    await this.refresh(); if (this.stopped) return;
    this.timer = setInterval(() => void this.refresh(), 3_600_000); (this.timer as any).unref?.();   // leases last 2 h, renewed hourly; also picks up a changed public IP
  }
  private async refresh() {
    const log = this.o.log ?? (() => {});
    try {
      const igd = this.igd ?? await discoverIgd(this.o.discover); if (this.stopped) return;
      const stunIp = await stunPublicIp(this.o.stun?.host, this.o.stun?.port);
      if (!igd) { this.igd = undefined; this.publicIp = stunIp; this.state = 'no-router'; this.detail = 'Your router did not answer automatic port opening (UPnP). Turn UPnP on in the router, or forward port ' + this.o.tcpPort + ' (TCP) and ' + UDP_BEGIN + '-' + UDP_END + ' (UDP) to this PC.'; log('remote', { state: this.state }); return; }
      this.igd = igd;
      await mapPort(igd, 'TCP', this.o.tcpPort); let udp = 0; for (let p = UDP_BEGIN; p <= UDP_END; p++) { try { await mapPort(igd, 'UDP', p); udp++; } catch { /* some routers cap the number of rules */ } }
      const routerIp = await routerExternalIp(igd); const ip = routerIp && !isPrivateOrCgnat(routerIp) ? routerIp : stunIp && !isPrivateOrCgnat(stunIp) ? stunIp : null;
      if (routerIp && isPrivateOrCgnat(routerIp)) { this.publicIp = null; this.state = 'cgnat'; this.detail = 'Your internet provider shares one public address between many customers (CGNAT), so this PC cannot be reached from outside. Ask the provider for a public IP, or use a VPN/relay.'; }
      else if (ip) { this.publicIp = ip; this.state = 'open'; this.detail = `Ready: ${ip}:${this.o.tcpPort}`; }
      else { this.publicIp = null; this.state = 'failed'; this.detail = 'The router accepted the request but the public address could not be determined.'; }
      log('remote', { state: this.state, udp, ip: this.publicIp ?? undefined });
    } catch (e) { this.state = 'failed'; this.detail = 'Automatic port opening failed: ' + (e instanceof Error ? e.message : String(e)); this.o.log?.('remote', { state: 'failed', err: this.detail }); }
  }
  async stop() {
    this.stopped = true; clearInterval(this.timer); const i = this.igd; this.igd = undefined; this.state = 'off';
    if (i) { try { await unmapPort(i, 'TCP', this.o.tcpPort); for (let p = UDP_BEGIN; p <= UDP_END; p++) await unmapPort(i, 'UDP', p).catch(() => {}); } catch { /* router already forgot them (lease) */ } }
  }
}
