import { spawn } from 'node:child_process'; import net from 'node:net'; import os from 'node:os';
import { dirs } from './paths.js'; import { loadConfig } from './config.js'; import { probeEncoder, hasFilter, listAudioDevices, type Encoder } from './capture.js';

export interface Check { ok: boolean | 'warn'; name: string; detail: string }
const run = (cmd: string, args: string[]) => new Promise<string>(res => { let o = ''; try { const c = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true }); const t = setTimeout(() => { c.kill(); res(o); }, 8000); c.stdout?.on('data', d => (o += d)); c.stderr?.on('data', d => (o += d)); c.once('error', () => { clearTimeout(t); res(''); }); c.once('exit', () => { clearTimeout(t); res(o); }); } catch { res(''); } });
const portFree = (port: number) => new Promise<boolean>(res => { const s = net.createServer(); s.once('error', () => res(false)); s.listen(port, '0.0.0.0', () => s.close(() => res(true))); });
/** Release builds say "6.1"; gyan.dev builds say "2024-05-01-git-..."; git-master builds say "N-113000-g..." (always recent, reported as 99). */
export const ffmpegMajor = (v: string) => { if (/ffmpeg version N-/.test(v)) return 99; const m = /ffmpeg version n?(\d+)/i.exec(v); return m ? Number(m[1]) : null; };

/** Everything that commonly goes wrong on a first run, in one list, with the fix next to each problem. */
export async function doctor(root?: string): Promise<Check[]> {
  const d = dirs(root), cfg = loadConfig(d), out: Check[] = [];
  const node = Number(process.versions.node.split('.')[0]); out.push({ ok: node >= 22, name: 'Node.js', detail: node >= 22 ? `v${process.versions.node}` : `v${process.versions.node}: version 22 or newer is required (nodejs.org)` });
  const v = await run(cfg.ffmpegPath, ['-version']); const major = ffmpegMajor(v);
  out.push({ ok: major !== null, name: 'ffmpeg', detail: major !== null ? `found (${cfg.ffmpegPath}), version ${major}` : 'NOT FOUND: download a "full" build from gyan.dev, then put ffmpeg.exe in the NEXORA folder' });
  if (major !== null) {
    if (major < 6) out.push({ ok: 'warn', name: 'ffmpeg version', detail: 'older than 6.0: screen capture will use the slower gdigrab; update ffmpeg' });
    const found: Encoder[] = []; for (const e of ['nvenc', 'qsv', 'amf', 'x264'] as Encoder[]) if (await probeEncoder(cfg.ffmpegPath, e)) found.push(e);
    out.push({ ok: found.length > 0, name: 'video encoder', detail: found.length ? `usable: ${found.join(', ')} (will use ${cfg.encoder === 'auto' ? found[0] : found.includes(cfg.encoder) ? cfg.encoder : found[0]})` : 'none works: ffmpeg needs libx264 or a GPU encoder' });
    if (process.platform === 'win32') {
      out.push({ ok: (await hasFilter(cfg.ffmpegPath, 'ddagrab')) ? true : 'warn', name: 'screen capture', detail: (await hasFilter(cfg.ffmpegPath, 'ddagrab')) ? 'ddagrab (fast desktop duplication)' : 'ddagrab missing, will use gdigrab (slower)' });
      const au = await listAudioDevices(cfg.ffmpegPath); out.push({ ok: cfg.audioDevice ? true : 'warn', name: 'game audio', detail: cfg.audioDevice ? `using "${cfg.audioDevice}"` : au.length ? `not set. Pick one in the panel: ${au.slice(0, 3).join(' | ')}` : 'no loopback device found: enable "Stereo Mix" in Windows Sound settings, or the stream is video-only' });
    }
  }
  for (const [mod, why] of [['node-datachannel', 'streaming'], ['koffi', 'keyboard/mouse control (Windows)'], ['ws', 'pairing server']] as const) {
    let ok = true; try { await import(mod); } catch { ok = false; }
    out.push({ ok: ok ? true : mod === 'koffi' && process.platform !== 'win32' ? 'warn' : false, name: mod, detail: ok ? 'installed' : `missing, needed for ${why}: run "npm install" in this folder` });
  }
  const free = await portFree(cfg.serverPort); out.push({ ok: free ? true : 'warn', name: `port ${cfg.serverPort}`, detail: free ? 'free' : 'in use: is NEXORA Host already running?' });
  const ips: string[] = []; for (const l of Object.values(os.networkInterfaces())) for (const a of l ?? []) if (a.family === 'IPv4' && !a.internal && !a.address.startsWith('169.254.')) ips.push(a.address);
  out.push({ ok: ips.length > 0, name: 'network', detail: ips.length ? `phone address: ${ips[0]}:${cfg.serverPort}${ips.length > 1 ? `  (others: ${ips.slice(1).join(', ')})` : ''}` : 'no network address: connect this PC to Wi-Fi or Ethernet' });
  if (process.platform === 'win32') out.push({ ok: 'warn', name: 'firewall', detail: `if the phone cannot find the PC: run setup.bat as Administrator once (opens port ${cfg.serverPort} on private networks)` });
  out.push({ ok: cfg.turnUrls.length && cfg.turnUser ? true : 'warn', name: 'internet relay (TURN)', detail: cfg.turnUrls.length && cfg.turnUser ? 'configured' : 'not set: fine on the same Wi-Fi; playing over mobile data / from another network needs one (see README)' });
  return out;
}
export const format = (cs: Check[]) => cs.map(c => `${c.ok === true ? '[ OK ]' : c.ok === 'warn' ? '[WARN]' : '[FAIL]'} ${c.name.padEnd(22)} ${c.detail}`).join('\n');
if (import.meta.url === new URL(process.argv[1] ?? '', 'file://').href || process.argv[1]?.endsWith('doctor.ts')) { const r = await doctor(); console.log('\nNEXORA Host check\n' + format(r) + '\n'); process.exit(r.some(c => c.ok === false) ? 1 : 0); }
