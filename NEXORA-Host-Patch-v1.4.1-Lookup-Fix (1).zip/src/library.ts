import fs from 'node:fs'; import path from 'node:path'; import { createHash } from 'node:crypto';
import { spawn, type ChildProcess } from 'node:child_process';
import { JsonStore } from './store.js'; import type { Dirs } from './paths.js'; import { cleanName } from './meta.js';
export interface GameProfile { id: string; name: string; exe: string; cwd: string; layout?: string; lastPlayed?: number; playMs?: number }
export type Spawner = typeof spawn;
export class GameLibrary {
  private store: JsonStore<GameProfile[]>; private running = new Map<string, ChildProcess>();
  constructor(d: Dirs, private spawner: Spawner = spawn) { this.store = new JsonStore(path.join(d.games, 'games.json'), []); }
  list(): GameProfile[] { return this.store.load(); }
  add(p: { name: string; exe: string; cwd?: string }): GameProfile {
    const exe = path.resolve(p.exe);
    if (!/\.exe$/i.test(exe)) throw new Error('Select an .exe file');
    if (!fs.existsSync(exe)) throw new Error('Game executable is missing');
    const g: GameProfile = { id: createHash('sha256').update(exe.toLowerCase()).digest('hex').slice(0, 16), name: p.name.trim().slice(0, 80) || cleanName(path.basename(exe)) || path.basename(exe, '.exe'), exe, cwd: p.cwd ? path.resolve(p.cwd) : path.dirname(exe) };
    this.store.save([...this.list().filter(x => x.id !== g.id), g]); return g;
  }
  rename(id: string, name: string) { const n = name.trim().slice(0, 80); if (!n) throw new Error('Name cannot be empty'); if (!this.list().some(g => g.id === id)) throw new Error('Game not found'); this.store.save(this.list().map(g => g.id === id ? { ...g, name: n } : g)); }
  isRunning(id: string) { return this.running.has(id); }
  remove(id: string) { this.store.save(this.list().filter(g => g.id !== id)); }
  /** Receiver-facing view: only id, name, lastPlayed. Paths never leave the PC. */
  toWire() { return this.list().map(g => ({ id: g.id, name: g.name, lastPlayed: g.lastPlayed, installed: fs.existsSync(g.exe) })); }
  /** Starts only the stored exe; tracks only its own child. onExit fires on exit or spawn failure. */
  launch(id: string, onExit: (code: number | null) => void): void {
    const g = this.list().find(x => x.id === id); if (!g) throw new Error('Game not found');
    if (this.running.has(id)) return;
    if (!fs.existsSync(g.exe)) throw new Error('Game executable is missing');
    const child = this.spawner(g.exe, [], { cwd: g.cwd, detached: true, stdio: 'ignore' });
    this.running.set(id, child);
    const startedAt = Date.now();
    const done = (c: number | null) => {
      if (!this.running.delete(id)) return;
      // Playtime: only counts sessions that lasted at least 20 s (launchers often exit their first process at once).
      const ms = Date.now() - startedAt; if (ms >= 20_000) this.store.save(this.list().map(x => x.id === id ? { ...x, playMs: (x.playMs ?? 0) + ms } : x));
      onExit(c);
    };
    child.once('exit', done); child.once('error', () => done(null)); child.unref?.();
    this.store.save(this.list().map(x => x.id === id ? { ...x, lastPlayed: Date.now() } : x));
  }
  stop(id: string) { this.running.get(id)?.kill(); }  // never touches processes we did not start
}
