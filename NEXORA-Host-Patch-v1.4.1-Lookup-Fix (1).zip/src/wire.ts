import { createPublicKey, verify } from 'node:crypto';
/** Byte-exact copies of the receiver's signing formats (src/lib/signaling.ts). Change both or neither. */
export const V = 2;
const enc = (v: unknown) => Buffer.from(JSON.stringify(v), 'utf8');
export const authBytes = (role: string, id: string, nonce: string) => enc(['NEXORA-auth', V, role, id, nonce]);
export type SessionMsg = { t: string; from: string; to: string; sessionId: string; seq: number; state?: string; kind?: string; data?: string };
export const sessionBytes = (m: SessionMsg) =>
  enc(['NEXORA-signaling', V, m.t, m.from, m.to, m.sessionId, m.seq, ...(m.t === 'signal' ? [m.kind, m.data] : m.t === 'session.state' ? [m.state] : [])]);
const SPKI = Buffer.from('302a300506032b6570032100', 'hex');
export function verifyB64u(publicKey: string, bytes: Buffer, sig: string): boolean {
  try { return verify(null, bytes, createPublicKey({ key: Buffer.concat([SPKI, Buffer.from(publicKey, 'base64url')]), format: 'der', type: 'spki' }), Buffer.from(sig, 'base64url')); } catch { return false; }
}
