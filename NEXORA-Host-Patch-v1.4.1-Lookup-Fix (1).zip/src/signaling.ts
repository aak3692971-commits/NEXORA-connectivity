import { authBytes, sessionBytes, V, verifyB64u, type SessionMsg } from './wire.js';
import type { Identity } from './identity.js'; import { JsonStore } from './store.js'; import path from 'node:path'; import type { Dirs } from './paths.js';
export interface Paired { id: string; publicKey: string; name: string; pairedAt: number; lastSeen?: number }
export interface PairRequest { clientId: string; clientPublicKey: string; clientName: string }
export interface Hooks { onPin?(pin: string, ttl: number): void; onPairRequest(r: PairRequest): Promise<boolean>; onSession?(peer: Paired, sessionId: string): void; onSignal?(peer: Paired, m: SessionMsg & { sig?: string }): void; onStatus?(s: string): void }
type WS = { send(d: string): void; close(): void; onopen: any; onmessage: any; onclose: any; onerror: any };

/** Host side of signaling protocol v2 (mirrors the receiver). Pairing + session announcements only; media never passes here. */
export class HostSignaling {
  private ws?: WS; private paired: JsonStore<Paired[]>; private seq = 0; private nonce = ''; private stopped = false; private attempts = 0; private lastSeq = new Map<string, number>(); private timer?: ReturnType<typeof setTimeout>;
  constructor(private id: Identity, d: Dirs, private url: string, private hooks: Hooks, private name = 'NEXORA PC', private Ctor: new (u: string) => WS = (globalThis as any).WebSocket) { this.paired = new JsonStore(path.join(d.data, 'paired.json'), []); }
  setUrl(u: string) { this.url = u; }
  pairedList() { return this.paired.load(); }
  /** Remembers when a phone last opened a session (shown as "last seen" in the dashboard). */
  touch(id: string) { const l = this.pairedList(); if (l.some(p => p.id === id)) this.paired.save(l.map(p => p.id === id ? { ...p, lastSeen: Date.now() } : p)); }
  revoke(id: string) { this.paired.save(this.pairedList().filter(p => p.id !== id)); this.sendAllow(); }   // server drops the client immediately
  /** Connects and keeps reconnecting (1s, 2s, 4s ... max 30s) until close() is called. */
  connect() {
    this.stopped = false; clearTimeout(this.timer);
    let ws: WS; try { ws = this.ws = new this.Ctor(this.url); } catch { this.hooks.onStatus?.('disconnected'); this.retry(); return; }
    ws.onopen = () => { this.attempts = 0; this.hooks.onStatus?.('connected'); };
    ws.onerror = () => {};
    ws.onclose = () => { if (this.ws === ws) this.ws = undefined; this.hooks.onStatus?.('disconnected'); this.retry(); };
    ws.onmessage = (e: { data: string }) => { let m: any; try { m = JSON.parse(String(e.data)); } catch { return; } void this.handle(m); };
  }
  openPairing() { this.raw({ t: 'pair.open' }); }
  private retry() { if (this.stopped) return; const delay = Math.min(30000, 1000 * 2 ** Math.min(this.attempts++, 5)); this.timer = setTimeout(() => this.connect(), delay); (this.timer as any)?.unref?.(); }
  get online() { return !!this.ws; }
  close() { this.stopped = true; clearTimeout(this.timer); try { this.ws?.close(); } catch { /* already closed */ } this.ws = undefined; }
  /** Sends a signed session message (signal / session.state) to a paired phone. */
  sendSession(m: Omit<SessionMsg, 'from' | 'seq'>) { this.raw(this.signed(m)); }
  get deviceId() { return this.id.deviceId; }
  /** Sign a session message the way the receiver verifies it. */
  signed(m: Omit<SessionMsg, 'from' | 'seq'>) { const full = { ...m, from: this.id.deviceId, seq: ++this.seq }; return { ...m, seq: full.seq, sig: this.id.sign(sessionBytes(full)) }; }
  verifyFrom(peer: Paired, m: SessionMsg & { sig?: string }) { return typeof m.sig === 'string' && m.from === peer.id && verifyB64u(peer.publicKey, sessionBytes(m), m.sig); }
  private raw(o: object) { try { this.ws?.send(JSON.stringify({ protocolVersion: V, ...o })); } catch { /* socket closing; reconnect will resync allow-list */ } }
  private sendAllow() { this.raw({ t: 'allow.set', clientIds: this.pairedList().map(p => p.id) }); }
  private async handle(m: any) {
    switch (m.t) {
      case 'hello': this.nonce = String(m.nonce); this.raw({ t: 'auth', role: 'host', deviceId: this.id.deviceId, publicKey: this.id.publicKey, sig: this.id.sign(authBytes('host', this.id.deviceId, this.nonce)), name: this.name }); break;
      case 'ready': this.sendAllow(); break;
      case 'pair.opened': this.hooks.onPin?.(m.pin, m.expiresInSec); break;
      case 'pair.request': {
        const r: PairRequest = { clientId: m.clientId, clientPublicKey: m.clientPublicKey, clientName: String(m.clientName ?? 'Phone').slice(0, 48) };
        if (await this.hooks.onPairRequest(r)) {
          this.paired.save([...this.pairedList().filter(p => p.id !== r.clientId), { id: r.clientId, publicKey: r.clientPublicKey, name: r.clientName, pairedAt: Date.now() }]);
          this.raw({ t: 'pair.accept', clientId: r.clientId }); this.sendAllow();
        } else this.raw({ t: 'pair.reject', clientId: r.clientId });
        break;
      }
      case 'signal': case 'session.state': {
        const peer = this.pairedList().find(p => p.id === m.from);
        if (!peer || m.to !== this.id.deviceId || !this.verifyFrom(peer, m)) break;           // unknown peer, wrong target or bad signature: drop
        const k = `${m.sessionId}:${m.from}`, last = this.lastSeq.get(k) ?? -1;
        if (!Number.isInteger(m.seq) || m.seq <= last) break;                                  // replay / reorder: drop
        this.lastSeq.set(k, m.seq); if (this.lastSeq.size > 256) this.lastSeq.delete(this.lastSeq.keys().next().value!);
        if (m.t === 'signal') this.hooks.onSignal?.(peer, m);
        break;
      }
      case 'session.created': { const peer = this.pairedList().find(p => p.id === m.peerId); if (peer && typeof m.sessionId === 'string') this.hooks.onSession?.(peer, m.sessionId); break; }
    }
  }
}
