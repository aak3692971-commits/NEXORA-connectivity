import type { InputEvent, InputSink } from './input.js';

/** Low-level output: what a real OS backend (Windows SendInput) has to do. */
export interface OsInput { key(name: string, down: boolean): void; mouseMove(dx: number, dy: number): void; mouseButton(b: 'left' | 'right', down: boolean): void }

/** Phone controls -> keyboard keys. A virtual gamepad driver is a separate add-on; until then gamepad buttons drive keyboard keys so games work out of the box. */
export const DEFAULT_KEYMAP: Record<string, string> = {
  A: 'SPACE', B: 'C', X: 'R', Y: 'Q', LB: 'Q', RB: 'E', LT: 'SHIFT', RT: 'ENTER', START: 'ESC', BACK: 'TAB', L3: 'CTRL', R3: 'V',
  DPAD_UP: 'UP', DPAD_DOWN: 'DOWN', DPAD_LEFT: 'LEFT', DPAD_RIGHT: 'RIGHT',
};
const STICK_ON = .35, STICK_OFF = .2;   // hysteresis so a stick resting near the threshold does not flicker the key
const CODEKEY = /^KEY_([A-Z0-9]+)$/;

/** Turns validated phone events into OS input. Stateless for buttons; the stick keeps per-direction state. */
export class InputMapper implements InputSink {
  private dir = { W: false, A: false, S: false, D: false };
  private x = 0; private y = 0;
  constructor(private os: OsInput, private keymap: Record<string, string> = DEFAULT_KEYMAP) {}
  apply(e: InputEvent) {
    if (e.kind === 'pointer') return this.os.mouseMove(Math.round(e.dx), Math.round(e.dy));
    if (e.kind === 'axis') { if (e.control === 'moveX') this.x = e.value; else this.y = e.value; return this.sticks(); }
    const c = e.control;
    if (c === 'MOUSE_LEFT') return this.os.mouseButton('left', e.pressed);
    if (c === 'MOUSE_RIGHT') return this.os.mouseButton('right', e.pressed);
    const m = CODEKEY.exec(c); const key = m ? m[1]! : this.keymap[c];
    if (key) this.os.key(key, e.pressed);                       // unknown controls are ignored, never guessed
  }
  private sticks() {
    this.set('D', this.x, true); this.set('A', this.x, false); this.set('S', this.y, true); this.set('W', this.y, false);
  }
  private set(k: 'W' | 'A' | 'S' | 'D', v: number, positive: boolean) {
    const mag = positive ? v : -v, on = this.dir[k];
    const next = on ? mag > STICK_OFF : mag > STICK_ON;
    if (next !== on) { this.dir[k] = next; this.os.key(k, next); }
  }
}
