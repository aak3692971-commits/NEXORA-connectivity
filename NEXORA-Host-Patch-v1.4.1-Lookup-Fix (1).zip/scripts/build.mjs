// Bundles the desktop app (electron/main.ts + the entire host) into dist/main.mjs
// and copies the UI + preload next to it.
import { build } from 'esbuild';
import fs from 'node:fs';

fs.rmSync('dist', { recursive: true, force: true });
fs.mkdirSync('dist/ui', { recursive: true });

await build({
  entryPoints: ['electron/main.ts'],
  outfile: 'dist/main.mjs',
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node22',
  sourcemap: false,
  logLevel: 'info',
  // Native / runtime-resolved packages stay outside the bundle
  external: ['electron', 'node-datachannel', 'koffi', 'ws'],
  // Make require() available inside the ESM bundle (some deps still expect it)
  banner: {
    js: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);",
  },
});

// Static assets that must sit next to the main process
fs.copyFileSync('electron/preload.cjs', 'dist/preload.cjs');
fs.copyFileSync('src/ui/index.html', 'dist/ui/index.html');
{ let ui = fs.readFileSync('dist/ui/index.html', 'utf8');
  ui = ui.replace(/\/assets\/([a-z0-9-]+)\.png/g, (m, n) => { const f = `src/ui/assets/${n}.png`; return fs.existsSync(f) ? 'data:image/png;base64,' + fs.readFileSync(f).toString('base64') : m; });
  fs.writeFileSync('dist/ui/index.html', ui); }
if (fs.existsSync('src/ui/empty-hero.jpg')) fs.copyFileSync('src/ui/empty-hero.jpg', 'dist/ui/empty-hero.jpg');
if (fs.existsSync('src/ui/assets')) fs.cpSync('src/ui/assets', 'dist/ui/assets', { recursive: true });
if (fs.existsSync('src/ui/controller-card.jpg')) fs.copyFileSync('src/ui/controller-card.jpg', 'dist/ui/controller-card.jpg');

// Icon – so the tray / window can find it both in dev and packaged
if (fs.existsSync('build/icon.png')) {
  fs.copyFileSync('build/icon.png', 'dist/icon.png');
}

const required = ['dist/main.mjs', 'dist/preload.cjs', 'dist/ui/index.html'];
for (const f of required) {
  if (!fs.existsSync(f)) {
    console.error('BUILD INCOMPLETE: missing ' + f);
    process.exit(1);
  }
}

// Quick sanity: main.mjs should be reasonably large (host code is inside it)
const size = fs.statSync('dist/main.mjs').size;
console.log(`built dist/  (main.mjs = ${(size / 1024).toFixed(1)} KB)`);
if (size < 50_000) {
  console.warn('WARNING: dist/main.mjs looks very small – host modules may not have been bundled.');
}
