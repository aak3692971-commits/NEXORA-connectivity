// Standalone rollback: puts back the backup made by the last update. No dependencies, works even if the app itself is broken.
// Usage: <node or NEXORA Host.exe with ELECTRON_RUN_AS_NODE=1> rollback.mjs <app-folder> [backup.zip]
import fs from 'node:fs'; import path from 'node:path'; import os from 'node:os'; import zlib from 'node:zlib'; import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || path.dirname(fileURLToPath(import.meta.url)));
const SKIP = new Set(['node_modules', '.git', 'release', '__MACOSX', 'nexora-data', 'backups', 'config', 'games', 'layouts', 'logs', 'cache', 'data']);
const say = m => console.log(m);
const die = m => { console.error('\nROLLBACK FAILED: ' + m); process.exit(1); };
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(b) { let c = 0xffffffff; for (const byte of b) c = CRC[(c ^ byte) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }

function safeRel(name) { const p = String(name).replace(/\\/g, '/').split('/').filter(x => x && x !== '.'); return !p.length || p.some(x => x === '..' || x.includes(':')) ? null : p.join('/'); }
function walk(dir, base = dir, out = []) { if (!fs.existsSync(dir)) return out; for (const n of fs.readdirSync(dir, { withFileTypes: true })) { const f = path.join(dir, n.name); n.isDirectory() ? walk(f, base, out) : out.push(path.relative(base, f).split(path.sep).join('/')); } return out; }
function readZip(buf) {
  let e = -1; for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('The backup is not a zip file.');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('The backup is damaged.');
    const method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), cs = buf.readUInt32LE(p + 20), us = buf.readUInt32LE(p + 24), nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nl).replace(/\\/g, '/'); p += 46 + nl + el + cl;
    out.push({ name, dir: name.endsWith('/'), read() { const s = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28), raw = buf.subarray(s, s + cs); const d = method === 0 ? Buffer.from(raw) : method === 8 ? zlib.inflateRawSync(raw) : (() => { throw new Error('The backup uses unsupported compression.'); })(); if (d.length !== us || crc32(d) !== crc) throw new Error('The backup is damaged.'); return d; } });
  }
  return out;
}
async function writeZip(file, items) {
  const local = [], central = []; let offset = 0;
  for (const item of items) {
    const name = Buffer.from(item.name, 'utf8'), data = zlib.deflateRawSync(item.data), crc = crc32(item.data);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(8, 8); h.writeUInt16LE(0x21, 12); h.writeUInt32LE(crc, 14); h.writeUInt32LE(data.length, 18); h.writeUInt32LE(item.data.length, 22); h.writeUInt16LE(name.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8); c.writeUInt16LE(8, 10); c.writeUInt16LE(0x21, 14); c.writeUInt32LE(crc, 16); c.writeUInt32LE(data.length, 20); c.writeUInt32LE(item.data.length, 24); c.writeUInt16LE(name.length, 28); c.writeUInt32LE(offset, 42);
    local.push(h, name, data); central.push(c, name); offset += 30 + name.length + data.length;
  }
  const cd = Buffer.concat(central), end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(items.length, 8); end.writeUInt16LE(items.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(offset, 16);
  fs.mkdirSync(path.dirname(file), { recursive: true }); const tmp = file + '.part'; fs.writeFileSync(tmp, Buffer.concat([...local, cd, end])); fs.renameSync(tmp, file);
}
function findBackup() {
  if (process.argv[3]) return path.resolve(process.argv[3]);
  try { const f = JSON.parse(fs.readFileSync(path.join(root, 'last-backup.json'), 'utf8')).file; if (f && fs.existsSync(f)) return f; } catch { /* fall through to searching */ }
  const ad = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  const dirs = [path.join(root, 'backups'), path.join(root, '..', 'backups'), path.join(root, '..', '..', 'nexora-data', 'backups'), path.join(ad, 'nexora-host', 'backups'), path.join(ad, 'NEXORA Host', 'backups')];
  const all = []; for (const d of dirs) { try { for (const f of fs.readdirSync(d)) if (/^NEXORA-backup-.*\.zip$/.test(f)) all.push(path.join(d, f)); } catch { /* folder missing */ } }
  all.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs); return all[0] || null;
}
function put(rel, data) {
  const dst = path.join(root, rel), tmp = dst + '.nxtmp'; fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.writeFileSync(tmp, data);
  for (let t = 0; ; t++) { try { fs.renameSync(tmp, dst); return; } catch (e) { if (t >= 20 || !['EPERM', 'EBUSY', 'EACCES'].includes(e?.code)) { try { fs.unlinkSync(tmp); } catch { /* ignore */ } throw e; } Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 250); } }
}

const zipPath = findBackup(); if (!zipPath) die('No backup was found. Nothing was changed.');
say('Using backup: ' + zipPath);
let ents; try { ents = readZip(fs.readFileSync(zipPath)); } catch (e) { die(e.message); }
let meta; try { meta = JSON.parse(ents.find(e => e.name === 'nexora-backup.json').read().toString('utf8')); if (meta.app !== 'nexora-host' || meta.kind !== 'backup') throw 0; } catch { die('That file is not a NEXORA backup.'); }
const files = ents.filter(e => e.name.startsWith('files/') && !e.dir), keep = new Set();
let n = 0;
try {
  // Reject damaged payloads before saving or changing anything.
  const payload = [];
  for (const f of files) { const rel = safeRel(f.name.slice(6)); if (rel && !SKIP.has(rel.split('/')[0])) payload.push({ rel, data: f.read() }); }
  // Save the current app before a standalone rollback, matching the in-app restore safety copy.
  const paths = new Set(payload.map(f => f.rel));
  for (const rel of Array.isArray(meta.added) ? meta.added : []) { const safe = safeRel(rel); if (safe) paths.add(safe); }
  for (const rel of walk(path.join(root, 'dist')).map(x => 'dist/' + x)) paths.add(rel);
  const present = [...paths].filter(rel => !SKIP.has(rel.split('/')[0]) && fs.existsSync(path.join(root, rel)));
  const version = (() => { try { return JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).version ?? null; } catch { return null; } })();
  const safety = path.join(path.dirname(zipPath), `NEXORA-before-rollback-v${version ?? 'x'}-${new Date().toISOString().replace(/[:.]/g, '-')}.zip`);
  const snapshot = [{ name: 'nexora-backup.json', data: Buffer.from(JSON.stringify({ app: 'nexora-host', kind: 'backup', created: new Date().toISOString(), version, dist: true, restoredFrom: path.basename(zipPath) }, null, 1)) }];
  for (const rel of present) snapshot.push({ name: 'files/' + rel, data: fs.readFileSync(path.join(root, rel)) });
  await writeZip(safety, snapshot);
  const pointer = path.join(root, 'last-backup.json'), tempPointer = pointer + '.part';
  fs.writeFileSync(tempPointer, JSON.stringify({ file: safety, version, made: new Date().toISOString() }));
  fs.renameSync(tempPointer, pointer);
  say('Safety copy saved: ' + safety);
  for (const f of payload) { keep.add(f.rel); put(f.rel, f.data); n++; if (n % 10 === 0) say(`Restored ${n} of ${payload.length} files…`); }
  for (const rel of Array.isArray(meta.added) ? meta.added : []) { const r = safeRel(rel); if (r && !keep.has(r) && !SKIP.has(r.split('/')[0])) try { fs.unlinkSync(path.join(root, r)); } catch { /* already gone */ } }
  if (meta.dist) for (const r of walk(path.join(root, 'dist')).map(x => 'dist/' + x)) if (!keep.has(r)) try { fs.unlinkSync(path.join(root, r)); } catch { /* ignore */ }
} catch (e) { die(String(e?.message || e)); }
say(`Done. Restored ${n} files${meta.version ? ' (back to version ' + meta.version + ')' : ''}.`);
