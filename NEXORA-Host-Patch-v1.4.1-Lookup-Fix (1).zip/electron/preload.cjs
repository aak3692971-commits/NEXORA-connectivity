// The panel talks to the PC through the local token-protected API; this bridge only adds the few things a web page cannot do itself.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('nexoraShell', {
  win: a => ipcRenderer.invoke('win', String(a)),
  pickExe: () => ipcRenderer.invoke('pickExe'),
  pickZip: d => ipcRenderer.invoke('pickZip', String(d || '')),
  pickFolder: () => ipcRenderer.invoke('pickFolder'),
  getPrefs: () => ipcRenderer.invoke('getPrefs'),
  setPrefs: p => ipcRenderer.invoke('setPrefs', { autostart: p && p.autostart === true ? true : p && p.autostart === false ? false : undefined, tray: p && p.tray === true ? true : p && p.tray === false ? false : undefined }),
  openData: () => ipcRenderer.invoke('openData'),
});
