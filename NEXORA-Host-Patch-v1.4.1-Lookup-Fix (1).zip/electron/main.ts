/**
 * NEXORA Host – Electron main process
 *
 * HARD RULES (so the installed app can never be a silent, window-less process):
 *  1. No top-level await (known to hang packaged Electron ESM mains).
 *  2. Window is created the instant app is ready – before any slow work.
 *  3. Every stage is logged to %APPDATA%\nexora-host\logs\startup.log
 *  4. Any fatal error is shown in the window (or a dialog) and written to the log.
 *  5. Single-instance lock is handled without blocking the event loop with top-level await.
 */
import { app, BrowserWindow, screen, Tray, Menu, nativeImage, ipcMain, dialog, shell } from 'electron';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// Software rendering – some GPU drivers make Electron windows invisible/blank.
app.disableHardwareAcceleration();

const here = path.dirname(fileURLToPath(import.meta.url));
const packaged = app.isPackaged;
// Electron's app path is the authoritative root in installed builds
// (resources/app when asar is disabled). `here/..` is only the build layout.
const appRoot = path.resolve(packaged ? app.getAppPath() : path.resolve(here, '..'));
const portableDir = path.join(path.dirname(process.execPath), 'nexora-data');
process.env.NEXORA_HOME =
  process.env.NEXORA_HOME ||
  (packaged && !fs.existsSync(portableDir) ? app.getPath('userData') : packaged ? portableDir : process.cwd());

// ---------- startup log (the one place to look when "nothing happens") ----------
const logDir = path.join(process.env.NEXORA_HOME!, 'logs');
const startupLog = path.join(logDir, 'startup.log');
const note = (m: string) => {
  try {
    fs.mkdirSync(logDir, { recursive: true });
    fs.appendFileSync(startupLog, `${new Date().toISOString()}  ${m}\n`);
  } catch {
    /* nowhere to write */
  }
};
const errText = (e: unknown) =>
  (e instanceof Error ? e.stack || e.message : String(e)).slice(0, 2000);

note(
  `start v${app.getVersion()} packaged=${packaged} electron=${process.versions.electron} node=${process.versions.node} home=${process.env.NEXORA_HOME} appRoot=${appRoot}`,
);

// ---------- state ----------
let win: BrowserWindow | null = null;
let tray: Tray | null = null;
let quitting = false;
let uiUrl = '';
let fatal: string | null = null;
let host: any = null;
let ui: any = null;
let up = false; // after a successful start, stray errors only go to the log

const fail = (stage: string, e: unknown) => {
  fatal = fatal ?? `${stage}: ${errText(e)}`;
  note('FATAL ' + stage + ': ' + errText(e));
  showError();
};

process.on('uncaughtException', (e) => (up ? note('uncaught: ' + errText(e)) : fail('Unexpected error', e)));
process.on('unhandledRejection', (e) =>
  up ? note('unhandled rejection: ' + errText(e)) : fail('Unexpected error', e),
);

// ---------- single-instance lock (NO top-level await) ----------
const beatFile = path.join(process.env.NEXORA_HOME!, 'running.json');
const readBeat = (): { pid: number; t: number } | null => {
  try {
    const b = JSON.parse(fs.readFileSync(beatFile, 'utf8'));
    return typeof b.pid === 'number' && typeof b.t === 'number' ? b : null;
  } catch {
    return null;
  }
};
const writeBeat = () => {
  try {
    fs.writeFileSync(beatFile, JSON.stringify({ pid: process.pid, t: Date.now() }));
  } catch {
    /* read-only folder */
  }
};

note('requesting single-instance lock…');
let gotLock = app.requestSingleInstanceLock();
note(`single-instance lock: ${gotLock ? 'ACQUIRED' : 'HELD BY ANOTHER COPY'}`);

if (!gotLock) {
  const b = readBeat();
  if (b && Date.now() - b.t < 20_000) {
    note(`copy ${b.pid} is alive (heartbeat ${Math.round((Date.now() - b.t) / 1000)}s ago) – handing over`);
    app.exit(0);
  } else {
    note(
      `lock held but no fresh heartbeat (${b ? 'last ' + Math.round((Date.now() - b.t) / 1000) + 's ago' : 'no file'}) – taking over`,
    );
    try {
      if (b && b.pid !== process.pid) process.kill(b.pid);
    } catch {
      /* already gone */
    }
    // Clean Electron singleton files that can outlive a crashed process
    for (const name of ['SingletonLock', 'SingletonSocket', 'SingletonCookie']) {
      try {
        fs.unlinkSync(path.join(app.getPath('userData'), name));
      } catch {
        /* ignore */
      }
    }
    // Give the OS a moment, then try the lock once more (still no top-level await)
    setTimeout(() => {
      gotLock = app.requestSingleInstanceLock();
      note(`second lock attempt: ${gotLock ? 'ACQUIRED' : 'STILL BLOCKED'}`);
      if (!gotLock) {
        note('could not take over – showing dialog and exiting');
        dialog.showErrorBox(
          'NEXORA Host is already running',
          'Another copy of NEXORA Host is stuck and could not be closed.\n\nOpen Task Manager, end every "NEXORA Host" process, then start it again.',
        );
        app.exit(1);
        return;
      }
      writeBeat();
      setInterval(writeBeat, 5000).unref?.();
      startApp();
    }, 1500);
  }
} else {
  writeBeat();
  setInterval(writeBeat, 5000).unref?.();
}

// ---------- helpers ----------
const prefsFile = path.join(app.getPath('userData'), 'prefs.json');
const loadPrefs = (): { tray: boolean; startHidden: boolean } => {
  try {
    return { tray: true, startHidden: false, ...JSON.parse(fs.readFileSync(prefsFile, 'utf8')) };
  } catch {
    return { tray: true, startHidden: false };
  }
};
const savePrefs = (p: object) => {
  try {
    fs.mkdirSync(path.dirname(prefsFile), { recursive: true });
    fs.writeFileSync(prefsFile, JSON.stringify({ ...loadPrefs(), ...p }));
  } catch (e) {
    note('prefs not saved: ' + errText(e));
  }
};

const icon = () => {
  try {
    const candidates = [
      path.join(here, 'icon.png'),
      path.join(here, '../build/icon.png'),
      path.join(process.resourcesPath || '', 'icon.png'),
      path.join(path.dirname(process.execPath), 'icon.png'),
    ];
    for (const c of candidates) {
      if (fs.existsSync(c)) return nativeImage.createFromPath(c);
    }
  } catch {
    /* fall through */
  }
  return nativeImage.createEmpty();
};

const esc = (s: string) => s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]!);
const page = (body: string, extra = '') =>
  'data:text/html;charset=utf-8,' +
  encodeURIComponent(
    `<!doctype html><meta charset="utf-8"><style>
html,body{margin:0;height:100%;background:#050b16;color:#eaf1ff;font:15px "Segoe UI",system-ui,sans-serif}
body{display:grid;place-items:center;text-align:center;-webkit-app-region:drag}
.b{max-width:640px;padding:30px}h1{font-size:22px;margin:0 0 10px;letter-spacing:.2em}
p{color:#9fb0d6;line-height:1.55}
pre{text-align:left;white-space:pre-wrap;background:#0a1630;border:1px solid #1d3568;border-radius:10px;padding:12px;color:#ffb3bd;max-height:220px;overflow:auto;font-size:12px;-webkit-app-region:no-drag;user-select:text}
button{-webkit-app-region:no-drag;margin:6px;height:40px;padding:0 18px;border-radius:10px;border:1px solid #2a4a99;background:#10224d;color:#fff;font:inherit;cursor:pointer}
.s{width:42px;height:42px;border:4px solid #1d3568;border-top-color:#3b8bff;border-radius:50%;margin:0 auto 18px;animation:r 1s linear infinite}
@keyframes r{to{transform:rotate(360deg)}}
</style><div class="b">${body}</div>${extra}`,
  );

const startingPage = () =>
  page('<div class="s"></div><h1>NEXORA</h1><p>Starting your host…</p>');

function showError() {
  note('showError called, fatal=' + (fatal ?? 'null'));
  if (!win || win.isDestroyed()) {
    try {
      createWindow();
    } catch (e) {
      note('createWindow in showError failed: ' + errText(e));
    }
  }
  if (!win || win.isDestroyed()) {
    try {
      dialog.showErrorBox('NEXORA Host could not start', (fatal ?? 'Unknown error') + `\n\nDetails: ${startupLog}`);
    } catch {
      /* nothing else to do */
    }
    app.exit(1);
    return;
  }
  const f = fatal ?? 'Unknown error';
  const helpful = /EADDRINUSE/.test(f)
    ? '<p>Another copy of NEXORA Host is already running (maybe the browser version). Close it and press Retry.</p>'
    : /not found|Cannot find module/i.test(f)
      ? '<p>A program file is missing. Reinstall NEXORA Host.</p>'
      : '';
  void win.loadURL(
    page(
      `<h1>NEXORA</h1><p><b>The host could not start.</b></p>${helpful}<pre>${esc(f)}</pre><p style="font-size:12px">Full log: ${esc(startupLog)}</p><button onclick="location.href='nexora://retry'">Retry</button><button onclick="location.href='nexora://quit'">Quit</button>`,
    ),
  );
  win.show();
  win.focus();
}

function showWindow() {
  if (!win || win.isDestroyed()) createWindow();
  win!.show();
  win!.focus();
}

/** 1920x1080 window, always 16:9; on smaller screens the largest 16:9 size that fits (the UI scales with it). */
function winSize() {
  const wa = screen.getPrimaryDisplay().workAreaSize; let w = Math.min(1920, wa.width), h = Math.min(1080, wa.height);
  if (w / h > 16 / 9) w = Math.round(h * 16 / 9); else h = Math.round(w * 9 / 16);
  return { width: w, height: h, minWidth: Math.min(960, w), minHeight: Math.min(540, h) };
}
function createWindow() {
  note('createWindow()');
  win = new BrowserWindow({
    useContentSize: true,
    ...winSize(),
    frame: false,
    backgroundColor: '#050b16',
    show: false,
    title: 'NEXORA Host',
    icon: icon(),
    webPreferences: {
      preload: path.join(here, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });
  try { win.setAspectRatio(16 / 9); } catch { /* optional */ }
  const hidden = process.argv.includes('--hidden') && !fatal && !!tray;
  let shown = false;
  const reveal = () => {
    if (shown || !win || win.isDestroyed()) return;
    shown = true;
    if (!hidden) {
      note('revealing window');
      win.show();
      win.focus();
    }
  };
  win.once('ready-to-show', reveal);
  setTimeout(reveal, 2000); // never rely on a single event
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//.test(url)) void shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    e.preventDefault();
    if (url === 'nexora://quit') {
      quitting = true;
      app.exit(0);
    } else if (url === 'nexora://retry') {
      app.relaunch();
      quitting = true;
      app.exit(0);
    }
  });
  win.webContents.on('did-fail-load', (_e, code, desc, url) => {
    if (code === -3 || url.startsWith('data:')) return;
    note(`window load failed ${code} ${desc} ${url}`);
    fail('The control panel did not load', new Error(`${desc} (${code})`));
  });
  win.webContents.on('render-process-gone', (_e, d) =>
    fail('The window crashed', new Error(d.reason)),
  );
  win.on('close', (e) => {
    if (!quitting && !fatal && tray && loadPrefs().tray) {
      e.preventDefault();
      win!.hide();
    }
  });
  win.on('closed', () => {
    win = null;
  });
  void win.loadURL(uiUrl || startingPage());
}

function makeTray() {
  try {
    const img = icon();
    if (img.isEmpty()) throw new Error('icon missing');
    tray = new Tray(img.resize({ width: 16, height: 16 }));
    tray.setToolTip('NEXORA Host');
    tray.setContextMenu(
      Menu.buildFromTemplate([
        { label: 'Open NEXORA Host', click: showWindow },
        {
          label: 'Show pairing code',
          click: () => {
            host?.openPairing();
            showWindow();
          },
        },
        { label: 'Stop current stream', click: () => host?.endSession() },
        { type: 'separator' },
        {
          label: 'Quit',
          click: () => {
            quitting = true;
            app.quit();
          },
        },
      ]),
    );
    tray.on('click', showWindow);
    note('tray ready');
  } catch (e) {
    note('tray unavailable (window still works): ' + errText(e));
    tray = null;
  }
}

// ---------- boot the host logic (runs after the window is visible) ----------
async function boot() {
  const step = async <T>(name: string, f: () => Promise<T> | T): Promise<T> => {
    note('step: ' + name);
    try {
      return await f();
    } catch (e) {
      throw Object.assign(
        new Error(`${name} failed: ${e instanceof Error ? e.message : e}`),
        { stack: e instanceof Error ? e.stack : undefined },
      );
    }
  };

  // Import from the bundled graph. esbuild (bundle:true) will include these.
  // Paths are relative to this file at BUILD time (electron/main.ts → ../src/…).
  const { HostApp } = await step('load host', () => import('../src/app.js'));
  const { buildIceServers } = await step('load config', () => import('../src/config.js'));
  const { startUi } = await step('load panel', () => import('../src/ui.js'));
  const { loadNodePeerFactory } = await import('../src/rtc-node.js');
  const { createWindowsInput, createLogInput } = await import('../src/input-win.js');

  host = await step(
    'create host',
    async () =>
      new HostApp({
        appRoot, // Installed builds resolve to resources/app; the app is unpacked so patches replace real files.
        restart: () => { app.relaunch(); app.exit(0); },
        remote: true,
        echo: !packaged,
        WS:
          typeof (globalThis as any).WebSocket === 'undefined'
            ? ((await import('ws')).WebSocket as any)
            : undefined,
      }),
  );

  // Optional native parts – failure is a warning, never a blank window.
  try {
    host.setBindings({ makePeer: await loadNodePeerFactory(buildIceServers(host.cfg)) });
  } catch (e) {
    note('webrtc not loaded: ' + errText(e));
    host.log.log('webrtc_missing', {
      err: e instanceof Error ? e.message.slice(0, 160) : 'unknown',
    });
    host.warn(
      'The WebRTC component (node-datachannel) failed to load, so streaming cannot start. Reinstall NEXORA Host.',
    );
  }
  try {
    host.setBindings({
      osInput:
        process.platform === 'win32'
          ? await createWindowsInput(host.log.log)
          : createLogInput(host.log.log),
    });
  } catch (e) {
    note('input backend not loaded: ' + errText(e));
    host.log.log('input_backend_missing', {
      err: e instanceof Error ? e.message.slice(0, 160) : 'unknown',
    });
    host.setBindings({ osInput: createLogInput(host.log.log) });
  }

  await step('start host', async () => {
    await host.ready();
    await host.start();
  });
  ui = await step('start control panel', () => startUi(host));
  uiUrl = ui.url;
  note('panel at ' + uiUrl.replace(/#.*/, ''));
  if (win && !win.isDestroyed()) await win.loadURL(uiUrl);
  else createWindow();
  up = true;
  note('ready');
}

// ---------- IPC (window controls used by the frameless UI) ----------
ipcMain.handle('win', (e, a: string) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (!w) return;
  if (a === 'min') w.minimize();
  else if (a === 'max') w.isMaximized() ? w.unmaximize() : w.maximize();
  else if (a === 'close') w.close();
});
ipcMain.handle('pickExe', async (e) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showOpenDialog(w!, {
    title: 'Choose the game',
    properties: ['openFile'],
    filters: [{ name: 'Games', extensions: ['exe'] }],
  });
  return r.canceled ? null : (r.filePaths[0] ?? null);
});
ipcMain.handle('pickZip', async (e, dir: string) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showOpenDialog(w!, { title: 'Choose the file', properties: ['openFile'], defaultPath: typeof dir === 'string' && dir ? dir : undefined, filters: [{ name: 'Zip files', extensions: ['zip'] }] });
  return r.canceled ? null : (r.filePaths[0] ?? null);
});
ipcMain.handle('pickFolder', async (e) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showOpenDialog(w!, { title: 'Choose a folder for the backup', properties: ['openDirectory', 'createDirectory'] });
  return r.canceled ? null : (r.filePaths[0] ?? null);
});
ipcMain.handle('getPrefs', () => loadPrefs());
ipcMain.handle('setPrefs', (_e, p: any) => {
  savePrefs(p || {});
  return loadPrefs();
});
ipcMain.handle('openData', () => {
  shell.openPath(process.env.NEXORA_HOME || app.getPath('userData'));
});

// ---------- app lifecycle ----------
app.on('second-instance', () => {
  note('second launch: showing window');
  showWindow();
});
app.on('before-quit', () => {
  quitting = true;
});
app.on('window-all-closed', () => {
  if (fatal || !tray) app.quit();
});
app.on('will-quit', () => {
  try {
    host?.stop();
    ui?.close();
  } catch {
    /* shutting down */
  }
});

function startApp() {
  note('startApp() – waiting for electron ready');
  app
    .whenReady()
    .then(async () => {
      note('electron ready');
      try {
        createWindow(); // visible immediately
        makeTray();
        await boot();
      } catch (e) {
        fail('Startup', e);
      }
    })
    .catch((e) => fail('whenReady', e));
}

// Only start if we already hold the lock. The "take over" path calls startApp() itself.
if (gotLock) {
  startApp();
}

note('main module evaluation finished (gotLock=' + gotLock + ')');
