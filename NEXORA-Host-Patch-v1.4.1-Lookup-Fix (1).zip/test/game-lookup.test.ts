import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canonicalizeGameName, isReliableMatch, matchScore, normalizeGameName, rankTitles,
} from '../src/game-lookup.ts';

test('known abbreviations resolve to canonical game names', () => {
  assert.equal(canonicalizeGameName('ac black flag'), "assassins creed iv black flag");
  assert.equal(canonicalizeGameName('gta 5'), 'grand theft auto v');
  assert.equal(canonicalizeGameName('rdr2'), 'red dead redemption 2');
  assert.equal(canonicalizeGameName('witcher 3'), 'the witcher 3 wild hunt');
});

test('punctuation, accents, case, and storefront words do not change identity', () => {
  assert.equal(normalizeGameName('  The Witcher III: Wild-Hunt (Steam)  '), 'the witcher iii wild hunt');
  assert.equal(canonicalizeGameName('GTA 5 — Steam'), 'grand theft auto v');
  assert.equal(canonicalizeGameName('Epic Mickey'), 'epic mickey');
});

test('a small typo still matches while unrelated titles do not', () => {
  assert.ok(matchScore('cyberpun 2077', 'Cyberpunk 2077') >= 0.8);
  assert.ok(matchScore('Forza Horizn 5', 'Forza Horizon 5') >= 0.8);
  assert.ok(matchScore('rdr2', 'Cooking Simulator') < 0.42);
  const typoMatch = rankTitles('cyberpun 2077', [
    { title: 'Cyberpunk 2077' },
    { title: 'Cyberpunk 2077: Phantom Liberty' },
    { title: 'Cyberpunk 2077 REDmod' },
  ]);
  assert.equal(isReliableMatch(typoMatch, 'cyberpun 2077'), true);
});

test('an exact title is reliable but near-tied alternatives are not silently selected', () => {
  const exact = rankTitles('gta 5', [{ title: 'Grand Theft Auto V' }, { title: 'Grand Theft Auto V Enhanced' }]);
  assert.equal(exact[0]?.confidence, 1);
  assert.equal(isReliableMatch(exact, 'gta 5'), true);

  const ambiguous = rankTitles('Assassin Creed', [
    { title: "Assassin's Creed III: Liberation" },
    { title: "Assassin's Creed IV: Black Flag" },
  ]);
  assert.equal(isReliableMatch(ambiguous, 'Assassin Creed'), false);
});
