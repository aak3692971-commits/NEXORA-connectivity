import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { MetaStore, type Fetcher } from '../src/meta.ts';
import type { Dirs } from '../src/paths.ts';

function dirs(): Dirs {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'nexora-meta-test-'));
  const config = path.join(root, 'config');
  const data = path.join(root, 'data');
  const games = path.join(root, 'games');
  const logs = path.join(root, 'logs');
  const cache = path.join(root, 'cache');
  for (const folder of [config, data, games, logs, cache]) fs.mkdirSync(folder, { recursive: true });
  return { root, config, data, games, logs, cache } as Dirs;
}

function response(data: unknown, status = 200) {
  return {
    ok: status >= 200 && status < 300,
    status,
    json: async () => data,
    arrayBuffer: async () => new ArrayBuffer(0),
    headers: { get: () => null },
  };
}

test('a reliable Steam result is selected and later stores are not queried', async () => {
  const calls: string[] = [];
  const fetcher: Fetcher = async url => {
    calls.push(url);
    if (url.includes('/storesearch/')) return response({ items: [{ id: 271590, name: 'Grand Theft Auto V' }] });
    if (url.includes('/appdetails?')) return response({ 271590: { success: true, data: {
      name: 'Grand Theft Auto V', short_description: 'An open-world action game.',
      developers: ['Rockstar North'], publishers: ['Rockstar Games'], platforms: { windows: true },
      release_date: { date: '14 Apr, 2015' }, genres: [{ description: 'Action' }],
    } } });
    throw new Error(`Unexpected request ${url}`);
  };
  const store = new MetaStore(dirs(), fetcher);
  const result = await store.lookup('gtav', 'gta 5');
  assert.equal(result?.source, 'steam');
  assert.equal(result?.title, 'Grand Theft Auto V');
  assert.equal(result?.platformIds?.steam, '271590');
  assert.equal(result?.developer, 'Rockstar North');
  assert.equal(result?.platforms?.[0], 'Windows');
  assert.equal(calls.length, 2);
  assert.equal(calls.some(url => url.includes('catalog.gog.com')), false);
});

test('a failed Steam request falls through to GOG and keeps platform metadata', async () => {
  const calls: string[] = [];
  const fetcher: Fetcher = async url => {
    calls.push(url);
    if (url.includes('/storesearch/')) return response({}, 503);
    if (url.includes('catalog.gog.com')) return response({ products: [{
      id: '12345', slug: 'sample_quest', productType: 'game', title: 'Sample Quest',
      coverHorizontal: '', releaseDate: '2024.02.03', developers: ['Studio'], publishers: ['Label'],
      genres: [{ name: 'Adventure' }], operatingSystems: ['windows', 'linux'],
    }] });
    if (url.includes('api.gog.com/products/')) return response({
      title: 'Sample Quest', description: { lead: '<p>Story &amp; puzzles.</p>' },
      images: {}, links: { product_card: 'https://www.gog.com/game/sample_quest' },
    });
    throw new Error(`Unexpected request ${url}`);
  };
  const store = new MetaStore(dirs(), fetcher);
  const result = await store.lookup('sample', 'Sample Quest');
  assert.equal(result?.source, 'gog');
  assert.equal(result?.platformIds?.gog, '12345');
  assert.equal(result?.description, 'Story & puzzles.');
  assert.equal(result?.developer, 'Studio');
  assert.deepEqual(result?.platforms, ['Windows', 'Linux']);
  assert.ok(calls.some(url => url.includes('catalog.gog.com')));
  assert.equal(calls.some(url => url.includes('store.epicgames.com/graphql')), false);
});

test('Epic is queried after Steam and GOG, and its platform ID is saved', async () => {
  const calls: string[] = [];
  const fetcher: Fetcher = async url => {
    calls.push(url);
    if (url.includes('/storesearch/')) return response({ items: [] });
    if (url.includes('catalog.gog.com')) return response({ products: [] });
    if (url.includes('store.epicgames.com/graphql')) return response({ data: { Catalog: { searchStore: {
      elements: [{
        id: 'epic-product-42', title: 'Sample Tactics', description: 'A tactical adventure.',
        productSlug: 'sample-tactics', keyImages: [], effectiveDate: '2024-02-03',
        seller: { name: 'Example Publisher' },
        customAttributes: [{ key: 'developerName', value: 'Example Studio' }],
        categories: [{ path: 'games/edition/base' }],
      }],
    } } } });
    throw new Error(`Unexpected request ${url}`);
  };
  const store = new MetaStore(dirs(), fetcher);
  const result = await store.lookup('epic', 'Sample Tactics');
  assert.equal(result?.source, 'epic');
  assert.equal(result?.platformIds?.epic, 'epic-product-42');
  assert.equal(result?.developer, 'Example Studio');
  assert.equal(result?.publisher, 'Example Publisher');
  assert.deepEqual(calls.map(url => url.includes('storesearch/') ? 'steam' : url.includes('catalog.gog.com') ? 'gog' : 'epic'), ['steam', 'gog', 'epic']);
});

test('uncertain candidates are exposed as alternatives and require an explicit choice', async () => {
  const fetcher: Fetcher = async url => {
    if (url.includes('/storesearch/')) return response({ items: [
      { id: 3, name: "Assassin's Creed III: Liberation" },
      { id: 4, name: "Assassin's Creed IV: Black Flag" },
    ] });
    if (url.includes('catalog.gog.com')) return response({ products: [] });
    if (url.includes('store.epicgames.com/graphql')) return response({ data: { Catalog: { searchStore: { elements: [] } } } });
    if (url.includes('wikipedia.org/w/api.php')) return response([ 'Assassin Creed', [], [], [] ]);
    if (url.includes('/appdetails?appids=4')) return response({ 4: { success: true, data: {
      name: "Assassin's Creed IV: Black Flag", short_description: 'The golden age of piracy.',
      genres: [{ description: 'Action' }],
    } } });
    throw new Error(`Unexpected request ${url}`);
  };
  const store = new MetaStore(dirs(), fetcher);
  const result = await store.lookup('ambiguous', 'Assassin Creed');
  assert.equal(result, null);
  const alternatives = store.suggestions('ambiguous');
  assert.ok(alternatives.length >= 2);
  assert.ok(alternatives.some(x => x.title.includes('Black Flag')));
  const selected = await store.chooseSuggestion('ambiguous', alternatives.findIndex(x => x.title.includes('Black Flag')));
  assert.equal(selected?.title, "Assassin's Creed IV: Black Flag");
  assert.equal(selected?.platformIds?.steam, '4');
  assert.equal(selected?.description, 'The golden age of piracy.');
});
